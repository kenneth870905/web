<template>
  <div class="layout-box">
    <div class="layout-header">
      <van-nav-bar title="忘记密码"
                   left-arrow
                   left-text="返回"
                   @click-left="$router.go(-1)" />
    </div>
    <div class="forget">
      <div class="cs-service"
           @click="cs">
        <img src="https://0698aa.com/M1/static/image/kefu.png"
             alt=""
             class="wh">
      </div>
    </div>
  </div>

</template>

<script>
import { mapState } from 'vuex';

export default {
  computed: {
    ...mapState({
      config: 'config'
    })
  },
  methods: {
    cs () {
      if (window.plus) {
        plus.runtime.openURL(config.online_chat)
      } else if (window.webkit) {
        window.webkit.messageHandlers.FillMoney.postMessage({
          link: config.online_chat
        })
      } else {
        window.open(config.online_chat)
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.forget {
  .cs-service {
    padding: 0.4rem;
  }
}
</style>
