<template>
  <div class="layout-box">
    <div class="layout-header">
      <van-nav-bar title="会员提款"
                   left-arrow
                   left-text="返回"
                   @click-left="$router.go(-1)" />
    </div>
    <div class="withdraw">
      <div class="withdraw-title">
        <label>提款申请</label>
      </div>
      <div class="m-cell-box">

        <div class="m-cell">
          <div class="cell-item">
            <div class="cell-left">
              <span class="cell-icon"></span>
              <span class="left">
                到账账户
              </span>
            </div>
            <div class="cell-right cell-arrow">
              <span class="right"><span>
                  <i class="icon"></i>
                  <p>{{info.Bank}}({{info.Name}})
                    <br>
                    <b>{{ info.BankAccount}}</b>
                  </p>
                </span></span>
            </div>
          </div>

          <div class="cell-item">
            <div class="cell-left">
              <span class="cell-icon"></span>
              <span class="left">
                当日打码量
              </span>
            </div>
            <div class="cell-right cell-arrow">
              <span class="right"><span>
                  <p>
                    <b>{{info.TempDml}}</b>
                  </p>
                </span></span>
            </div>
          </div>

          <div class="cell-item">
            <div class="cell-left">
              <span class="cell-icon"></span>
              <span class="left">
                所需打码量
              </span>
            </div>
            <div class="cell-right cell-arrow">
              <span class="right"><span>
                  <i class="icon"></i>
                  <p>
                    <b>{{info.Dml}}</b>
                  </p>
                </span></span>
            </div>
          </div>

          <div class="cell-item">
            <div class="cell-left">
              <span class="cell-icon"></span>
              <span class="left">
                可用余额
              </span>
            </div>
            <div class="cell-right cell-arrow">
              <span class="right"><span>
                  <i class="icon"></i>
                  <p>
                    <b>{{info.Money}}</b>
                  </p>
                </span></span>
            </div>
          </div>
          <!--  -->

          <div class="cell-item">
            <div class="cell-left">
              <span class="cell-icon">
              </span>
              <span class="left">
                提款金额
              </span>
            </div>
            <div class="cell-right">
              <span class="right">
                <div class="m-input"
                     slot="right">
                  <input type="number"
                         placeholder="请输入提款金额，最低金额为100元"
                         autocomplete="off"
                         v-model="amount">
                </div>
              </span>
            </div>
          </div>
          <div class="cell-item">
            <div class="cell-left">
              <span class="cell-icon">
              </span>
              <span class="left">
                安全密码
              </span>
            </div>
            <div class="cell-right">
              <div class="m-input">
                <input type="password"
                       maxlength="4"
                       placeholder="请输入安全密码"
                       autocomplete="off"
                       v-model="pwd">
              </div>
            </div>
          </div>
          <p class="withdraw-tishi01">
            <b>提示：</b>
            当天提款次数超过五次会收取额外的手续费 (当天北京时间 00:00:00 - 23:59:59) 敬请谅解！</p>
        </div>
      </div>
      <button class="btnOk btn-block btn-primary"
              @click="提款()">申请提款</button>
    </div>
  </div>

</template>

<script>
import { api_获取提款卡, api_提现 } from '@/api/资金接口.js';
import { Dialog } from 'vant';
export default {
  data () {
    return {
      amount: '',
      pwd: '',
      info: []
    }
  },

  methods: {
    获取提款信息 () {
      api_获取提款卡().then(x => {
        if (!x.data.IsBank) {
          Dialog.confirm({
            title: '温馨提示',
            message: '您还尚未绑定银行卡，请问是否立即绑定？',
            cancelButtonText: '返回首页'
          })
            .then(x => {
              this.$router.push('/mine/bankInfo')
            })
            .catch(e => {
              this.$router.push('/')
            })
        } else {
          this.info = x.data
        }
      })
    },
    提款 () {
      if (this.amount < 100) {
        this.$toast('取款金额必须大于100元')
        return;
      } else if (this.amount > this.info.Money) {
        this.$toast('可用余额不足')
        return;
      } else if (this.pwd.length != 4) {
        this.$toast('请输入安全密码')
        return;
      }
      Dialog.confirm({
        title: '确定提交取款审核吗？',
        message: '金额：' + this.amount
      })
        .then(() => {
          // on confirm
          api_提现({ amount: this.amount, pwd: this.pwd })
            .then(x => {
              if (x.data.code == 0) {
                this.$toast('提交成功，请等待审核')
              } else {
                this.$toast(x.data.msg)
              }
            })
            .catch(err => {
              this.$toast('系统繁忙，稍后再试')
            })
        })
        .catch(() => {
          // on cancel
        })
    }
  },
  mounted () {
    this.获取提款信息()
  }
}
</script>

<style lang="scss" scoped>
.withdraw {
  &-title {
    width: 100%;
    background-color: #fff;
    border-bottom: 5px solid #f2f2f2;
    label {
      display: inline-block;
      font-size: 0.26rem;
      margin: 0.3rem 0;
      padding-left: 0.15rem;
      border-left: 5px solid #ff3a2b;
      color: #888;
    }
  }
}

.title-item {
  position: relative;
  z-index: 6;
  width: 100%;
  background-color: #fff;
  border-bottom: 1px solid #f2f2f2;
}
.m-cell {
  z-index: 5;
  background-color: #fff;
}
.cell-item {
  display: flex;
  position: relative;
  padding-left: 0.24rem;
  overflow: hidden;
  border-bottom: 1px solid #eee;
}
.cell-left {
  font-size: 0.26rem;
  display: flex;
  align-items: center;
}
.cell-icon {
  display: block;
  margin-right: 0.1rem;
}
.left {
  width: 1.65rem;
}
.cell-right {
  flex: 1;
  width: 100%;
  min-height: 1.2rem;
  color: grey;
  text-align: right;
  padding-right: 0.24rem;
  justify-content: flex-end;
  display: flex;
  align-items: center;
}
.right {
  text-align: left;
  width: 100%;
  display: inline-block;
}

p {
  font-size: 0.24rem;
  color: rgb(187, 187, 187);
  b {
    color: rgb(102, 102, 102);
    font-weight: 500;
  }
}
.m-input {
  display: flex;
  width: 100%;
  height: 100%;
  align-items: center;
  border: none;
  input {
    flex: 1;
    height: 1.2rem;
    border: none;
    font-size: 0.26rem;
    background: transparent;
    color: #666;
    display: flex;
    justify-content: flex-start;
    align-items: center;
    text-align: left;
  }
}
.withdraw-tishi01 {
  font-size: 0.22rem;
  color: #aaa;
  font-weight: 400;
  line-height: 0.32rem;
  padding: 0.26rem 0;
  margin: 0 4.5%;
  b {
    color: #f01924;
    font-weight: bolder;
  }
}
.btnOk {
  width: 96%;
  height: 0.88rem;
  border: none;
  margin-left: 2%;
  margin-top: 0.2rem;
  background-color: #f01924;
  color: #fff;
  font-size: 0.26rem;
  border-radius: 4px;
}
.van-dialog {
  // transform: translate3d(-50%, -60%);
}
</style>
