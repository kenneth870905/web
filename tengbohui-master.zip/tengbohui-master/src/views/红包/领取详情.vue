<template>
  <div>
    <header class="mui-bar mui-bar-nav">
      <a class="mui-action-back mui-icon mui-icon-left-nav mui-pull-left"></a>
      <h1 class="mui-title">红包详情</h1>
      <!-- <button class="mui-btn mui-btn-blue mui-btn-link mui-pull-right" @click="$toast('暂未开放')">
                <i class="mui-icon mui-icon-help"></i>
      </button>-->
    </header>
    <div class="mui-content mui-fullscreen">
      <div class="占位"></div>
      <div class="半圆">
        <!-- <by /> -->
      </div>
      <div class="hader_1">
        <div class="img_1">
          <img
            v-if="详情.ImgId"
            :src="`${config.img_url}static/image/touxiang/${详情.ImgId}`"
            alt
            srcset
          />
          <img v-else :src="`${config.img_url}static/image/touxiang/wutu.jpg`" alt srcset />
        </div>
        <div class="name">
          <span>{{详情.Nickname}}</span>
          <span>拼</span>
        </div>
        <div class="提示1">{{详情.Note}}</div>
        <div v-if="详情.MyBonus">
          <div class="金额">￥{{详情.MyBonus.Amount}}</div>
          <div class="提示2">已存入零钱，可用于购彩</div>
        </div>
      </div>

      <div class="title_1">
        <div
          v-if="详情.BonusLogs.length<详情.Quantity"
        >已领取{{详情.BonusLogs.length}}/{{详情.Quantity}} 个，共{{总额}}/{{详情.Amount}}元</div>
        <div v-else>{{详情.Quantity}}个红包共{{详情.Amount}}元</div>
      </div>

      <ul class="mui-table-view list_1">
        <li class="mui-table-view-cell" v-for="(item, index) in 详情.BonusLogs" :key="index">
          <img
            v-if="item.ImgId"
            class="img_1"
            :src="`${config.img_url}static/image/touxiang/${item.ImgId}`"
            alt
            srcset
          />
          <img
            v-else
            class="img_1"
            :src="`${config.img_url}static/image/touxiang/wutu.jpg`"
            alt
            srcset
          />
          <ul>
            <li>
              <div :class="{'红色字体':item.IsSelf}">{{item.Nickname ? item.Nickname : "暂无昵称" }}</div>
              <div>{{item.Amount}}元</div>
            </li>
            <li>
              <div class="time">{{item.ReceiveDate | ft}}</div>
              <div class="手气王" v-if="item.Amount == 最大">
                <img :src="`${config.img_url}static/image/liaotian/huanguan.png`" alt srcset />
                手气最佳
              </div>
            </li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
import moment from 'moment'
import { api_查询状态, api_群红包领取状态 } from "@/api/红包接口.js";
// import by from "@/components/半圆.vue";
import { mapState, mapActions } from 'vuex';
export default {
  name: "",
  components: {
    // by
  },
  data() {
    return {
      bonusId: "",
      MemberId: '',
      Nickname: "",
      详情: {
        MyBonus: null,
        BonusLogs: []
      },
    }
  },
  filters: {
    ft(t) {
      return moment(t).format('H:mm');
    }
  },
  computed: {
    ...mapState({
      config: 'config',
      Person: x => x.个人资料.Person
    }),
    总额() {
      let n = 0;
      this.详情.BonusLogs.forEach(x => n += x.Amount);
      return Math.round(n * 100) / 100
    },
    最大() {
      let list = this.详情.BonusLogs.sort((a, b) => {
        return b.Amount - a.Amount;
      })
      return list[0].Amount;
    }
  },
  methods: {
    ...mapActions({
      // getPersonInfo:'个人资料/getPersonInfo',
    }),
  },
  mounted() {
    this.bonusId = this.$route.query.b;
    // api_查询状态(this.bonusId).then(x=>{
    //     console.log(x)
    //     this.MyBonus = x.data.msg; 
    // }).catch(err=>{})


    api_群红包领取状态({ bonusId: this.bonusId }).then(x => {
      this.详情 = x.data.msg;
    }).catch(err => { })

  },
}
</script>

<style lang="scss" scoped>
.红色字体 {
  color: red;
}
.mui-bar-nav {
  box-shadow: none;
}
.mui-content {
  background: #ffffff;
}
.占位 {
  height: 20px;
  @include bgcolor;
}
.半圆 {
  height: _vw(40);
}
.hader_1 {
  text-align: center;
  margin-top: -25px;
  position: relative;
  border-bottom: _vw(10) solid #eeee;
  padding: 0px 0px 25px;
  .img_1 {
    width: _vw(50);
    height: _vw(50);
    margin: 0px auto;
    img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      border-radius: 100%;
    }
  }
  .name {
    margin: _vw(10) 0px 0px;
    font-size: _vw(16);
    span:nth-child(1) {
      font-weight: bold;
    }
    span:nth-child(2) {
      margin: 0px 0px 0px 5px;
      width: 22px;
      text-align: center;
      display: inline-block;
      background: #eeb54b;
      color: #ffffff;
    }
  }
  .提示1 {
    font-size: _vw(14);
    color: #4e4e4e;
    margin: _vw(15) 0px _vw(15);
  }
  .金额 {
    font-size: _vw(40);
    font-weight: bold;
  }
  .提示2 {
    color: #506dd8;
    font-size: _vw(14);
    margin: _vw(15) 0px 0px;
  }
}

.title_1 {
  padding: 0px _vw(10);
  line-height: _vw(50);
  font-size: _vw(14);
  color: #8e8e8e;
  border-bottom: 1px solid #efefef;
}
.list_1 {
  font-size: _vw(15);
  > li {
    display: flex;
  }
  .img_1 {
    width: _vw(50);
    height: _vw(50);
    object-fit: cover;
    border-radius: 100%;
    margin: 0px _vw(5) 0px 0px;
  }
  ul {
    width: calc(100% - #{_vw(55)});
    display: flex;
    flex-direction: column;
    justify-content: space-around;
    > li {
      display: flex;
      align-items: center;
      div {
        white-space: nowrap;
        &:nth-child(1) {
          width: 0;
          flex-grow: 1;
          overflow: hidden;
          text-overflow: ellipsis;
        }
        &:nth-child(2) {
          flex-shrink: 0;
        }
      }
    }
  }
  .time {
    font-size: _vw(12);
    color: #4e4e4e;
  }
  .手气王 {
    color: #ffa802;
    font-size: _vw(14);
    display: flex;
    align-items: center;
    img {
      width: _vw(20);
    }
  }
}
</style>