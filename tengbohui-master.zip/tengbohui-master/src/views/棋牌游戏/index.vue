<template>
  <div class="layout-box">
    <div class="layout-header">
      <appHeader headTitle="棋牌游戏" />
    </div>
    <div class="byyx">
      <div class="byyx-box">
        <img src="images/棋牌游戏/banner.jpg"
             alt="">
      </div>
      <div class="byyx-title">
        <label>随时随地 轻松畅玩</label>
      </div>
      <div class="byyx-games">
        <div class="game-list"
             v-for="(item,index) in list"
             :key="index"
             @click="跳转游戏(item)">
          <div class="game-item">
            <img v-lazy="`images/电游平台/${item.type}/${item.imgid}${item.ext}`">
            <h2>{{item.title}}</h2>
          </div>
        </div>

      </div>
    </div>
    <BackTop container=".byyx"
             :distance="200" />

    <div class="layout-footer">
      <appFooter />
    </div>
  </div>

</template>

<script>
import appHeader from '@/components/头部';
import appFooter from '@/components/尾部';
import { mapState, mapActions } from 'vuex';
import { Dialog } from 'vant';
export default {
  components: {
    appHeader,
    appFooter
  },
  data () {
    return {
      list: [],
      t: []
    }
  },
  created () {
    this.$axios.get('json/home.json').then(x => {
      var data = x.data[3].children
      data[0].children.forEach(item => {
        item.type = data[0].type
        item.ext = data[0].ext
      })
      data[1].children.forEach(item => {
        item.type = data[1].type
        item.ext = data[1].ext
      })
      data[2].children.forEach(item => {
        item.type = data[2].type
        item.ext = data[2].ext
      })
      data[3].children.forEach(item => {
        item.type = data[3].type
        item.ext = data[3].ext
      })
      data[4].children.forEach(item => {
        item.type = data[4].type
        item.ext = data[4].ext
      })
      data[5].children.forEach(item => {
        item.type = data[5].type
        item.ext = data[5].ext
      })
      data[6].children.forEach(item => {
        item.type = data[6].type
        item.ext = data[6].ext
      })
      this.list = _.concat(
        [...data[0].children],
        [...data[1].children],
        [...data[2].children],
        [...data[3].children],
        [...data[4].children],
        [...data[5].children],
        [...data[6].children]
      )
      console.log(this.list)
    })
  },
  computed: {
    ...mapState({
      userinfo: x => x.user.userinfo
    })
  },
  methods: {
    ...mapActions({
      设置类型: '进入游戏/设置类型'
    }),
    跳转游戏 (item) {
      if (this.userinfo.UserId) {
        this.设置类型(item)
      } else {
        this.$store.commit('setIsLoginShow', true)
      }
    },

  }
}
</script>

<style lang="scss" scoped>
.byyx {
  flex: 1;
  overflow-x: scroll;
  background: #fff;
  &-box {
    width: auto;
    height: 3.33rem;
    margin: 0.16rem 2% 0 2%;
    box-shadow: 1px 2px 12px rgba(0, 100, 255, 0.1);
    img {
      width: 100%;
      height: 100%;
    }
  }
  &-title {
    width: 100%;
    margin: 0 0 0 0;
    text-align: center;
    label {
      font-size: 0.3rem;
      height: 0.28rem;
      line-height: 0.32rem;
      margin: 0.22rem 0 0.12rem 0;
      color: #444;
      font-weight: 400;
      color: #79d1ff;
      text-shadow: 1px 1px 2px rgba(0, 155, 255, 0.25);
      opacity: 0.8;
      display: inline-block;
    }
  }
  &-games {
    overflow: hidden;
    padding-bottom: 0.1rem;
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    .game-list {
      width: 30%;
      display: flex;
      justify-content: center;
      align-items: center;
      background: #fff;
      border-radius: 16px;
      margin-bottom: 10px;
      margin-top: 10px;
      .game-item {
        width: 1.5rem;
        text-align: center;
        img {
          width: 100%;
          height: 100%;
          border-radius: 16px;
        }
        h2 {
          color: #444;
          font-weight: 400;
          font-size: 0.24rem;
          line-height: 0.36rem;
          margin-top: 0.1rem;
          white-space: nowrap;
        }
        p {
          font-size: 0.22rem;
          color: #bbb;
          padding-bottom: 0.1rem;
        }
      }
    }
    // img {
    //   border-radius: 16px;
    // }
    // h2 {
    //   color: #444;
    //   font-weight: 400;
    //   font-size: 0.24rem;
    //   line-height: 0.36rem;
    //   margin-top: 0.1rem;
    // }
    // p {
    //   font-size: 0.22rem;
    //   color: #bbb;
    //   padding-bottom: 0.1rem;
    // }
  }
}
</style>
