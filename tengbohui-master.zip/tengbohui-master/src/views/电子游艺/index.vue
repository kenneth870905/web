<template>
  <div class="layout-box">
    <div class="layout-header">
      <appHeader headTitle="电子游艺" />
    </div>
    <div class="dzyy">
      <!-- 游戏头部 -->
      <yxtb />
      <!-- 最新中奖 -->
      <zxzj />
      <!-- 游戏列表 -->
      <yxlb />
      <BackTop container=".dzyy"
               :distance="200" />
    </div>
    <div class="layout-footer">
      <appFooter />
    </div>
  </div>

</template>

<script>
import appHeader from '@/components/头部';
import appFooter from '@/components/尾部';
const yxlb = () => import('./components/游戏列表')
const zxzj = () => import('./components/最新中奖')
const yxtb = () => import('./components/游戏头部')
export default {
  components: {
    appHeader,
    appFooter,
    yxlb,
    zxzj,
    yxtb
  }
}
</script>

<style lang="scss" scoped>
.dzyy {
  flex: 1;
  overflow-x: scroll;
}
</style>
