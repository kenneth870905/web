<template>
  <div class="layout-box">
    <div class="layout-header">
      <van-nav-bar :title="$route.meta.title"
                   left-arrow
                   left-text="返回"
                   @click-left="handleGoBack" />
    </div>
    <div class="center">
      <div class="game">
        <div class="game-list"
             v-for="(item,index) in list"
             :key="index.id">
          <div class="list-left fl">
            <i class="iconfont">&#xe606;</i>
            <div class="icon-img">
              <img v-lazy="`images/电游平台/${item.type}/${item.imgid}${ext}`"
                   alt=""
                   class="wh">
            </div>
            <div class="list-left-info">
              <h2>{{item.title}}</h2>
            </div>
          </div>
          <div class="list-right fr">
            <button class="btn-start"
                    @click="跳转游戏(item)">开始游戏</button>
          </div>
        </div>

      </div>

      <!-- 返回 -->
      <BackTop container=".center"
               :distance="200" />
    </div>

  </div>
</template>

<script>
import { mapActions, mapState } from 'vuex';
import { Dialog } from 'vant';
export default {
  data () {
    return {
      id: '',
      list: [],
      ext: '',
      type: '',

    }
  },
  computed: {
    ...mapState({
      config: 'config',
      userinfo: x => x.user.userinfo
    })
  },
  created () {
    this.$axios.get('json/home.json').then(x => {
      this.list = x.data[2].children.filter(
        x => x.title === this.$route.meta.title
      )
      this.ext = this.list[0].ext
      this.list = this.list[0].children
    })
  },
  methods: {
    ...mapActions({
      设置类型: '进入游戏/设置类型'
    }),
    跳转游戏 (item) {
      if (this.userinfo.UserId) {
        this.设置类型(item)
      } else {
        this.$store.commit('setIsLoginShow', true)
      }
    },

    handleGoBack () {
      history.back()
    }
  }
}
</script>

<style lang="scss" scoped>
.center {
  flex: 1;
  overflow: auto;
  background: #fff;
}
list-item {
  border-bottom: 1px solid #f6f6f6;
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.025);
  padding-top: 0.28rem;
  padding-bottom: 0.28rem;
  padding-left: 0.2rem;
  .game-icon {
    width: 1.24rem;
    height: 1.24rem;
    margin-left: 0.2rem;
    margin-right: 0.2rem;
    border-radius: 18px;
    border: 1px solid #e6e6e6;
    img {
      width: 100%;
      height: 100%;
    }
  }
}
.game {
  background: #fff;
  margin-top: 0.2rem;
  width: 100%;
  //  padding-top: .28rem;
  //   padding-bottom: .28rem;
  //   padding-left: .2rem;
  &-list {
    height: 100%;
    border-bottom: 1px solid #f6f6f6;
    box-shadow: 0 1px 4px rgba(0, 0, 0, 0.025);
    overflow: hidden;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding-top: 0.28rem;
    padding-bottom: 0.28rem;
    .list-left {
      display: flex;
      align-items: center;
      padding-left: 0.2rem;
      i {
        font-size: 0.44rem;
        color: rgb(232, 232, 232);
        font-style: normal;
        font-weight: 400;
      }
      .icon-img {
        width: 1.24rem;
        height: 1.24rem;
        margin-left: 0.2rem;
        margin-right: 0.2rem;
        border-radius: 18px;
        border: 1px solid #e6e6e6;
        box-shadow: 0 1px 12px rgba(0, 0, 0, 0.12);
        position: relative;
        overflow: hidden;
        img {
          border-radius: 16px;
          margin: 0;
        }
      }
      &-info {
        h2 {
          color: #333;
          font-weight: 500;
          font-size: 0.24rem;
          margin-bottom: 3px;
        }
        p {
          color: #ccc;
          font-size: 0.22rem;
        }
      }
    }
    .list-right {
      display: flex;
      justify-content: flex-end;
      height: 100%;
      button {
        border: 1px solid #bcd4f5;
        color: #75a4e5;
        margin-right: 0.15rem;
        background-image: linear-gradient(180deg, #f9fbfe, #eef4fb);
        border-radius: 0.34rem;
        width: 1.46rem;
        height: 0.6rem;
        text-align: center;
        font-size: 0.22rem;
      }
      .btn-start {
        background-image: linear-gradient(180deg, #ff2549, #ff9280);
        color: #fff;
        border: none;
      }
    }
  }
}
</style>
