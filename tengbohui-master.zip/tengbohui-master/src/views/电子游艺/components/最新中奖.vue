<template>
  <div class="new-win boxshadow">
    <div class="group-title">
      <label>最新中奖</label>
    </div>
    <div class="win-games">
      <van-swipe :show-indicators="false"
                 :autoplay="3000">
        <van-swipe-item>
          <div class="win-game-list fl"
               v-for="(item,index) in 最新中奖[0].children"
               :key="index"
               @click="跳转游戏(item)">
            <div class="list-pic">
              <img :src="`images/电游平台/${item.type}/${item.id}${item.ext}`"
                   alt="">
            </div>
            <h2>{{item.title}}</h2>
            <p>{{item.user}}</p>
            <p class="bottom">
              <i class="iconfont">&#xe651;
              </i>
              <span>{{item.money}}</span>
            </p>
          </div>

        </van-swipe-item>
        <van-swipe-item>
          <div class="win-game-list fl"
               v-for="(item,index) in 最新中奖[1].children"
               :key="index"
               @click="跳转游戏(item)">
            <div class="list-pic">
              <img :src="`images/电游平台/${item.type}/${item.id}${item.ext}`"
                   alt="">
            </div>
            <h2>{{item.title}}</h2>
            <p>{{item.user}}</p>
            <p class="bottom">
              <i class="iconfont">&#xe651;
              </i>
              <span>{{item.money}}</span>
            </p>
          </div>
        </van-swipe-item>
      </van-swipe>
    </div>

  </div>
</template>

<script>
import { mapActions, mapState } from 'vuex';

export default {
  data () {
    return {
      最新中奖: config.最新中奖
    }
  },
  computed: {
    ...mapState({
      config: 'config',
      userinfo: x => x.user.userinfo
    })
  },
  methods: {
    ...mapActions({
      设置类型: '进入游戏/设置类型'
    }),
    跳转游戏 (item) {
      if (this.userinfo.UserId) {
        this.设置类型(item)
      } else {
        this.$store.commit('setIsLoginShow', true)
      }
    },
  },

}
</script>

<style lang="scss" scoped>
.new-win {
  margin-top: 0.2rem;
  .group-title {
    width: 100%;
    background-color: #fff;
    position: relative;
    border-bottom: 1px solid #f0f0f0;
    overflow: hidden;
    label {
      font-size: 0.26rem;
      margin: 0.3rem 0;
      display: inline-block;
      color: #444;
      padding-left: 0.18rem;
      border-left: 4px solid #ff3a2b;
    }
  }
  .win-games {
    background: #fff;
    height: 3rem;
    .van-swipe {
      height: 100%;
    }
    .van-swipe-item {
      display: flex;
      justify-content: space-around;
    }
    .win-game-list {
      padding-top: 0.3rem;
      box-sizing: border-box;
      width: 1.87rem;
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      .list-pic {
        width: 1.24rem;
        height: 1.24rem;
        border-radius: 18px;
        img {
          width: 100%;
          height: 100%;
          border-radius: 18px;
        }
      }
      i {
        color: #fff;
      }
      h2 {
        font-weight: 500;
        font-size: 0.22rem;
        color: #333;
      }

      p {
        font-weight: 500;
        font-size: 0.22rem;
        color: #bbb;
        span {
          width: auto;
          overflow: hidden;
          padding-left: 5px;
          color: #fff;
          padding-right: 5px;
        }
      }
      .bottom {
        display: flex;
        background-image: linear-gradient(90deg, #ff6c44, #ff5144);
        border-radius: 0.36rem;
        align-items: center;
        height: 0.36rem;
        line-height: 0.38rem;
      }
    }
  }
}
</style>
