<template>
  <div>
    <!-- ag电子 -->
    <div class="game">
      <div class="game-banner borderBox"
           @click="$router.push('/eGames/agdz')">
        <img src="images/AG-电子.jpg"
             alt=""
             class="wh">
      </div>
      <div class="game-list"
           v-for="(item,index) in ag电子"
           :key="index">
        <div class="list-left fl">
          <i class="iconfont">&#xe606;</i>
          <div class="icon-img">
            <img v-lazy="`images/电游平台/${item.type}/${item.imgid}.jpg`"
                 alt=""
                 class="wh">
          </div>
          <div class="list-left-info">
            <h2>{{item.title}}</h2>
            <p>{{item.type}}电游平台</p>
          </div>
        </div>
        <div class="list-right fr">
          <button @click="免费试玩()">试玩</button>
          <button class="btn-start"
                  @click="跳转游戏(item)">开始游戏</button>
        </div>
      </div>

    </div>
    <!-- ag街机 -->
    <div class="game">
      <div class="game-banner borderBox"
           @click="$router.push('/eGames/agjj')">
        <img src="images/AG-街机.jpg"
             alt=""
             class="wh">
      </div>
      <div class="game-list"
           v-for="(item,index) in ag街机"
           :key="index">
        <div class="list-left fl">
          <i class="iconfont">&#xe606;</i>
          <div class="icon-img">
            <img v-lazy="`images/电游平台/${item.type}/${item.imgid}.jpg`"
                 alt=""
                 class="wh">
          </div>
          <div class="list-left-info">
            <h2>{{item.title}}</h2>
            <p>{{item.type}}街机平台</p>
          </div>
        </div>
        <div class="list-right fr">
          <button @click="免费试玩()">试玩</button>
          <button class="btn-start"
                  @click="跳转游戏(item)">开始游戏</button>
        </div>
      </div>

    </div>
    <!-- mg电子 -->
    <div class="game">
      <div class="game-banner borderBox"
           @click="$router.push('/eGames/mgdz')">
        <img src="images/MG-电子.jpg"
             alt=""
             class="wh">
      </div>
      <div class="game-list"
           v-for="(item,index) in mg电子"
           :key="index">
        <div class="list-left fl">
          <i class="iconfont">&#xe606;</i>
          <div class="icon-img">
            <img v-lazy="`images/电游平台/${item.type}/${item.imgid}.png`"
                 alt=""
                 class="wh">
          </div>
          <div class="list-left-info">
            <h2>{{item.title}}</h2>
            <p>{{item.type}}平台</p>
          </div>
        </div>
        <div class="list-right fr">
          <button @click="免费试玩()">试玩</button>
          <button class="btn-start"
                  @click="跳转游戏(item)">开始游戏</button>
        </div>
      </div>

    </div>

    <!-- bbin电子 -->
    <div class="game">
      <div class="game-banner borderBox"
           @click="$router.push('/eGames/bbin')">
        <img src="images/BBIN-电子.jpg"
             alt=""
             class="wh">
      </div>
      <div class="game-list"
           v-for="(item,index) in bbin电子"
           :key="index">
        <div class="list-left fl">
          <i class="iconfont">&#xe606;</i>
          <div class="icon-img">
            <img v-lazy="`images/电游平台/${item.type}/${item.imgid}.jpg`"
                 alt=""
                 class="wh">
          </div>
          <div class="list-left-info">
            <h2>{{item.title}}</h2>
            <p>BBIN平台</p>
          </div>
        </div>
        <div class="list-right fr">
          <button @click="免费试玩()">试玩</button>
          <button class="btn-start"
                  @click="跳转游戏(item)">开始游戏</button>
        </div>
      </div>

    </div>

    <!-- bg电子 -->
    <div class="game">
      <div class="game-banner borderBox"
           @click="$router.push('/eGames/bgdz')">
        <img src="images/BG-电子.jpg"
             alt=""
             class="wh">
      </div>
      <div class="game-list"
           v-for="(item,index) in bg电子"
           :key="index">
        <div class="list-left fl">
          <i class="iconfont">&#xe606;</i>
          <div class="icon-img">
            <img v-lazy="`images/电游平台/${item.type}/${item.imgid}.png`"
                 alt=""
                 class="wh">
          </div>
          <div class="list-left-info">
            <h2>{{item.title}}</h2>
            <p>{{item.type}}平台</p>
          </div>
        </div>
        <div class="list-right fr">
          <button @click="免费试玩()">试玩</button>
          <button class="btn-start"
                  @click="跳转游戏(item)">开始游戏</button>
        </div>
      </div>

    </div>

    <!-- 泛亚电竞 -->
    <div class="game">
      <div class="game-banner borderBox"
           @click="$router.push('/eGames/fydj')">
        <img src="images/泛亚电竞.jpg"
             alt=""
             class="wh">
      </div>
      <div class="game-list"
           v-for="(item,index) in 泛亚电竞"
           :key="index">
        <div class="list-left fl">
          <i class="iconfont">&#xe606;</i>
          <div class="icon-img">
            <img v-lazy="`images/电游平台/${item.type}/${item.imgid}.png`"
                 alt=""
                 class="wh">
          </div>
          <div class="list-left-info">
            <h2>{{item.title}}</h2>
            <p>泛亚电竞平台</p>
          </div>
        </div>
        <div class="list-right fr">
          <button @click="免费试玩()">试玩</button>
          <button class="btn-start"
                  @click="跳转游戏(item)">开始游戏</button>
        </div>
      </div>

    </div>

    <!-- fg电子 -->
    <div class="game">
      <div class="game-banner borderBox"
           @click="$router.push('/eGames/fgdz')">
        <img src="images/FG-电子.jpg"
             alt=""
             class="wh">
      </div>
      <div class="game-list"
           v-for="(item,index) in fg电子"
           :key="index">
        <div class="list-left fl">
          <i class="iconfont">&#xe606;</i>
          <div class="icon-img">
            <img v-lazy="`images/电游平台/${item.type}/${item.imgid}.png`"
                 alt=""
                 class="wh">
          </div>
          <div class="list-left-info">
            <h2>{{item.title}}</h2>
            <p>{{item.type}}平台</p>
          </div>
        </div>
        <div class="list-right fr">
          <button @click="免费试玩()">试玩</button>
          <button class="btn-start"
                  @click="跳转游戏(item)">开始游戏</button>
        </div>
      </div>

    </div>

    <!-- 哈巴电游 -->
    <div class="game">
      <div class="game-banner borderBox"
           @click="$router.push('/eGames/hbdy')">
        <img src="images/HB-电游.jpg"
             alt=""
             class="wh">
      </div>
      <div class="game-list"
           v-for="(item,index) in 哈巴电游"
           :key="index">
        <div class="list-left fl">
          <i class="iconfont">&#xe606;</i>
          <div class="icon-img">
            <img v-lazy="`images/电游平台/${item.type}/${item.imgid}.png`"
                 alt=""
                 class="wh">
          </div>
          <div class="list-left-info">
            <h2>{{item.title}}</h2>
            <p>{{item.type}}平台</p>
          </div>
        </div>
        <div class="list-right fr">
          <button @click="免费试玩()">试玩</button>
          <button class="btn-start"
                  @click="跳转游戏(item)">开始游戏</button>
        </div>
      </div>

    </div>
  </div>
</template>

<script>
import { mapActions, mapState } from 'vuex';
import { Toast } from 'vant';
import { api_登录试玩 } from '@/api/登录接口.js';
export default {
  data () {
    return {
      ag电子: [],
      ag街机: [],
      mg电子: [],
      bbin电子: [],
      bg电子: [],
      泛亚电竞: [],
      fg电子: [],
      哈巴电游: [],
    }
  },
  computed: {
    ...mapState({
      config: 'config',
      userinfo: x => x.user.userinfo
    })
  },
  created () {
    this.$axios.get('json/home.json').then(x => {
      let list = x.data[2].children
      this.ag电子 = _.sampleSize(list[0].children, 10)
      this.ag街机 = _.sampleSize(list[1].children, 10)
      this.mg电子 = _.sampleSize(list[2].children, 10)
      this.bbin电子 = _.sampleSize(list[3].children, 10)
      this.bg电子 = _.sampleSize(list[4].children, 10)
      this.泛亚电竞 = _.sampleSize(list[5].children, 10)
      this.fg电子 = _.sampleSize(list[6].children, 10)
      this.哈巴电游 = _.sampleSize(list[7].children, 10)
    })
  },
  methods: {
    ...mapActions({
      设置类型: '进入游戏/设置类型',
      获取平台余额: '进入游戏/获取平台余额',
      getUserInfo: 'user/getUserInfo'
    }),
    跳转游戏 (item) {
      if (this.userinfo.UserId) {
        this.设置类型(item)
      } else {
        this.$store.commit('setIsLoginShow', true)
      }
    },
    async 免费试玩 () {
      if (this.userinfo.UserId) {
        this.$toast('请先退出当前账号')
        return;
      }
      var r = await api_登录试玩()
      if (r.data.code == 0) {
        this.$toast('登录成功')
        this.getUserInfo()
        // this.获取平台余额()
      } else {
        this.$toast(r.data.msg)
      }
    },

  }
}
</script>

<style lang="scss" scoped>
.game {
  background: #fff;
  margin-top: 0.2rem;
  &-banner {
    width: 100%;
    padding: 0.18rem 0.14rem 0.06rem 0.14rem;
  }
  &-list {
    padding-top: 0.28rem;
    padding-bottom: 0.28rem;
    padding-left: 0.2rem;
    border-bottom: 1px solid #f6f6f6;
    box-shadow: 0 1px 4px rgba(0, 0, 0, 0.025);
    overflow: hidden;
    display: flex;
    align-items: center;
    justify-content: space-between;
    .list-left {
      display: flex;
      align-items: center;
      i {
        font-size: 0.44rem;
        color: rgb(232, 232, 232);
        font-style: normal;
        font-weight: 400;
      }
      .icon-img {
        width: 1.24rem;
        height: 1.24rem;
        margin-left: 0.2rem;
        margin-right: 0.2rem;
        border-radius: 18px;
        border: 1px solid #e6e6e6;
        box-shadow: 0 1px 12px rgba(0, 0, 0, 0.12);
        position: relative;
        overflow: hidden;
        img {
          border-radius: 16px;
          margin: 0;
        }
      }
      &-info {
        h2 {
          color: #333;
          font-weight: 500;
          font-size: 0.24rem;
          margin-bottom: 3px;
        }
        p {
          color: #ccc;
          font-size: 0.22rem;
        }
      }
    }
    .list-right {
      display: flex;
      justify-content: flex-end;
      height: 100%;
      button {
        border: 1px solid #bcd4f5;
        color: #75a4e5;
        margin-right: 0.15rem;
        background-image: linear-gradient(180deg, #f9fbfe, #eef4fb);
        border-radius: 0.34rem;
        width: 1.46rem;
        height: 0.6rem;
        text-align: center;
        font-size: 0.22rem;
      }
      .btn-start {
        background-image: linear-gradient(180deg, #ff2549, #ff9280);
        color: #fff;
        border: none;
      }
    }
  }
}
</style>
