<template>
  <div class="dzyy-platform">
    <swiper :options="swiperOption">
      <swiper-slide>
        <div class="slide-item">
          <div class="slide-item-list ">
            <div class="dzyy-container">
              <div class="dzyy-item"
                   @click="$router.push('/eGames/agdz')">
                <div class="dzyy-item-box"
                     style="background-image: linear-gradient(to right bottom, #6b83fa, #caa2fd);">
                  <img src="images/AG电子.png">
                </div>
                <p>AG电子</p>
              </div>
              <div class="dzyy-item"
                   @click="$router.push('/eGames/agjj')">
                <div class="dzyy-item-box"
                     style=" background-image: linear-gradient(to right bottom, #47c0f5, #3eeac4);">
                  <img src="images/AG电子.png">
                </div>
                <p>AG街机</p>
              </div>
              <div class="dzyy-item"
                   @click="$router.push('/eGames/mgdz')">
                <div class="dzyy-item-box"
                     style="background-image: linear-gradient(to right bottom, #ff2549, #ff8080);">
                  <img src="images/MG电子.png">
                </div>
                <p>MG电子</p>
              </div>
              <div class="dzyy-item"
                   @click="$router.push('/eGames/bbin')">
                <div class="dzyy-item-box"
                     style="background-image: linear-gradient(to right bottom, #ff9d0b, #ffdd57);">
                  <img src="images/BBIN电子.png">
                </div>
                <p>BBIN电子</p>
              </div>
            </div>
          </div>

          <div class="slide-item-list">
            <div class="dzyy-container">
              <div class="dzyy-item"
                   @click="$router.push('/eGames/bgdz')">
                <div class="dzyy-item-box"
                     style="background:linear-gradient(to right bottom,#ff7d43,#ffa555)">
                  <img src="images/BG电子.png">
                </div>
                <p>BG电子</p>
              </div>
              <div class="dzyy-item"
                   @click="$router.push('/eGames/fydj')">
                <div class="dzyy-item-box"
                     style="background:linear-gradient(to right bottom,#4d90ff,#87d3ff)">
                  <img src="images/泛亚电竞.png">
                </div>
                <p>泛亚电竞</p>
              </div>
              <div class="dzyy-item"
                   @click="$router.push('/eGames/fgdz')">
                <div class="dzyy-item-box"
                     style="background-image: linear-gradient(to right bottom,#a313cd,#d74dff);">
                  <img src="images/FG电子.png">
                </div>
                <p>FG电子</p>
              </div>
              <div class="dzyy-item"
                   @click="$router.push('/eGames/hbdy')">
                <div class="dzyy-item-box"
                     style="background-image: linear-gradient(to right bottom,#66c80c,#43ff24);">
                  <img src="images/哈巴电游.png">
                </div>
                <p>哈巴电游</p>
              </div>
            </div>
          </div>
        </div>
      </swiper-slide>
      <swiper-slide>
        <div class="slide-item">
          <div class="slide-item-list ">
            <div class="dzyy-container">
              <div class="dzyy-item"
                   @click="$router.push('/eGames/lydz')">
                <div class="dzyy-item-box"
                     style="background-image: linear-gradient(to right bottom, #6b83fa, #caa2fd);">
                  <img src="images/乐游电子.png">
                </div>
                <p>乐游电子</p>
              </div>
              <div class="dzyy-item"
                   @click="$router.push('/eGames/cq9dz')">
                <div class="dzyy-item-box"
                     style=" background-image: linear-gradient(to right bottom, #47c0f5, #3eeac4);">
                  <img src="images/CQ9电子.png">
                </div>
                <p>CQ9电子</p>
              </div>
              <div class="dzyy-item"
                   @click="$router.push('/eGames/swdz')">
                <div class="dzyy-item-box"
                     style="background-image: linear-gradient(to right bottom, #ff2549, #ff8080);">
                  <img src="images/SW电子.png">
                </div>
                <p>SW电子</p>
              </div>
              <!-- 占位子 -->
              <div class="dzyy-item">
                <div class="dzyy-item-box">
                </div>
              </div>

            </div>
          </div>

        </div>
      </swiper-slide>

      <div class="swiper-pagination"
           slot="pagination"></div>
    </swiper>
  </div>
</template>

<script>
export default {
  data () {
    return {
      swiperOption: {
        loop: true,
        pagination: {
          el: '.swiper-pagination'
        }
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.dzyy-platform {
  padding-top: 0.25rem;
  padding-bottom: 0.25rem;
  box-shadow: 0 1px 0.25rem rgba(0, 0, 0, 0.06);
  background-color: #fff;
  width: 100%;
}
.swiper-container {
  height: 100%;
}
.slide-item {
  .item-list {
    width: 50px;
    height: 50px;
    background: red;
  }
  .item-box {
    background: red;
  }
}
.swiper-pagination-bullet-active {
  background: #ff0005;
}

.dzyy-container {
  padding-bottom: 0.2rem;
  display: flex;
  background-color: #fff;
  text-align: center;
  justify-content: space-around;
  .dzyy-item-box {
    width: 1.08rem;
    height: 1.08rem;
    line-height: 1.08rem;
    border-radius: 38%;
  }

  img {
    width: 100%;
    height: 100%;
    line-height: 0.76rem;
    font-size: 0.4rem;
  }
  p {
    line-height: 0.48rem;
    color: #444;
    font-size: 0.24rem;
    height: 0.64rem;
  }
}

.swiper-pagination-bullets {
  bottom: 0;
}
</style>
