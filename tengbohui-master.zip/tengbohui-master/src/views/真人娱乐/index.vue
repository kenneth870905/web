<template>

  <div class="layout-box">
    <div class="layout-header">
      <appHeader headTitle="真人娱乐" />
    </div>
    <div class="liveCasino">
      <div class="liveCasino-panel"
           v-for="(item,index) in list"
           :key="index"
           @click="跳转游戏(item)">
        <div class="panel-baner">
          <div class="banner-box">
            <img :src="item.img"
                 alt="">
          </div>
        </div>
        <div class="liveCasino-text">
          <div class="text-left">
            <div class="left-icon">
              <img :src="`images/真人娱乐/${item.type}/${item.id}.png`" />
            </div>
            <h2>{{item.title}}</h2>
            <p>{{item.desc}}</p>
          </div>
          <div class="text-right">
            <i class="iconfont">&#xe63b;</i>
          </div>
        </div>
      </div>

    </div>

    <div class="layout-footer">
      <appFooter />
    </div>
  </div>
</template>

<script>
import appHeader from '@/components/头部';
import appFooter from '@/components/尾部';
import { mapState, mapActions } from 'vuex';

export default {
  data () {
    return {
      list: [
        {
          type: 'AG',
          img: 'images/真人娱乐/ag_1.png',
          title: 'AG国际厅',
          id: '2',
          desc: '现场360度视角，实时显示输赢排行榜'
        },
        {
          type: 'AG',
          img: 'images/真人娱乐/ag_2.png',
          title: 'AG旗舰厅',
          id: '1',
          desc: '独创6张牌先发，全球首创，多种创新玩法'
        },
        {
          type: 'BY',
          img: 'images/真人娱乐/bg.png',
          title: 'BG视讯大厅',
          id: 'live',
          desc: '现场360度视角，实时显示输赢排行榜'
        },
        {
          type: 'BG',
          img: 'images/真人娱乐/bbin.png',
          title: '波音厅',
          id: '1',
          desc: '体验多桌同时投注，让您乐在其中'
        }
      ]
    }
  },
  components: {
    appHeader,
    appFooter
  },
  computed: {
    ...mapState({
      userinfo: x => x.user.userinfo
    })
  },
  methods: {
    ...mapActions({
      设置类型: '进入游戏/设置类型'
    }),
    跳转游戏 (item) {
      if (this.userinfo.UserId) {
        this.设置类型(item)
      } else {
        this.$store.commit('setIsLoginShow', true)
      }
    },

  },
  created () {
    this.$axios.get('json/home.json').then(x => {
      var list = x.data[2].children
      list.forEach(item => {
        if (item.title === 'AG电子') {
          return item
        }
      })
      console.log(list)
    })
  }
}
</script>

<style lang="scss" scoped>
.liveCasino {
  flex: 1;
  overflow-x: scroll;
  &-panel {
    width: 96%;
    background: #fff;
    margin-left: 2%;
    margin-top: 0.2rem;
    .panel-baner {
      width: 100%;
      padding: 0.1rem 0.1rem 0.08rem 0.1rem;
      box-sizing: border-box;
      .banner-box {
        width: 100%;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
        img {
          width: 100%;
        }
      }
    }
  }
  &-text {
    padding: 0.2rem;
    box-sizing: border-box;
    overflow: hidden;
    margin-bottom: 0.24rem;
    .text-left {
      width: 90%;
      float: left;
      .left-icon {
        width: 0.88rem;
        height: 0.88rem;
        line-height: 0.88rem;
        border-radius: 40%;
        text-align: center;
        margin-right: 0.24rem;
        float: left;
        background-image: linear-gradient(to right bottom, #47c0f5, #3eeac4);
        img {
          width: 100%;
          height: 100%;
          border-radius: 40%;
        }
      }
      h2 {
        color: #333;
        font-size: 0.3rem;
        line-height: 0.4rem;
        font-weight: 500;
      }
      p {
        color: #bbb;
        font-size: 0.22rem;
        line-height: 0.32rem;
        margin-bottom: 0.1rem;
        white-space: nowrap;
        text-overflow: ellipsis;
        overflow: hidden;
      }
    }
    .text-right {
      float: right;
      margin-top: 0.1rem;
      i {
        font-size: 0.44rem;
        color: rgb(204, 204, 204);
      }
    }
  }
}
</style>
