<template>
  <div>
    <van-nav-bar :title="titleType + '转账'"
                 left-arrow
                 left-text="返回"
                 @click-left="onClickLeft" />

    <div class="deposit-title">
      <label>收款方信息</label>
    </div>

    <van-cell v-if="!选中账户">
      <template slot="title">
        <div class="m-cell">
          <div class="cell-item">
            <p @click="选择卡(item)"
               v-for="(item, index) in list.Alipays"
               :key="index"
               class="dzxk_txt">
              <span style="font-weight: bold;">{{item.Account}}</span>
              <br />
              <span>{{item.UserName}}</span>

              <br />
              <span>{{item.Note}}</span>
            </p>
            <van-icon name="arrow"
                      class="icon-right" />
          </div>
        </div>
      </template>
    </van-cell>

    <div v-if="选中账户">
      <div class="m-cell">
        <div class="cell-item">
          <div class="cell-left">收款银行</div>
          <div class="cell-right">{{选中账户.Note.split('：')[1]}}</div>
        </div>
      </div>

      <div class="m-cell">
        <div class="cell-item">
          <div class="cell-left">帐(卡)号</div>
          <div class="cell-right">
            {{选中账户.UserName.split('：')[1]}}
            <span @click="复制(选中账户.UserName.split('：')[1])">复制</span>
          </div>
        </div>
      </div>

      <div class="m-cell">
        <div class="cell-item">
          <div class="cell-left">姓名</div>
          <div class="cell-right">
            {{选中账户.Account.split('：')[1]  }}
            <span @click="复制(选中账户.Account.split('：')[1])">复制</span>
          </div>
        </div>
      </div>

      <div class="deposit-title"
           style="margin-top:0.16rem;">
        <label>付款方信息(请转账后填写)</label>
      </div>

      <div class="m-cell">
        <div class="cell-item">
          <div class="cell-left">付款姓名</div>
          <div class="cell-right">
            <input type="text"
                   placeholder="请输入您的付款人姓名"
                   v-model="transferUserName">
          </div>
        </div>
      </div>

      <div class="m-cell">
        <div class="cell-item">
          <div class="cell-left">付款金额</div>
          <div class="cell-right">
            <input type="text"
                   v-model="amount"
                   placeholder="请输入您的付款金额">
          </div>
        </div>
      </div>

      <div class="m-cell">
        <div class="cell-item">
          <div class="cell-left">付款标识</div>
          <div class="cell-right">
            <input type="text"
                   v-model="transferAccount"
                   placeholder="请输入您的付款标识">
          </div>
        </div>
      </div>
      <button class="btn"
              @click="提交()">提交</button>
    </div>

  </div>
</template>

<script>
import { api_电子转账账号, api_网银转账 } from '@/api/资金接口.js';
import { Toast } from 'vant';
export default {
  data () {
    return {
      titleType: '',
      list: [],
      选中账户: '',
      type: '',
      transferUserName: '', // 姓名
      amount: '', // 金额
      transferAccount: '' // 交易标识
    }
  },
  methods: {
    复制 (text) {
      this.$copyText(text).then(
        e => {
          this.$toast('复制成功')
        },
        e => {
          this.$toast('复制失败，请手动复制')
        }
      )
    },
    onClickLeft () {
      this.$router.go(-1)
    },
    选择卡 (item) {
      this.选中账户 = item
    },
    提交 () {
      var min = this.选中账户.Min ? this.选中账户.Min : this.list.MinAccount
      var max = this.选中账户.Max ? this.选中账户.Max : this.list.MaxAccount
      console.log(min, max)

      if (!this.transferUserName) {
        Toast('请输入姓名')
        return;
      } else if (!this.amount) {
        Toast('请输入金额')
        return;
      } else if (this.amount < min || this.amount > max) {
        Toast('金额必须在' + min + '到' + max + '之间')
        return;
      }

      var obj = {
        alipayId: this.选中账户.Id,
        payWay: this.选中账户.PayWayId,
        amount: this.amount,
        transferUserName: this.transferUserName,
        transferAccount: this.transferAccount,
        isGift: false
      }
      api_网银转账(obj)
        .then(x => {
          if (x.data.code == 0) {
            Toast('提交成功')
            history.back()
          } else {
            Toast(x.data.msg)
          }
        })
        .catch(err => {})
    }
  },
  mounted () {
    var id = this.$route.query.id
    var query = {
      type: ''
    }
    if (id == 'alipay') {
      query.type = '支付宝';
    } else if (id == 'wechat') {
      query.type = '微信';
    } else if (id == 'cloudpay') {
      query.type = '云闪付';
    }
    this.type = query.type
    api_电子转账账号(query)
      .then(x => {
        this.list = x.data
        this.titleType = this.list.Alipays[0].Type
      })
      .catch(err => {})
  }
}
</script>
<style lang="scss" scoped>
.deposit-title {
  width: 100%;
  background-color: #fff;
  border-bottom: 1px solid #f2f2f2;
  box-shadow: 0 0 8px rgba(0, 0, 0, 0.05);
  margin-bottom: 0.16rem;
}
label {
  display: inline-block;
  font-size: 0.26rem;
  margin: 0.3rem 0;
  padding-left: 0.15rem;
  border-left: 5px solid #ff3a2b;
  color: #888;
}
.m-cell {
  padding-left: 0.24rem;
  display: flex;
  border-bottom: 1px solid #f2f2f2;
  font-size: 0.26rem;
  color: #666;
  background: #fff;
}
.cell-item {
  width: 100%;
  display: flex;
  align-items: center;
  min-height: 1.2rem;
  position: relative;
}
p {
  width: 100%;
}
.cell-left {
  width: 2rem;
}
.cell-right {
  flex: 1;
  padding-right: 0.24rem;
  display: flex;
  justify-content: space-between;
  align-items: center;
  span {
    min-width: 1rem;
    border: 0;
    background-color: #56cc77;
    color: #fff;
    padding: 0.1rem 0.1rem;
    border-radius: 2px;
    display: block;
    text-align: center;
  }
  input {
    border: none;
  }
}

.btn {
  width: 5rem;
  height: 0.76rem;
  background: #56cc77;
  border-radius: 0.12rem;
  color: white;
  margin: 35px auto;
  border: none;
  display: block;
  font-size: 0.26rem;
}
.icon-right {
  position: absolute;
  right: 0;
  font-size: 0.36rem;
}
</style>
