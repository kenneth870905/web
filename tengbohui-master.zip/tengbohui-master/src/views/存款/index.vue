<template>
  <div class="layout-box">
    <div class="layout-header">
      <van-nav-bar title="会员存款"
                   left-arrow
                   left-text="返回"
                   @click-left="$router.go(-1)" />
    </div>
    <div class="deposit">
      <div class="deposit-title">
        <label>请选中存款方式</label>
      </div>

      <p class="chongzhi_txt">手机转账 Mobile transfer</p>
      <div>
        <van-cell @click="跳转选卡(item)"
                  v-for="(item, index) in 充值类型.Transfer"
                  :key="index"
                  :icon="`images/支付/${item.Id}.png`"
                  :title="item.Title"
                  is-link
                  clickable />
      </div>
      <!-- <van-cell icon="van-icon van-icon-chat" title="微信转账" is-link /> -->
      <p class="chongzhi_txt">在线支付 Online Payment</p>
      <van-cell @click="跳转选卡(item)"
                v-for="(item, index) in 充值类型.Online"
                :key="index"
                :icon="`images/支付/${item.Id}.png`"
                :title="item.Title"
                is-link />
    </div>
  </div>

</template>

<script>
import { api_获取充值类型接口 } from '@/api/资金接口.js';
import { Toast } from 'vant';

export default {
  data () {
    return {
      充值类型: {
        AuditRecharge: null,
        Online: [],
        Transfer: []
      }
    }
  },
  methods: {
    跳转选卡 (item) {
      if (item.Type == 'wyzz') {
        // 网银选卡
        if (this.充值类型.AuditRecharge) {
          Toast('您已提交过申请，请等待审核')
        } else {
          this.$router.push('/wyxk?id=' + item.Id)
        }
      } else if (item.Type == 'dzzz') {
        if (this.充值类型.AuditRecharge) {
          Toast('您已提交过申请，请等待审核')
        } else {
          // 电子选卡
          this.$router.push('/dzxk?id=' + item.Id)
        }
      } else {
        this.$router.push('/zxxk?id=' + item.Id)
      }
    }
  },
  mounted () {
    api_获取充值类型接口()
      .then(x => {
        this.充值类型 = x.data
      })
      .catch(err => {
        console.log(err)
      })
  }
}
</script>

<style lang="scss" scoped>
.deposit {
  flex: 1;
  overflow-x: scroll;
  &-title {
    width: 100%;
    background-color: #fff;
    border-bottom: 1px solid #f2f2f2;
    box-shadow: 0 0 8px rgba(0, 0, 0, 0.05);
    label {
      display: inline-block;
      font-size: 0.26rem;
      margin: 0.3rem 0;
      padding-left: 0.15rem;
      border-left: 5px solid #ff3a2b;
      color: #888;
    }
  }
  .chongzhi_txt {
    padding: 0 10px;
    line-height: 0.8rem;
    color: #888;
    font-size: 14px;
  }
  .van-cell {
    align-items: center;
  }
  /deep/ .van-cell__left-icon {
    font-size: 20px;
    display: table;
  }
  .van-icon__image {
    width: 0.92rem;
    height: 0.92rem;
  }
}
</style>
