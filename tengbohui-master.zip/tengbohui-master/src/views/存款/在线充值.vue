<template>
  <div>
    <van-nav-bar title="在线充值"
                 left-arrow
                 left-text="返回"
                 @click-left="onClickLeft" />

    <div class="deposit-title"
         v-show="!当前选中">
      <label>选择支付通道</label>
    </div>

    <van-cell v-show="!当前选中">
      <template slot="title">
        <div class="m-cell">
          <div class="cell-item">
            <p @click="选择卡(item)"
               v-for="(item, index) in list"
               :key="index"
               class="dzxk_txt">
              <span style="font-weight: bold;">额度范围：{{item.Min}}~{{item.Max ? item.Max : '不限制'}}</span>
              <br />
              <span>备注：{{item.Note ? item.Note : '无'}}</span>

              <span>{{item.Khh}}</span>
            </p>
            <van-icon name="arrow"
                      class="icon-right" />
          </div>
        </div>

      </template>
    </van-cell>

    <div v-show="当前选中">
      <div class="deposit-title">
        <label>当前通道</label>
      </div>

      <div class="m-cell">
        <div class="cell-item">
          <div class="cell-left">额度范围</div>
          <div class="cell-right">
            {{当前选中.Min}}~{{当前选中.Max ? 当前选中.Max : '不限制'}}
          </div>
        </div>
      </div>

      <div class="m-cell">
        <div class="cell-item">
          <div class="cell-left">备注：</div>
          <div class="cell-right">
            {{当前选中.Note ? 当前选中.Note : '无'}}
          </div>
        </div>
      </div>
      <div class="deposit-title"
           style="margin-top:0.16rem;">
        <label>充值信息</label>
      </div>

      <div class="m-cell">
        <div class="cell-item">
          <div class="cell-left">付款金额</div>
          <div class="cell-right">
            <input type="text"
                   v-model="totalAmount"
                   placeholder="请输入您的付款金额">
          </div>
        </div>
      </div>

      <button class="btn"
              @click="提交()">确定</button>
    </div>
  </div>
</template>

<script>
import { api_在线充值账号, api_在线充值 } from '@/api/资金接口.js';
import { Toast, Dialog } from 'vant';

export default {
  data () {
    return {
      list: [],
      // loading:true,
      type: '',
      当前选中: '',

      name: '',
      totalAmount: '',
      payData: '', // 选中银行
      args: {
        qq: 'QQ钱包',
        alipay: '支付宝',
        wechat: '微信',
        cloudpay: '云闪付',
        kuaijie: '快捷支付',
        bank: '网银支付',
        jd: '京东钱包',
        ylsm: '银联扫码'
      }
    }
  },
  methods: {
    onClickLeft () {
      this.$router.go(-1)
    },
    选择卡 (item) {
      this.当前选中 = item
    },
    选择银行 () {
      var 选择器 = new mui.PopPicker()
      this.当前选中.Select.forEach(item => {
        item.text = item.Text
      })
      选择器.setData(this.当前选中.Select)
      选择器.show(items => {
        this.payData = items[0]
        选择器.dispose()
        选择器 = null
      })
    },
    提交 () {
      if (this.当前选中.Select && !this.payData) {
        Toast('请选择银行')
        return;
      } else if (!this.totalAmount) {
        Toast('请输入金额')
        return;
      } else if (this.当前选中.Min && this.当前选中.Min > this.totalAmount) {
        Toast('金额不能小于' + this.当前选中.Min)
        return;
      } else if (this.当前选中.Max && this.当前选中.Max < this.totalAmount) {
        Toast('金额不能大于' + this.当前选中.Min)
        return;
      }

      var obj = {
        payId: this.当前选中.Id,
        totalAmount: this.totalAmount,
        payData: this.payData ? this.payData.Id : ''
      }
      //this.加载中(true)
      api_在线充值(obj)
        .then(x => {
          if (x.data.code == 0) {
            if (window.plus) {
              plus.runtime.openURL(x.data.msg)
            } else if (window.webkit) {
              window.webkit.messageHandlers.FillMoney.postMessage({
                link: x.data.msg
              })
            } else {
              // Toast('极速前往充值页面', '支付', '前往支付', function () {
              // window.open(x.data.msg, '_blank');
              // });
              Dialog.confirm({
                title: '支付',
                message: '点击确定前往充值页面',
                confirmButtonColor: '#f01924'
              })
                .then(() => {
                  window.open(x.data.msg, '_blank')
                })
                .catch(() => {
                  Toast('不要走 决战到天明')
                })
            }
          } else {
            Toast(x.data.msg)
          }

          // this.加载中(false);
        })
        .catch(err => {
          // this.加载中(false);
        })
    }
  },
  mounted () {
    this.type = this.$route.query.id

    api_在线充值账号({ type: this.args[this.type] })
      .then(x => {
        this.list = x.data
        this.loading = false
      })
      .catch(err => {
        this.loading = false
      })
  }
}
</script>
<style lang="scss" scoped>
.deposit-title {
  width: 100%;
  background-color: #fff;
  border-bottom: 1px solid #f2f2f2;
  box-shadow: 0 0 8px rgba(0, 0, 0, 0.05);
  margin-bottom: 0.16rem;
}
label {
  display: inline-block;
  font-size: 0.26rem;
  margin: 0.3rem 0;
  padding-left: 0.15rem;
  border-left: 5px solid #ff3a2b;
  color: #888;
}

.m-cell {
  padding-left: 0.24rem;
  display: flex;
  border-bottom: 1px solid #f2f2f2;
  font-size: 0.26rem;
  color: #666;
  background: #fff;
}
.cell-item {
  width: 100%;
  display: flex;
  align-items: center;
  min-height: 1.2rem;
  position: relative;
}
p {
  width: 100%;
}
.cell-left {
  width: 2rem;
}
.cell-right {
  flex: 1;
  padding-right: 0.24rem;
  display: flex;
  justify-content: space-between;
  align-items: center;
  span {
    min-width: 1rem;
    border: 0;
    background-color: #56cc77;
    color: #fff;
    padding: 0.1rem 0.1rem;
    border-radius: 2px;
    display: block;
    text-align: center;
  }
  input {
    border: none;
  }
}

.btn {
  width: 5rem;
  height: 0.76rem;
  background: #56cc77;
  border-radius: 0.12rem;
  color: white;
  margin: 35px auto;
  border: none;
  display: block;
  font-size: 0.26rem;
}
.icon-right {
  position: absolute;
  right: 0;
  font-size: 0.36rem;
}
.van-cell:not(:last-child)::after {
  border: none;
}
/deep/.dialog__cancel {
  background: #fff;
}
</style>
