<template>
  <div class="layout-box">
    <div class="layout-header">
      <appHeader headTitle="体育赛事" />
    </div>
    <div class="sports">
      <div class="sports-btn">
        <!-- <img src="../../assets/images/play.9207bfcc.png"
           alt=""> -->
      </div>
      <div class="sports-banner">
        <img v-for="(item,index) in list"
             :key="item.id"
             :src="`images/体育赛事/${item.type}.jpg`"
             @click="跳转游戏(item)"
             alt="">

      </div>

    </div>
    <div class="layout-footer">
      <appFooter />
    </div>

    <!-- 弹窗 -->

  </div>

</template>

<script>
import appHeader from '@/components/头部';
import appFooter from '@/components/尾部';
import { mapState, mapActions } from 'vuex';
import { Dialog } from 'vant';
export default {
  components: {
    appHeader,
    appFooter
  },
  data () {
    return {
      list: [],
    }
  },
  created () {
    this.$axios('json/homeList.json').then(x => {
      this.list = x.data[5].children
    })
  },
  computed: {
    ...mapState({
      userinfo: x => x.user.userinfo
    })
  },
  methods: {
    ...mapActions({
      设置类型: '进入游戏/设置类型'
    }),
    跳转游戏 (item) {
      if (this.userinfo.UserId) {
        this.设置类型(item)
      } else {
        this.$store.commit('setIsLoginShow', true)
      }
    },

  }
}
</script>

<style lang="scss" scoped>
.sports {
  flex: 1;
  overflow-x: scroll;
  width: 100%;
  background: url("/images/sp-bg.05916f3b.jpg") no-repeat;
  background-color: #007337;
  background-size: 100% auto;
  padding-top: 0.88rem;
  &-btn {
    margin-top: 3.4rem;
    text-align: center;
    margin-bottom: 0.4rem;
    img {
      width: 2.4rem;
      display: inline-block;
      margin-right: 0.2rem;
    }
  }

  &-banner {
    width: 7.28rem;
    margin: 0 auto;
    img {
      width: 100%;
    }
  }
}
</style>
