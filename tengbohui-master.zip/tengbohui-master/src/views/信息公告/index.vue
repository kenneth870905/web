<template>
  <div class="layout-box">
    <div class="layout-header">
      <van-nav-bar title="信息公告"
                   left-arrow
                   left-text="返回"
                   @click-left="$router.go(-1)" />
    </div>
    <div class="notice">
      <div class="notice-box">
        <div class="notice-list">

          <div class="notice-list-item"
               v-for="(item,index) in listTitle"
               :key="item.Id"
               @click="getContent(item)">
            <h3>{{item.Title}}</h3>

            <p v-if="item.Content && item.Show"
               v-html="item.Content"
               class="slideInUp"></p>

          </div>

        </div>
      </div>
    </div>
  </div>

</template>

<script>
import { api_获取公告列表, api_公告详情 } from '@/api/公告接口.js';
export default {
  data () {
    return {
      listTitle: [],
      listData: [],
      activeNames: ['0']
    }
  },
  created () {
    api_获取公告列表().then(x => {
      this.listTitle = x.data
    })
  },
  methods: {
    getContent (item) {
      console.log(item)
      if (item.Show) {
        item.Show = !item.Show
      } else {
        if (item.Content) {
          item.Show = true
        } else {
          api_公告详情({ Id: item.Id })
            .then(x => {
              this.$set(item, 'Content', x.data)
              this.$set(item, 'Show', true)
            })
            .catch(err => {})
        }
      }
    }
  }
}
</script>

<style lang="scss" scoped>
@-webkit-keyframes slideInUp {
  from {
    -webkit-transform: translate3d(0, 100%, 0);
    transform: translate3d(0, 100%, 0);
    visibility: visible;
  }

  to {
    -webkit-transform: translate3d(0, 0, 0);
    transform: translate3d(0, 0, 0);
  }
}

@keyframes slideInUp {
  from {
    -webkit-transform: translate3d(0, 100%, 0);
    transform: translate3d(0, 100%, 0);
    visibility: visible;
  }

  to {
    -webkit-transform: translate3d(0, 0, 0);
    transform: translate3d(0, 0, 0);
  }
}

.slideInUp {
  -webkit-animation-name: slideInUp;
  animation-name: slideInUp;
  animation-duration: 0.5s;
}
.notice {
  line-height: 0.88rem;
  height: 100%;
  flex: 1;
  overflow-x: scroll;
}
.notice-box {
  background: #fff;
  padding-bottom: 0.4rem;
  margin-bottom: -0.5rem;
  height: 100%;
}
.notice-list {
  padding: 0.15rem 0.25rem 0 0.25rem;
  font-size: 0.24rem;
  color: #666;
}
.notice-list-item {
  width: 100%;
  h3 {
    font-size: 0.26rem;
    color: #444;
    margin: 0 0 0 0.2rem;
    font-weight: 600;
    border-bottom: 1px solid #eee;
  }
  p {
    background: #f2f2f2;
    padding: 0.25rem 0.2rem;
    border-radius: 12px;
    line-height: 0.4rem;
    color: #999;
    font-size: 0.24rem !important;
    margin-bottom: 0.3rem;
    line-height: initial;
  }
}
</style>
