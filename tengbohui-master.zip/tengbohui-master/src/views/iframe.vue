<template>
<div v-if="src" class="mui-fullscreen">
  <iframe :src="src" frameborder="0"></iframe>
</div>
</template>

<script>
import {
  mapState
} from 'vuex'
export default {
  name: '',
  data () {
    return {
      src: '',
      urlList: {
        qd: '/M/System/SignIn',
        ShouChong: '/Html/ShouChong/',
        vipbet: '/html/vipbet/',
        liuheHongbao: '/Html/MarkSix/' // 六合红包 ， 刮刮乐
        // liuheHongbao: "/Html/1/",       //六合红包 ， 刮刮乐
      }
    }
  },
  computed: {
    ...mapState({
      config: 'config'
    })
  },
  methods: {
    设置地址 () {}
  },
  mounted () {
    // /M/System/SignIn
    console.log(this.$route)
    if (this.$route.query.u) {
      var u = this.$route.query.u
      if (u == 1) {
        this.src = this.config.api_url + '/Html/1/index.html?back=1'
      } else {
        u = u.startsWith('http') ? u : this.config.api_url + u
        this.src = u + '?back=1'
      }
      // var u = this.$route.query.u;
    } else {
      var type = this.$route.params.type
      this.src = config.iframe_url + this.urlList[type]
    }
  }
}
</script>

<style lang="scss" scoped>
iframe {
  width: 100%;
  height: 100%;
}
</style>
