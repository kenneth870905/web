<template>
  <div class="layout-box">
    <div class="layout-header">
      <appHeader headTitle="优惠活动" />
    </div>
    <div class="discount">
      <div class="discount-panel "
           v-for="(item,index) in resData"
           :key="index"
           @click="info(item,index)">
        <div class="panel-baner">
          <div class="banner-box">
            <img :src="item.Img"
                 alt="">
          </div>
        </div>
        <div class="discount-text ">
          <div class="text-left">
            <h2>{{item.Name}}</h2>
            <p>{{item.Summary}}</p>
          </div>
          <!-- <div class="text-right">
            <i class="iconfont icon-right"></i>
          </div> -->
          <div v-if="item.Content && item.Show"
               v-html="item.Content"
               class="zoomIn"></div>
        </div>
      </div>
    </div>
    <div class="layout-footer">
      <appFooter />
    </div>
  </div>

</template>

<script>
import appHeader from '@/components/头部';
import appFooter from '@/components/尾部';

import { api_获取优惠列表, api_优惠列表详情 } from '@/api/优惠接口.js';
export default {
  components: {
    appHeader,
    appFooter
  },
  data () {
    return {
      resData: [],
      transition: false
    }
  },
  created () {
    api_获取优惠列表().then(x => {
      this.resData = x.data
    })
  },
  methods: {
    info (item) {
      if (item.Show) {
        item.Show = !item.Show
      } else {
        if (item.Content) {
          item.Show = true
        } else {
          api_优惠列表详情({ Id: item.Id })
            .then(x => {
              this.$set(item, 'Content', x.data)
              this.$set(item, 'Show', true)
            })
            .catch(err => {})
        }
      }
    }
  }
}
</script>

<style lang="scss" scoped>
@-webkit-keyframes zoomIn {
  from {
    opacity: 0;
    -webkit-transform: scale3d(0.3, 0.3, 0.3);
    transform: scale3d(0.3, 0.3, 0.3);
  }

  50% {
    opacity: 1;
  }
}

@keyframes zoomIn {
  from {
    opacity: 0;
    -webkit-transform: scale3d(0.3, 0.3, 0.3);
    transform: scale3d(0.3, 0.3, 0.3);
  }

  50% {
    opacity: 1;
  }
}

.zoomIn {
  -webkit-animation-name: zoomIn;
  animation-name: zoomIn;
  animation-duration: 0.5s;
}

.discount {
  flex: 1;
  overflow-x: scroll;
  &-panel {
    width: 96%;
    background: #fff;
    margin-left: 2%;
    margin-top: 0.2rem;
    .panel-baner {
      width: 100%;
      padding: 0.1rem 0.1rem 0.08rem 0.1rem;
      box-sizing: border-box;
      .banner-box {
        width: 100%;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
        img {
          width: 100%;
        }
      }
    }
  }
  &-text {
    padding: 0.2rem;
    box-sizing: border-box;
    overflow: hidden;
    .text-left {
      width: 100%;
      float: left;
      h2 {
        color: #333;
        font-size: 0.3rem;
        line-height: 0.4rem;
        font-weight: 500;
      }
      p {
        color: #bbb;
        font-size: 0.22rem;
        line-height: 0.32rem;
        margin-bottom: 0.1rem;
        white-space: nowrap;
        text-overflow: ellipsis;
        overflow: hidden;
      }
    }
    .text-right {
      float: right;
      margin-top: 0.1rem;
      i {
        font-size: 0.44rem;
        color: rgb(204, 204, 204);
      }
    }
  }
}
</style>
