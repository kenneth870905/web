<template>
  <div class="layout-box">
    <div class="layout-header">
      <van-nav-bar title="会员注册"
                   left-arrow
                   left-text="返回"
                   @click-left="$router.go(-1)" />
    </div>
    <div class="register">
      <div class="register-container">
        <!-- 预留 -->
        <div class="cont">
          <div class="m-cell-box">
            <div class="m-cell">
              <div class="cell-item">
                <div class="cell-left">
                  <span>登录账号</span>
                </div>
                <div class="cell-right">
                  <div class="m-input">
                    <van-field v-model="user.uid"
                               type="text"
                               center
                               clearable
                               maxlength="20"
                               placeholder="请输入您的用户名或手机号"
                               ref="uid">
                    </van-field>
                  </div>
                </div>
              </div>

              <div class="cell-item"
                   v-if="!isphone">
                <div class="cell-left">
                  <span>登录密码</span>
                </div>
                <div class="cell-right">
                  <div class="m-input">

                    <van-field v-model="user.pwd"
                               type="password"
                               center
                               clearable
                               maxlength="20"
                               placeholder="请输入您的密码"
                               ref="pwd">
                    </van-field>

                  </div>
                </div>
              </div>

              <div class="cell-item"
                   v-if="!isphone">
                <div class="cell-left">
                  <span>确认密码</span>
                </div>
                <div class="cell-right">
                  <div class="m-input">

                    <van-field v-model="user.pwds"
                               type="password"
                               center
                               clearable
                               maxlength="20"
                               placeholder="请确认输入您的密码"
                               ref="pwds">
                    </van-field>

                  </div>
                </div>
              </div>

              <div class="cell-item"
                   v-if="!isphone">
                <div class="cell-left">
                  <span>验证码</span>
                </div>
                <div class="cell-code-right">
                  <div class="m-input">
                    <!-- <input type="text"
                           maxlength="4"
                           placeholder="请输入您的验证码"
                           v-model="user.code"
                           ref="code"> -->
                    <van-field v-model="user.code"
                               type="text"
                               center
                               maxlength="4"
                               placeholder="请输入您的验证码"
                               @focus="focus1()"
                               ref="code">
                    </van-field>

                    <div @click="改变验证码()"
                         class="code-address">
                      <img :src="验证码地址"
                           alt="">
                    </div>
                  </div>
                </div>
              </div>

              <div class="cell-item"
                   v-if="isphone">
                <div class="cell-left">
                  <span>短信码</span>
                </div>
                <div class="cell-code-right">
                  <div class="m-input">

                    <van-cell-group>
                      <van-field v-model="user.sms"
                                 ref="sms"
                                 center
                                 clearable
                                 placeholder="请输入短信验证码">
                        <van-button slot="button"
                                    size="small"
                                    type="danger"
                                    @click="getSms()">{{ timer> 0? timer + 's' : '获取短信'}}</van-button>
                      </van-field>
                    </van-cell-group>

                  </div>
                </div>
              </div>

            </div>
          </div>
          <button class="btn-button"
                  @click="register">注册</button>
          <button class="btn-button btn-register"
                  @click="$router.push('/login')">我已注册有账号</button>
        </div>
      </div>
    </div>
  </div>

</template>

<script>
import { Toast } from 'vant';
import {
  api_获取短信验证码,
  api_短信注册接口,
  api_普通注册接口
} from '@/api/登录接口.js';
import JSEncrypt from 'jsencrypt';
import { mapActions, mapMutations, mapState } from 'vuex';

export default {
  components: {},
  data () {
    return {
      验证码地址: '',
      user: {
        uid: '',
        pwd: '',
        code: '',
        sms: '',
        pwds: ''
      },
      publicKey:
        'MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDOfM4Ikzr/973NIm6ZgkhzPdJjMgTzwwh2h8aZcubSF5IT0UBZPfNtF9IpZi59dUHwe/4W2mP6aShQqlzteII+BNGxDUIIYMH0WLHTO3W3u7No0PD3eJ8cfpd+xCYTpYEgL0Qh08b5WrOUFXnKzyd1Hjmur3LYR0106s67Ce7k2wIDAQAB',
      timer: 0,
      定时器: ''
    }
  },
  computed: {
    isphone () {
      var phoneTest = /^1[3|4|5|6|7|8][0-9]\d{8}$/
      return phoneTest.test(this.user.uid)
    },
    ...mapState({
      config: 'config'
    })
  },

  methods: {
    ...mapMutations({
      加载中: '加载中'
    }),
    ...mapActions({
      getUserInfo: 'user/getUserInfo'
    }),
    focus1 () {
      if (!this.验证码地址) {
        this.验证码地址 = config.api_url + '/Home/Verify?v=' + Math.random()
      }
    },

    改变验证码 () {
      this.验证码地址 = config.api_url + '/Home/Verify?v=' + Math.random()
    },
    // 计算短信时间
    getSms () {
      if (this.timer != 0) return
      this.timer = 60
      this.定时器 = setInterval(() => {
        this.timer--
        if (this.timer <= 0) {
          clearInterval(this.定时器)
        }
      }, 1000)
      api_获取短信验证码({ uid: this.user.uid })
        .then(x => {
          if (x.data.code == 0) {
            Toast('短信已发送，请注意查收')
          } else {
            Toast(x.data.msg)
          }
        })
        .catch(err => {})
    },
    // 注册
    register () {
      if (this.isphone) {
        var phoneTest = /^1[3|4|5|6|7|8][0-9]\d{8}$/
        if (!phoneTest.test(this.user.uid)) {
          Toast('请输入电话号码')
          this.$refs.uid.focus()
          return;
        } else if (!this.user.sms) {
          this.$refs.msm.focus()
          Toast('请输入验证码')
          return;
        }
        var obj = {
          uid: this.user.uid,
          sms: this.user.sms
        }
        this.加载中(true)
        api_短信注册接口(obj)
          .then(x => {
            if (x.data.code == 0) {
              Toast.success('注册成功')
              this.getUserInfo().then(() => {
                this.$router.push('/home')
              })
            } else {
              Toast(x.data.msg)
            }
            this.加载中(false)
          })
          .catch(err => {
            this.加载中(false)
            Toast('网络异常稍后再试')
          })
      } else {
        if (!this.user.uid) {
          this.$refs.uid.focus()
          Toast('请输入您的用户名')
          return;
        } else if (!this.user.pwd) {
          this.$refs.pwd.focus()
          Toast('请输入您的密码')
          return;
        } else if (!this.user.pwds) {
          this.$refs.pwds.focus()
          Toast('请再次输入您的密码')
          return;
        } else if (this.user.pwd !== this.user.pwds) {
          this.$refs.pwds.focus()
          Toast('您的密码输入不一致，请重新输入')
          return;
        } else if (!this.user.code) {
          this.$refs.code.focus()
          Toast('请输入您的验证码')
          return;
        }

        // 加密
        var app = '';
        if (window.plus) {
          app = plus.os.name
        }
        var layout_encrypt = new JSEncrypt()
        layout_encrypt.setPublicKey(this.publicKey)
        var pwd = layout_encrypt.encrypt(this.user.pwd)
        var obj = {
          uid: this.user.uid,
          pwd: pwd,
          code: this.user.code,
          app: app
        }
        this.加载中(true)
        api_普通注册接口(obj).then(x => {
          if (x.data.code == 0) {
            this.$toast(x.data.msg)
            this.getUserInfo().then(() => {
              this.$router.push('/home')
              this.加载中(false)
            })
          } else {
            this.改变验证码()
            this.$toast(x.data.msg)
            this.加载中(false)
          }
        })
        this.加载中(false).catch(err => {
          this.加载中(false)
          this.改变验证码()
          this.$toast('网络异常稍后再试')
        })
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.cont {
  margin: 0.3rem 0.2rem 0 0.2rem;
}
/deep/.van-field__body input {
  margin-bottom: 0;
  border: none;
}
.m-cell-box {
  border-radius: 8px;
  overflow: hidden;
  margin-bottom: 0.3rem;
  box-shadow: 0 0 0.5rem rgba(0, 0, 0, 0.06);
  .m-cell {
    background-color: #fff;
    box-shadow: 0 0 0.4rem rgba(0, 0, 0, 0.08);
    z-index: 5;
    position: relative;
    .cell-item {
      border-bottom: 1px solid #eee;
      padding-top: 0.06rem;
      padding-bottom: 0.06rem;
      display: flex;
      position: relative;
      padding-left: 0.24rem;
      overflow: hidden;
      .cell-left {
        padding-right: 10px;
        font-size: 0.26rem;
        color: #666;
        display: flex;
        align-items: center;
        i {
          font-size: 20px;
        }
        span {
          padding-left: 0.1333rem;
          width: 1.5rem;
          display: inline-block;
        }
      }
      .cell-code-right {
        width: 100%;
        padding-right: 0.24rem;
        min-height: 1.2rem;
        color: grey;
        .m-input {
          width: 100%;
          height: 100%;
          input {
            height: 1.2rem;
            border: none;
            font-size: 0.26rem;
            background: transparent;
            color: #666;
          }
        }
      }
      .cell-right {
        flex: 1;
        padding-right: 0.24rem;
        min-height: 1.2rem;
        color: grey;
        float: right;
        .m-input {
          width: 100%;
          height: 100%;
          input {
            width: 100%;
            height: 1.2rem;
            border: none;
            font-size: 0.26rem;
            background: transparent;
            color: #666;
          }
        }
      }
    }
  }
}
.btn-button {
  width: 100%;
  height: 0.9rem;
  background-color: #f01924;
  color: #fff;
  font-size: 0.26rem;
  border: none;
  border-radius: 4px;
  margin-bottom: 0.25rem;
  box-shadow: 0 0.03rem 0.2rem rgba(0, 0, 0, 0.05);
}
.btn-register {
  background: #fff;
  color: #09f;
}
// .btn-box {
//   display: flex;
//   justify-content: space-between;
//   button {
//     border: none;
//     width: 48%;
//     height: 0.9rem;
//     color: #09f;
//     border: 1px solid #eaeaea;
//     margin: 0.25rem 0 0 0;
//     background: #fff;
//     box-shadow: 0 0.02rem 0.3rem rgba(0, 0, 0, 0.06);
//     font-size: 0.26rem;
//   }
// }

.code-address {
  float: right;
  width: 75px;
  height: 100%;
  position: absolute;
  right: 0;
  bottom: 0;
  img {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    margin: auto;
  }
}
.van-cell {
  line-height: 0;
}
.van-cell--center {
  height: 100%;
  padding: 0;
}
.van-cell-group {
  height: 100%;
}
::-webkit-input-placeholder {
  color: #ccc;
}
:-moz-placeholder {
  /* Firefox 18- */
  color: #ccc;
}
::-moz-placeholder {
  /* Firefox 19+ */
  color: #ccc;
}
:-ms-input-placeholder {
  color: #ccc;
}
</style>
