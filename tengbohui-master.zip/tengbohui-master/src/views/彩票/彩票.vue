<template>
  <div class="layout-box">
    <div class="layout-header">
      <van-nav-bar title="彩票游戏"
                   left-arrow
                   left-text="返回"
                   @click-left="$router.go(-1)" />
    </div>
    <div class="byyx">
      <div class="byyx-box">
        <img src="images/caipiao/cpbanner.jpg"
             alt="">
      </div>

      <div class="byyx-games">
        <div class="game-list"
             v-for="(item,index) in list"
             :key="item.id"
             @click="跳转游戏(item)">
          <div class="game-item">
            <img v-lazy="`images/caipiao/${item.id}.png`">
            <h2>{{item.title}}</h2>
            <!-- <p>{{item.typeTitle}}</p> -->
          </div>
        </div>

      </div>
    </div>
  </div>
</template>

<script>
import { mapState } from 'vuex';

export default {
  data () {
    return {
      list: []
    }
  },
  computed: {
    ...mapState({
      config: 'config',
      彩票玩法: x => x.user.彩票玩法
    })
  },
  methods: {
    跳转游戏 (item) {
      this.$router.push('/cpiframe?i=' + item.id + '&t=' + this.彩票玩法)
    }
  },
  mounted () {
    this.$axios.get('json/home.json').then(x => {
      this.list = x.data[0].children[0].children.slice(1)
      console.log(this.list)
    })
  }
}
</script>

<style lang="scss" scoped>
.byyx {
  flex: 1;
  overflow-x: scroll;
  background: #fff;
  &-box {
    width: auto;
    margin: 0.16rem 2% 0 2%;
    box-shadow: 1px 2px 12px rgba(0, 100, 255, 0.1);
    img {
      width: 100%;
    }
  }
  &-title {
    width: 100%;
    margin: 0 0 0 0;
    text-align: center;
    label {
      font-size: 0.3rem;
      height: 0.28rem;
      line-height: 0.32rem;
      margin: 0.22rem 0 0.12rem 0;
      color: #444;
      font-weight: 400;
      color: #79d1ff;
      text-shadow: 1px 1px 2px rgba(0, 155, 255, 0.25);
      opacity: 0.8;
      display: inline-block;
    }
  }
  &-games {
    overflow: hidden;
    padding-bottom: 0.1rem;
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    .game-list {
      width: 30%;
      display: flex;
      justify-content: center;
      align-items: center;
      background: #fff;
      border-radius: 16px;
      margin-bottom: 10px;
      margin-top: 10px;
      .game-item {
        width: 1.5rem;
        text-align: center;
        img {
          width: 100%;
          height: 100%;
          border-radius: 16px;
        }
        h2 {
          color: #444;
          font-weight: 400;
          font-size: 0.24rem;
          line-height: 0.36rem;
          margin-top: 0.1rem;
        }
        p {
          font-size: 0.22rem;
          color: #bbb;
          padding-bottom: 0.1rem;
        }
      }
    }
  }
}
</style>
