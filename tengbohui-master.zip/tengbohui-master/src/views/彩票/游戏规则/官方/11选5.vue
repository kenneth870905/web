<template>

    <div class="mint-tab-container-item lottery-rule wfgz-rule">
                    <div class="rule">
                        <p>三码</p>
                        <div class="box">
                            <!---->
                            <div class="item">
                                <div class="title">
                                    前三直选
                                    <i class="icon iconfont icon-icon-arrow-bottom2"></i></div>
                                <div style="display: none;">
                                    <div class="content"><span>复式</span>
                                        <p>从第一、二、三位中各选1个不同的号码组成一注。所选号与开奖号前三位号码相同，且顺序一致，即为中奖。</p>
                                    </div>
                                    <div class="content"><span>单式</span>
                                        <p>手动输入1个三位不同的号码组成一注。输入号与开奖号前三位号码相同，且顺序一致，即为中奖。</p>
                                    </div>
                                    <!---->
                                </div>
                            </div>
                            <div class="item">
                                <div class="title">
                                    前三组选
                                    <i class="icon iconfont icon-icon-arrow-bottom2"></i></div>
                                <div style="display: none;">
                                    <div class="content"><span>复式</span>
                                        <p>从01-11中任选3个不同的号码组成一注。不限顺序，开奖号前三位中包含全部所选号，即为中奖。</p>
                                    </div>
                                    <div class="content"><span>单式</span>
                                        <p>手动输入1个三位不同的号码组成一注。不限顺序，开奖号前三位号码中包含3个输入号，即为中奖。</p>
                                    </div>
                                    <!---->
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="rule">
                        <p>二码</p>
                        <div class="box">
                            <!---->
                            <div class="item">
                                <div class="title">
                                    前二直选
                                    <i class="icon iconfont icon-icon-arrow-bottom2"></i></div>
                                <div style="display: none;">
                                    <div class="content"><span>复式</span>
                                        <p>从第一、二位中各选1个不同的号码组成一注。所选号与开奖号前两位号码相同，且顺序一致，即为中奖。</p>
                                    </div>
                                    <div class="content"><span>单式</span>
                                        <p>手动输入1个两位不同的号码组成一注。输入号与开奖号前两位号码相同，且顺序一致，即为中奖。</p>
                                    </div>
                                    <!---->
                                </div>
                            </div>
                            <div class="item">
                                <div class="title">
                                    前二组选
                                    <i class="icon iconfont icon-icon-arrow-bottom2"></i></div>
                                <div style="display: none;">
                                    <div class="content"><span>复式</span>
                                        <p>从01-11中任选2个不同的号码组成一注。不限顺序，开奖号前两位中包含全部所选号，即为中奖。</p>
                                    </div>
                                    <div class="content"><span>单式</span>
                                        <p>手动输入1个两位不同的号码组成一注。不限顺序，开奖号前两位中包含2个输入号，即为中奖。</p>
                                    </div>
                                    <!---->
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="rule">
                        <p>不定胆</p>
                        <div class="box">
                            <!---->
                            <div class="item">
                                <div class="title">
                                    不定胆
                                    <i class="icon iconfont icon-icon-arrow-bottom2"></i></div>
                                <div style="display: none;">
                                    <div class="content"><span>前三位</span>
                                        <p>从01-11中任选1个号码组成一注。不限顺序，开奖号前三位任意一位中包含所选号，即为中奖。</p>
                                    </div>
                                    <!---->
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="rule">
                        <p>定位胆</p>
                        <div class="box">
                            <!---->
                            <div class="item">
                                <div class="title">
                                    定位胆
                                    <i class="icon iconfont icon-icon-arrow-bottom2"></i></div>
                                <div style="display: none;">
                                    <div class="content"><span>定位胆</span>
                                        <p>从第一位至第五位中任选1个位置，并选1个号码组成一注。投注号与开奖号位置及号码相同，即为中奖。</p>
                                    </div>
                                    <!---->
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="rule">
                        <p>任选</p>
                        <div class="box">
                            <!---->
                            <div class="item">
                                <div class="title">
                                    任选复式
                                    <i class="icon iconfont icon-icon-arrow-bottom2"></i></div>
                                <div style="display: none;">
                                    <div class="content"><span>一中一</span>
                                        <p>从01-11中任选1个号码组成一注。不限顺序，开奖号中包含1个所选号，即为中奖。</p>
                                    </div>
                                    <div class="content"><span>二中二</span>
                                        <p>从01-11中任选2个号码组成一注。不限顺序，开奖号中包含2个所选号，即为中奖。</p>
                                    </div>
                                    <div class="content"><span>三中三</span>
                                        <p>从01-11中任选3个号码组成一注。不限顺序，开奖号中包含3个所选号，即为中奖。</p>
                                    </div>
                                    <div class="content"><span>四中四</span>
                                        <p>从01-11中任选4个号码组成一注。不限顺序，开奖号中包含4个所选号，即为中奖。</p>
                                    </div>
                                    <div class="content"><span>五中五</span>
                                        <p>从01-11中任选5个号码组成一注。不限顺序，开奖号中包含全部所选号，即为中奖。</p>
                                    </div>
                                    <div class="content"><span>六中五</span>
                                        <p>从01-11中任选6个号码组成一注。不限顺序，开奖号中包含6个所选号中的任意5个号码，即为中奖。</p>
                                    </div>
                                    <div class="content"><span>七中五</span>
                                        <p>从01-11中任选7个号码组成一注。不限顺序，开奖号中包含7个所选号中的任意5个号码，即为中奖。</p>
                                    </div>
                                    <div class="content"><span>八中五</span>
                                        <p>从01-11中任选8个号码组成一注。不限顺序，开奖号中包含8个所选号中的任意5个号码，即为中奖。</p>
                                    </div>
                                    <!---->
                                </div>
                            </div>
                            <div class="item">
                                <div class="title">
                                    任选单式
                                    <i class="icon iconfont icon-icon-arrow-bottom2"></i></div>
                                <div style="display: none;">
                                    <div class="content"><span>一中一</span>
                                        <p>从01-11中手动输入1个号码组成一注。不限顺序，开奖号中包含1个输入号，即为中奖。</p>
                                    </div>
                                    <div class="content"><span>二中二</span>
                                        <p>从01-11中手动输入2个号码组成一注。不限顺序，开奖号中包含2个输入号，即为中奖。</p>
                                    </div>
                                    <div class="content"><span>三中三</span>
                                        <p>从01-11中手动输入3个号码组成一注。不限顺序，开奖号中包含3个输入号，即为中奖。</p>
                                    </div>
                                    <div class="content"><span>四中四</span>
                                        <p>从01-11中手动输入4个号码组成一注。不限顺序，开奖号中包含4个输入号，即为中奖。</p>
                                    </div>
                                    <div class="content"><span>五中五</span>
                                        <p>从01-11中手动输入5个号码组成一注。不限顺序，开奖号中包含全部输入号，即为中奖。</p>
                                    </div>
                                    <div class="content"><span>六中五</span>
                                        <p>从01-11中手动输入6个号码组成一注。不限顺序，开奖号中包含6个输入号中的任意5个号码，即为中奖。</p>
                                    </div>
                                    <div class="content"><span>七中五</span>
                                        <p>从01-11中手动输入7个号码组成一注。不限顺序，开奖号中包含7个输入号中的任意5个号码，即为中奖。</p>
                                    </div>
                                    <div class="content"><span>八中五</span>
                                        <p>从01-11中手动输入8个号码组成一注。不限顺序，开奖号中包含8个输入号中的任意5个号码，即为中奖。</p>
                                    </div>
                                    <!---->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

</template>

<script>
export default {
    name:"",
    data() {
        return {
            
        }
    },
    mounted() {
        $('.title').click(function(){
            $(this).next().slideToggle(300);
        })
    },
}
</script>

<style lang="scss" scoped>
.wfgz-rule{
    padding-bottom: 40px;
}
.rule{
    >p{
        background: #f5f5f9;
        padding: 5px 10px;
        margin: 0px;
    }
    .title{
        padding: 0px 10px 0px 35px;
        border-bottom: 1px solid #e4e4e4;
        line-height: 36px;
        font-size: 14px;
        i{
            float: right;
            color: #929292;
            font-size: 14px;
        }
    }
}
.content{
    padding: 0px 15px;
}
</style>
