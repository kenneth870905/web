<template>

    <div class="mint-tab-container-item lottery-rule wfgz-rule">
                    <div class="rule">
                        <p>两面</p>
                        <div class="box">
                            <!---->
                            <div class="item">
                                <div class="title">
                                    两面
                                    <i class="icon iconfont icon-icon-arrow-bottom2"></i></div>
                                <div style="display: none;">
                                    <div class="content"><span>两面</span>
                                        <p>指大小单双。对特码的总和及形态或正码1-6的合数及形态进行投注。所选号与开奖号的位置、形态相同，即为中奖，特码开出49为和局，退还本金。</p>
                                    </div>
                                    <!---->
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="rule">
                        <p>特码</p>
                        <div class="box">
                            <!---->
                            <div class="item">
                                <div class="title">
                                    特码
                                    <i class="icon iconfont icon-icon-arrow-bottom2"></i></div>
                                <div style="display: none;">
                                    <div class="content"><span>特码</span>
                                        <p>当期开出的第七个号码为特码，从01-49中任选1个号码组成一注。所选号码与开奖特码相同，即为中奖。</p>
                                    </div>
                                    <!---->
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="rule">
                        <p>正码</p>
                        <div class="box">
                            <!---->
                            <div class="item">
                                <div class="title">
                                    正码
                                    <i class="icon iconfont icon-icon-arrow-bottom2"></i></div>
                                <div style="display: none;">
                                    <div class="content"><span>正码</span>
                                        <p>从01-49中任选1个号码组成一注。不限顺序，开奖的正码中包含投注号，即为中奖。</p>
                                    </div>
                                    <!---->
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="rule">
                        <p>正码特</p>
                        <div class="box">
                            <!---->
                            <div class="item">
                                <div class="title">
                                    正码特
                                    <i class="icon iconfont icon-icon-arrow-bottom2"></i></div>
                                <div style="display: none;">
                                    <div class="content"><span>正码特</span>
                                        <p>从01-49中任选1个号码组成一注。不限顺序，开奖的正码中包含投注号，即为中奖。</p>
                                    </div>
                                    <!---->
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="rule">
                        <p>正码1-6</p>
                        <div class="box">
                            <!---->
                            <div class="item">
                                <div class="title">
                                    正码1-6
                                    <i class="icon iconfont icon-icon-arrow-bottom2"></i></div>
                                <div style="display: none;">
                                    <div class="content"><span>正码1-6</span>
                                        <p>任选1个形态组成一注。投注号与开奖号的正码位置、形态相同，即为中奖。</p>
                                    </div>
                                    <div class="content"><span>大小</span>
                                        <p>指定出现正码的位置与号码大于或等于25为大，小于或等于24为小，开出49为和。</p>
                                    </div>
                                    <div class="content"><span>单双</span>
                                        <p>以指定出现正码的位置与号码为单数或双数下注，开出49为和。</p>
                                    </div>
                                    <div class="content"><span>合数大小</span>
                                        <p>以指定出现正码的位置与号码个位和十位的数字和值来判断大小，和数大于或等于7为大，小于或等于6为小。</p>
                                    </div>
                                    <div class="content"><span>合数单双</span>
                                        <p>以指定出现正码的位置与号码个位和十位数字和值来判断单双。</p>
                                    </div>
                                    <div class="content"><span>色波</span>
                                        <p>以指定出现正码的位置的球色下注，开奖的球色与下注的颜色相同，即为中奖。</p>
                                    </div>
                                    <div class="content"><span>尾数大小</span>
                                        <p>以指定出现正码的位置与号码尾数大小下注，0尾~4尾为小、5尾~9尾为大。</p>
                                    </div>
                                    <!---->
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="rule">
                        <p>正码过关</p>
                        <div class="box">
                            <!---->
                            <div class="item">
                                <div class="title">
                                    正码过关
                                    <i class="icon iconfont icon-icon-arrow-bottom2"></i></div>
                                <div style="display: none;">
                                    <div class="content"><span>正码过关</span>
                                        <p>从正一至正六中任选2个位置，并各选1个形态组成一注。所选形态与相同位置上的开奖形态一致，即为中奖。可同时选投多个正码形态，串联成投注组合，赔率为所选串联赔率的总乘积。</p>
                                    </div>
                                    <!---->
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="rule">
                        <p>连码</p>
                        <div class="box">
                            <!---->
                            <div class="item">
                                <div class="title">
                                    连码
                                    <i class="icon iconfont icon-icon-arrow-bottom2"></i></div>
                                <div style="display: none;">
                                    <div class="content"><span>四全中</span>
                                        <p>对开奖正码进行投注，任选4个号码为一注。不限顺序，开奖正码中包含4个所选号，即为中奖。</p>
                                    </div>
                                    <div class="content"><span>三全中</span>
                                        <p>对开奖正码进行投注，任选3个号码为一注。不限顺序，开奖正码中包含3个所选号，即为中奖。</p>
                                    </div>
                                    <div class="content"><span>三中二</span>
                                        <p>对开奖正码进行投注，任选3个号码为一 注。不限顺序，开奖正码中包含所选号中的任意2个号码，即中“三中二”；正码中包含3个所选号，即中“三中二之中三。</p>
                                    </div>
                                    <div class="content"><span>二全中</span>
                                        <p>对开奖正码进行投注，任选2个号码为一注。不限顺序，开奖正码中包含2个所选号，即为中奖。</p>
                                    </div>
                                    <div class="content"><span>二中特</span>
                                        <p>从01-49中任选2个号码为一注。开奖正码中包含2个所选号，则中“二中特之中二”；若所选号中1个是正码，1个是特码，则中“二全中之中特”。</p>
                                    </div>
                                    <div class="content"><span>特串</span>
                                        <p>从01-49中任选2个号码为一注。2个所选号一个出现在开奖正码中，一个出现在开奖特码中，即为中奖。</p>
                                    </div>
                                    <!---->
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="rule">
                        <p>连肖连尾</p>
                        <div class="box">
                            <!---->
                            <div class="item">
                                <div class="title">
                                    连肖连尾
                                    <i class="icon iconfont icon-icon-arrow-bottom2"></i></div>
                                <div style="display: none;">
                                    <div class="content"><span>连肖连尾</span>
                                        <p>对7个开奖号码所属的生肖或尾数进行投注。不限顺序，7个开奖号中包含全部所选生肖或尾数，即为中奖。</p>
                                    </div>
                                    <!---->
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="rule">
                        <p>自选不中</p>
                        <div class="box">
                            <!---->
                            <div class="item">
                                <div class="title">
                                    自选不中
                                    <i class="icon iconfont icon-icon-arrow-bottom2"></i></div>
                                <div style="display: none;">
                                    <div class="content"><span>自选不中</span>
                                        <p>7个开奖号中均不包含全部所选号，即为中奖。</p>
                                    </div>
                                    <!---->
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="rule">
                        <p>生肖</p>
                        <div class="box">
                            <!---->
                            <div class="item">
                                <div class="title">
                                    生肖
                                    <i class="icon iconfont icon-icon-arrow-bottom2"></i></div>
                                <div style="display: none;">
                                    <div class="content"><span>特肖</span>
                                        <p>对开奖特码所属的生肖进行投注，任选1个生肖为一注。开奖特码在所选生肖范围内，即为中奖。</p>
                                    </div>
                                    <div class="content"><span>正肖</span>
                                        <p>对6个开奖正码所属的生肖进行投注，任选1个生肖组成一注。不限顺序，6个开奖正码中任意1个号码在所选生肖范围内，即为中奖。若有N个开奖正码在所选生肖范围内，中奖金额=本金*（赔率-1）*中奖次数+本金。</p>
                                    </div>
                                    <div class="content"><span>一肖</span>
                                        <p>对7个开奖号码所属的生肖范围进行投注，任选1个生肖为一注。7个开奖号中任意一个号码在所选生肖的范围内，即为中奖。</p>
                                    </div>
                                    <div class="content"><span>总肖</span>
                                        <p>对7个开奖号的不同生肖总数及总肖的单双形态进行投注，任选1个组成一注。总肖单双指7个开奖号所属的生肖总数为单数或双数。投注类型与7个开奖号类型相符，即为中奖。</p>
                                    </div>
                                    <!---->
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="rule">
                        <p>合肖</p>
                        <div class="box">
                            <!---->
                            <div class="item">
                                <div class="title">
                                    合肖
                                    <i class="icon iconfont icon-icon-arrow-bottom2"></i></div>
                                <div style="display: none;">
                                    <div class="content"><span>合肖</span>
                                        <p>对开奖特码所属生肖进行投注，任选1个生肖为一注。开奖特码在所选生肖范围内，即为中奖，特码开出49为和局，退还本金。</p>
                                    </div>
                                    <div class="content"><span>野兽</span>
                                        <p>鼠（11 23 35 47）、虎（09 21 33 45）、兔（08 20 32 44）、龙（07 19 31 43）、蛇（06 18 30 42）、猴（03 15 27
                                            39）</p>
                                    </div>
                                    <div class="content"><span>家禽</span>
                                        <p>牛（10 22 34 46）、马（05 17 29 41）、羊（04 16 28 40）、鸡（02 14 26 38）、狗（01 13 25 37 49）、猪（12 24 36
                                            48）</p>
                                    </div>
                                    <div class="content"><span>天肖</span>
                                        <p>牛（10 22 34 46）、兔（08 20 32 44）、龙（07 19 31 43）、马（05 17 29 41）、猴（03 15 27 39）、猪（12 24 36
                                            48）</p>
                                    </div>
                                    <div class="content"><span>地肖</span>
                                        <p>鼠（11 23 35 47）、虎（09 21 33 45）、蛇（06 18 30 42）、羊（04 16 28 40）、鸡（02 14 26 38）、狗（01 13 25 37
                                            49）</p>
                                    </div>
                                    <div class="content"><span>前肖</span>
                                        <p>鼠（11 23 35 47）、牛（10 22 34 46）、虎（09 21 33 45）、兔（08 20 32 44）、龙（07 19 31 43）、蛇（06 18 30
                                            42）</p>
                                    </div>
                                    <div class="content"><span>后肖</span>
                                        <p>马（05 17 29 41）、羊（04 16 28 40）、猴（03 15 27 39）、鸡（02 14 26 38）、狗（01 13 25 37 49）、猪（12 24 36
                                            48）</p>
                                    </div>
                                    <!---->
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="rule">
                        <p>色波</p>
                        <div class="box">
                            <!---->
                            <div class="item">
                                <div class="title">
                                    色波
                                    <i class="icon iconfont icon-icon-arrow-bottom2"></i></div>
                                <div style="display: none;">
                                    <div class="content"><span>三色波</span>
                                        <p>对开奖特码的色波进行投注，任选1个色波为一注。所选波色与开奖特码的色波相同，即为中奖。</p>
                                    </div>
                                    <div class="content"><span>半波</span>
                                        <p>以开奖特码的色波和大小单双为一个组合，任选1个组合为一注。所选组合与开奖特码相符，即为中奖。如开奖特码为49，则为和局，系统自动退还投注金额。</p>
                                    </div>
                                    <div class="content"><span>半半波</span>
                                        <p>以开奖特码的色波和大单大双小单小双为一个组合，任选1个组合为一注。所选组合与开奖特码相符，即为中奖。如开奖号特码为49，则为和局，系统自动退还投注金额。</p>
                                    </div>
                                    <div class="content"><span>七色波</span>
                                        <p>以7个开奖号的色波，哪个颜色最多为中奖色波。7个开奖号最多的色波与所选色波相同，即为中奖。以下3种结果视为和局：6个正码开出3蓝3绿，特码是1.5红
                                            6个正码开出3蓝3红，特码是1.5绿 6个正码开出3绿3红，特码是1.5蓝 如投注红、蓝、绿波时开出和局，则系统自动退还投注金额；会员也可以下注“和局”。</p>
                                    </div>
                                    <!---->
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="rule">
                        <p>尾数</p>
                        <div class="box">
                            <!---->
                            <div class="item">
                                <div class="title">
                                    尾数
                                    <i class="icon iconfont icon-icon-arrow-bottom2"></i></div>
                                <div style="display: none;">
                                    <div class="content"><span>头尾数</span>
                                        <p>对开奖特码头（十位）或尾（个位）数进行投注，任选1个类型为一注。所选的头数或尾数与开奖特码位置、号码相同，即为中奖。</p>
                                    </div>
                                    <div class="content"><span>正特尾数</span>
                                        <p>对6个正码和特码的尾数进行投注，任选1个类型为一注。6个正码或特码中任意一个尾数与所选尾数相同，即为中奖。</p>
                                    </div>
                                    <!---->
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="rule">
                        <p>七码五行</p>
                        <div class="box">
                            <!---->
                            <div class="item">
                                <div class="title">
                                    七码五行
                                    <i class="icon iconfont icon-icon-arrow-bottom2"></i></div>
                                <div style="display: none;">
                                    <div class="content"><span>七码</span>
                                        <p>对7个开奖号中大小单双各有多少个进行投注，任选1个类型为一注。所选的大小单双数量与7个开奖号的大小单双数量相同，即为中奖。</p>
                                    </div>
                                    <div class="content"><span>五行</span>
                                        <p>对开奖特码所属的五行进行投注，任选1个为一注。开奖特码在所选的五行范围内，即为中奖。</p>
                                    </div>
                                    <!---->
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="rule">
                        <p>中一</p>
                        <div class="box">
                            <!---->
                            <div class="item">
                                <div class="title">
                                    中一
                                    <i class="icon iconfont icon-icon-arrow-bottom2"></i></div>
                                <div style="display: none;">
                                    <div class="content"><span>中一</span>
                                        <p>对7个开奖号中大小单双各有多少个进行投注，任选1个类型为一注。所选的大小单双数量与7个开奖号的大小单双数量相同，即为中奖。</p>
                                    </div>
                                    <!---->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

</template>

<script>
export default {
    name:"",
    data() {
        return {
            
        }
    },
    mounted() {
        $('.title').click(function(){
            console.log('132')
            $(this).next().slideToggle(300);
        })
    },
}
</script>

<style lang="scss" scoped>
.wfgz-rule{
    padding-bottom: 40px;
}
.rule{
    >p{
        background: #f5f5f9;
        padding: 5px 10px;
        margin: 0px;
    }
    .title{
        padding: 0px 10px 0px 35px;
        border-bottom: 1px solid #e4e4e4;
        line-height: 36px;
        font-size: 14px;
        i{
            float: right;
            color: #929292;
            font-size: 14px;
        }
    }
}
.content{
    padding: 0px 15px;
}
</style>
