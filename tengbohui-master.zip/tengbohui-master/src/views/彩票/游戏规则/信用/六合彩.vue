<template>
    <div class="mint-tab-container-item lottery-rule wfgz-xywf" style="">
                </div>
</template>

<script>
export default {
    name:"",
    data() {
        return {
            
        }
    },
}
</script>


<style lang="scss" scoped>
.wfgz-xywf{
    padding: _vw(10);
}
p{
    color: #585858;
}
strong {
    font-size: 18px;
    color: #000000;
}
span {
    color: #0099cc;
}
</style>