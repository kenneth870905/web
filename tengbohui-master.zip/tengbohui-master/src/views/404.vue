<template>
  <div>
    <div class="app-container">
      <van-row>
        <van-col>
          <img src="../assets/gif_404.gif"
               alt="404"
               class="img-style">
        </van-col>
        <van-col>
          <div class="app-content">
            <h1 class="color-main"
                style="padding: 20px;">SORRY!</h1>
            <h2 style="color: #606266;padding-bottom: 10px; ">很抱歉，页面它不小心迷路了！</h2>
            <div style="color:#909399;font-size: 14px;line-height: 30px;">请检查您输入的网址是否正确，请点击以下按钮返回主页</div>
            <van-button style="margin-top: 20px"
                        type="primary"
                        round
                        @click="handleGoMain">返回首页</van-button>
          </div>
        </van-col>
      </van-row>
    </div>
  </div>
</template>

<script>
export default {
  name: 'wrongPage',
  methods: {
    handleGoMain () {
      this.$router.push({ path: '/' })
    }
  }
}
</script>

<style scoped>
.img-style {
  width: auto;
  height: auto;
  max-width: 100%;
  max-height: 100%;
}
.van-col {
  width: 100%;
}
.app-content {
  display: flex;
  flex-direction: column;
  text-align: center;
  align-items: center;
  width: 100%;
}
</style>
