<template>
  <div class="layout-box">
    <div class="layout-header">
      <van-nav-bar title="户内转账"
                   left-arrow
                   left-text="返回"
                   @click-left="$router.go(-1)" />
    </div>

    <div class="changeCash">

      <div class="balance">
        <span class="balance-title">主账户资金</span>
        <div class="balance-right">
          <span class="redColor">￥{{userinfo.Money}}</span>
          <span class="yuan">元</span>
        </div>
        <div class="zzyjgh">
          <!-- <div class="anniu"
               @click="主账户()">资金一键归户</div> -->
        </div>
      </div>
      <p class="tips">
        <!-- <b>提示:</b>&nbsp;&nbsp;显示【锁】标识的平台，代表正在参与优惠活动，期间该平台必须完成指定流水或子账户资金小于5元才可成功操作子账户转账。用户可点击该标识查看流水详情！ -->
      </p>
      <div class="cell-box"
           ref="onCell">

        <!-- 选中 -->
        <div :class="['cell-item',{selected: isAc == index}]"
             v-for="(item,index) in items"
             :key="index"
             @click="onSelected(item,index)">
          <div class="cell-left">
            <div class="left-wrap">
              <div class="game-balance">
                <p class="game-balance-title">{{item.title}}</p>
                <p class="">
                  <span class="money">余额：</span>
                  <span class="djck"
                        @click="查询余额(item, item.type)">{{item.balance > 0 || item.balance == 0 ? item.balance : '查询余额'}}</span>
                </p>
              </div>
            </div>
          </div>
          <div>
            <div class="cell-right">
            </div>
            <van-icon name="success"
                      v-if="isAc == index" />
          </div>

        </div>

      </div>
      <div class="title-text">
        <span>{{gameTitle.name}}</span>
      </div>
      <div class="input-box">
        <input type="text"
               placeholder="最低1元，只能为整数"
               v-model="money">
      </div>
      <div class="transfer-btn">
        <button @click="转入游戏平台()">转入游戏平台</button>
        <button @click="转出游戏平台()">转出游戏平台</button>
      </div>
    </div>

  </div>

  </div>

</template>

<script>
import {
  api_获取平台余额,
  api_转入金额,
  api_转出金额
} from "@/api/余额接口.js";
import { mapActions, mapState, mapMutations } from "vuex";
export default {
  components: {},
  data() {
    return {
      isAc: 0,
      gameTitle: { name: "AG电子", type: "" },
      money: "",
      items: [
        {
          title: "AG电子",
          type: "AG"
        },
        // {
        //   title: 'AG街机',
        //   type: 'AG'
        // },
        {
          title: "MG电子",
          type: "MG"
        },
        {
          title: "BBIN电子",
          type: "BY"
        },
        {
          title: "BG电子",
          type: "BG"
        },
        {
          title: "泛亚电竞",
          type: "FY"
        },
        {
          title: "FG电子",
          type: "FG"
        },
        {
          title: "哈巴电游",
          type: "HB"
        },
        {
          title: "乐游电子",
          type: "LY"
        },
        {
          title: "CQ9电子",
          type: "CQ"
        },
        {
          title: "SW电子",
          type: "SW"
        }
      ],
      list: []
    };
  },
  computed: {
    ...mapState({
      userinfo: x => x.user.userinfo
    })
  },
  methods: {
    ...mapActions({
      获取平台余额: "进入游戏/获取平台余额",
      转入金额: "进入游戏/转入金额",
      转出金额: "进入游戏/转出金额"
    }),
    ...mapMutations({
      加载中: "加载中",
      设置changeType: "进入游戏/设置changeType"
    }),
    onSelected(item, index) {
      this.isAc = index;
      this.gameTitle.name = item.title;
      this.gameTitle.type = item.type;
      this.money = "";
      this.list = item;
    },
    查询余额(item, type) {
      this.加载中(true);
      api_获取平台余额({ type })
        .then(x => {
          console.log(x);
          if (x.data.code === 0) {
            this.加载中(false);
            this.$set(item, "balance", x.data.msg);
            this.money = "";
          } else {
            this.$toast(x.data.msg);
            this.加载中(false);
          }
        })
        .catch(e => {});
    },
    转入游戏平台() {
      var 整数 = /^[1-9]+.?[0-9]*$/; // 验证正整数
      if (!this.money) {
        this.$toast("请输入转入金额");
      } else if (!整数.test(this.money)) {
        this.$toast("请输入整数");
      } else {
        this.加载中(true);
        this.设置changeType(this.gameTitle.type);
        this.转入金额(this.money);
        this.查询余额(this.list, this.gameTitle.type);
        this.加载中(false);
      }
    },
    转出游戏平台() {
      var 整数 = /^[1-9]+.?[0-9]*$/; // 验证正整数
      if (!this.money) {
        this.$toast("请输入转入金额");
      } else if (!整数.test(this.money)) {
        this.$toast("请输入整数");
      } else {
        this.加载中(true);
        this.设置changeType(this.gameTitle.type);
        this.转出金额(this.money);
        this.查询余额(this.list, this.gameTitle.type);
        this.加载中(false);
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.changeCash {
  flex: 1;
  overflow-x: scroll;
  .balance {
    width: 100%;
    margin: 0 0 0 0;
    padding: 0 0.24rem 0 0;
    line-height: 1.08rem;
    font-size: 0.24rem;
    color: #999;
    background: #fff;
    border-bottom: 1px solid #f2f2f2;
    box-sizing: border-box;
    &-title {
      height: 0.38rem;
      line-height: 0.38rem;
      display: inline-block;
      border-left: 4px solid #ff3a2b;
      margin-top: 0.35rem;
      padding-left: 0.18rem;
      font-size: 0.26rem;
      color: #444;
      float: left;
    }
    &-right {
      float: right;
      font-size: 0.3rem;
      .redColor {
        color: #f11924;
      }
      .yuan {
        margin-left: 4px;
      }
    }
    .zzyjgh {
      clear: both;
      margin-left: 0.24rem;
    }
    .anniu {
      display: block;
      margin: 0 auto;
      width: 100%;
      height: 0.8rem;
      line-height: 0.8rem;
      text-align: center;

      background-image: linear-gradient(180deg, #fff, #f6f6f6);
      border: 1px solid #dcdcdc;
      border-radius: 4px;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
      color: #666;
      font-size: 0.26rem;
    }
  }
  .tips {
    margin: 0.24rem 2% 0 2%;
    font-size: 0.22rem;
    line-height: 0.3rem;
    color: #999;
    opacity: 0.75;
    b {
      color: #f01924;
      font-weight: bold;
    }
  }
  .cell-box {
    display: flex;
    justify-content: space-between;
    flex-wrap: wrap;
    padding: 0 0.24rem 0.24rem 0;
    .cell-item {
      background: #fff;
      width: 47%;
      margin: 0.15rem 0 0 2%;
      height: 1.4rem;
      padding-left: 0;
      border-radius: 6px;
      border-top: 1px solid #f5f5f5;
      border-left: 1px solid #f5f5f5;
      border-bottom: 1px solid #e6e6e6;
      border-right: 1px solid #e6e6e6;
      box-shadow: 3px 3px 10px rgba(0, 0, 0, 0.08);
      position: relative;
      overflow: hidden;
      .cell-left {
        font-size: 0.26rem;
        .left-wrap {
          display: block;
          width: 100%;
          text-align: left;
          font-size: 0.24rem;
          height: 1.2rem;
          margin: 0 0;
          position: relative;
          .game-balance {
            padding-top: 0.3rem;
            color: #ccc;
            padding-left: 0.4rem;
            line-height: 0.36rem;
            &-title {
              font-size: 0.24rem;
              width: 2.8rem;
              color: #333;
              padding-bottom: 2px;
            }
            .djck {
              color: #699deb;
              opacity: 0.75;
            }
          }
        }
      }
    }
    // 选中
    .selected {
      border: 1px solid #f01924;
      box-shadow: 1px 2px 8px rgba(220, 0, 0, 0.25);
      .cell-right {
        width: 0.88rem;
        height: 0.88rem;
        position: absolute;
        bottom: -0.6rem;
        background: #f01924;
        right: -0.44rem;
        transform: rotate(45deg);
      }
      i {
        color: #fff;
        float: right;
        position: absolute;
        right: 0;
        bottom: -0.04rem;
      }
    }
  }
  .title-text {
    margin-top: 15px;
    width: 100%;
    border-top: 0.2rem solid #f2f2f2;
    padding: 0.3rem 0 0.3rem 0;
    overflow: hidden;
    float: left;
    span {
      display: inline-block;
      border-left: 4px solid #09f;
      padding-left: 0.28rem;
      color: #333;
      font-size: 0.26rem;
    }
  }
  .input-box {
    clear: both;
    overflow: hidden;
    height: 0.88rem;
    margin: 0 3%;
    width: 94%;
    border-radius: 6px;
    padding: 0 5px;
    border-top: 1px solid #eee;
    border-left: 1px solid #eee;
    border-bottom: 1px solid #e1e1e1;
    border-right: 1px solid #e1e1e1;
    background: #fff;
    box-shadow: 0 0.04rem 0.15rem rgba(0, 0, 0, 0.1);
    box-sizing: border-box;
    input {
      width: 100%;
      height: 100%;
      border: none;
      font-size: 0.26rem;
    }
  }
  .transfer-btn {
    overflow: hidden;
    clear: both;
    padding-bottom: 0.25rem;
    display: flex;
    justify-content: space-between;
    padding: 0 0.24rem 0.24rem 0;
    button {
      width: 46%;
      height: 0.8rem;
      background: #ff3a2b;
      color: #fff;
      box-shadow: 0 0.02rem 0.5rem rgba(0, 0, 0, 0.1);
      margin: 0.25rem 0 0 0.2rem;
      border: none;
      font-size: 0.26rem;
      border-radius: 4px;
    }
    button:nth-child(2) {
      background: #473f4d;
    }
  }
}
input::placeholder {
  color: #ccc;
}
</style>
