<template>
  <div class="layout-box">
    <div class="layout-header">
      <van-nav-bar title="代理管理"
                   left-arrow
                   left-text="返回"
                   @click-left="$router.go(-1)" />
    </div>
    <div class="提示">
      <van-icon name="fail"
                class="icon" />
      <!-- <i class="icon iconfont icon-gantanhao"></i> -->
      <span>添加绑定代理线请访问电脑版网站查看</span>
    </div>
    <table>
      <thead class="header">
        <tr>
          <td>返佣类型</td>
          <td>推广链接</td>
          <td>会员</td>
          <td>总收益</td>
          <td>操作</td>
        </tr>
      </thead>
      <tbody class="tbody">
        <tr v-for="(item, index) in list"
            :key="index">
          <td>{{item.TuiShuiType}}</td>
          <td>{{item.Domain}}</td>
          <td>{{item.MemberCount}}</td>
          <td>{{item.TuiShuiTotal}}</td>
          <td>
            <div @click="复制(item)"
                 class="btn_1">复制链接</div>
          </td>
        </tr>

      </tbody>
    </table>
  </div>
</template>

<script>
import { api_获取推广链接 } from '@/api/代理接口.js';

export default {
  data () {
    return {
      list: []
    }
  },
  methods: {
    复制 (item) {
      this.$copyText(item.Domain).then(
        e => {
          this.$toast('复制成功')
        },
        e => {
          this.$toast('复制失败，请手动复制')
        }
      )
    }
  },
  mounted () {
    api_获取推广链接().then(x => {
      var data = x.data
      data.forEach(item => {
        if (item.Url) {
          item.Domain = item.Url
        } else {
          item.Domain = location.host + '/p/' + item.Id
        }
      })
      this.list = x.data
    })
  }
}
</script>

<style lang="scss" scoped>
.提示 {
  padding: 10px;
  font-size: 12px;
  i {
    margin: 0px 5px 0px 0px;
    border-radius: 50%;
    background: red;
    color: #fff;
  }
  color: #888888;
}
//头部样式
header {
  height: 44px;
  .mui-icon-left-nav,
  .mui-title {
    font-size: 18px;
    line-height: 40px;
    padding: 0px;
  }
  .mui-bar-nav {
    height: 44px;
  }
  position: relative;
  span {
    position: absolute;
    right: 10px;
    top: 0px;
    color: #ffffff;
    line-height: 44px;
    font-size: 15px;
  }
}

//内容部分
table {
  table-layout: fixed;
  width: 100%;
  td {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  td:nth-child(1) {
    width: 85px;
  }

  td:nth-child(3) {
    width: 50px;
  }
  td:nth-child(4) {
    width: 60px;
  }
  td:nth-child(5) {
    width: 60px;
  }
  thead {
    width: 100%;
    tr {
      width: 100%;
      td {
        text-align: center;
        font-size: 12px;
        background: #b9b9b9;
        color: #fff;
        height: 32px;
        line-height: 32px;
      }
      td:not(:nth-child(1)) {
        border-left: 1px solid #eeeeee;
      }
    }
  }
  .tbody {
    tr {
      width: 100%;
      td {
        text-align: center;
        font-size: 12px;
        height: 32px;
        border-top: 1px solid #eeeeee;
        line-height: 32px;
      }
      td:not(:nth-child(1)) {
        border-left: 1px solid #eeeeee;
      }
    }
    tr:nth-child(2n-1) {
      background: #fff;
    }
    tr:nth-child(2n) {
      background: #f7f7f7;
    }

    .btn_1 {
      display: inline-block;
      padding: 3px;
      background: #565656;
      color: #ffffff;
    }
  }
}
</style>
