<template>
  <div class="layout-box">
    <div class="layout-header">
      <van-nav-bar title="交易明细"
                   left-arrow
                   left-text="返回"
                   @click-left="$router.go(-1)" />
    </div>
    <div class="jiaoyimingxi">
      <div class="search">
        <div class="类型"
             @click="选择彩票类型()">
          {{当前类型.text}}
          <van-icon name="arrow-down" />
        </div>
        <input type="text"
               v-model="query.MemberCode"
               placeholder="会员名">
        <div class="查找框"
             @click="查找()">
          <span class="iconfont icon-weibiaoti--"></span>
          <span>搜索</span>
        </div>
      </div>
      <div class="search">
        <input class="mui-text-center"
               placeholder="开始时间"
               type="text"
               readonly
               v-model="query.StartDate"
               @click="选择时间('StartDate')">
        <span class="至">至</span>
        <input class="mui-text-center"
               placeholder="结束时间"
               type="text"
               readonly
               v-model="query.EndDate"
               @click="选择时间('EndDate')">
        <!-- <div class="time_date" @click="time()">
                    {{dateTime}}&nbsp;
                    <span class="iconfont icon-icon-arrow-bottom2"></span>
                </div> -->
      </div>

      <div class="内容">
        <van-list v-model="loading"
                  :finished="error_1 ||  (!loading && total<=list.length)"
                  finished-text="没有更多了"
                  @load="onLoad"
                  background:
                  #fff;>
          <ul class="mui-table-view">
            <li class="mui-table-view-cell"
                @click="跳转(item)"
                v-for="(item, index) in list"
                :key="index">
              <div class="mui-table">
                <div class="mui-table-cell mui-col-xs-6">
                  <h4 class="mui-ellipsis"
                      :class="{'蓝色字体':item.Code}">({{item.SystemType}}){{item.Type}}</h4>
                  <p>用户：<span class="红色字体">{{item.MemberId}}</span></p>
                  <p class="mui-h6">{{item.Note}}</p>
                </div>
                <div class="mui-table-cell mui-col-xs-6 mui-text-right">
                  <p class="mui-h6 mui-ellipsis">{{item.Createtime | filter_time}}</p>
                  <span class="mui-h5"
                        :class="getAmountColor(item)">{{item.Amount}}</span> 元

                </div>
              </div>
            </li>
          </ul>

        </van-list>
      </div>
    </div>

    <!-- 选择时间弹出层 -->
    <van-popup v-model="showTime"
               position="bottom"
               :overlay="true">
      <!-- <van-datetime-picker v-model="query[时间类型]" type="date" @cancel="时间取消" :min-date="minDate" @confirm="完成时间()" /> -->
      <van-datetime-picker v-model="currentDate"
                           type="date"
                           @cancel="时间取消"
                           @confirm="完成时间()" />
    </van-popup>

    <van-popup v-model="titleShow"
               position="bottom"
               :style="{ height: '40%' }">

      <van-picker show-toolbar
                  :columns="分类"
                  @cancel="titleShow = false"
                  @confirm="onConfirm" />
    </van-popup>

  </div>
</template>

<script>
import { 时间格式化 } from '@/assets/js/通用.js';

import { api_获取下级交易明细 } from '@/api/代理接口.js';
import { mapState, mapActions, mapGetters } from 'vuex';
export default {
  data () {
    return {
      分类: [
        { value: '', text: '全部类型' },
        { value: '0', text: '提款' },
        { value: '1', text: '存款' },
        { value: '2', text: '转出' },
        { value: '3', text: '转入' },
        { value: '4', text: '支出' },
        { value: '5', text: '派奖' },
        { value: '6', text: '优惠' },
        { value: '7', text: '返水' },
        { value: '8', text: '彩金' },
        { value: '9', text: '推荐' },
        { value: '10', text: '返点' },
        { value: '11', text: '返佣' },
        { value: '12', text: '撤单' }
      ],
      titleShow: false,

      nowIndex: 0, // 默认第一个tab为激活状态
      show: false,
      currentDate: new Date(),
      showTime: false,
      minDate: null,
      时间类型: 'StartDate', // 0 表示开始时间
      当前彩种: '',
      error_1: false,

      query: {
        StartDate: '',
        EndDate: '',
        MemberCode: '', // 会员名
        MemberMoneyLogType: '', // 提款 0,存款 1,转出 2,转入 3,支出 4,派奖 5,优惠 6,返水 7,彩金 8,推荐 9,返点 10,返佣 11,撤单 12
        page: 1,
        rows: 20
      },
      list: [],
      loading: true,
      total: 0
    }
  },
  created () {},
  filters: {
    filter_time (time, type) {
      return 时间格式化('yyyy-MM-dd hh:mm', time)
    }
  },
  computed: {
    当前类型 () {
      return this.分类.find(x => x.value == this.query.MemberMoneyLogType)
    }
  },
  methods: {
    onLoad () {
      this.query.page++
    },
    onConfirm (val) {
      this.当前类型.text = val.text
      this.query.MemberMoneyLogType = val.value
      this.获取数据()
      this.titleShow = false
    },
    选择时间 (type) {
      this.时间类型 = type
      this.showTime = true
    },
    完成时间 () {
      this.showTime = false
      if (this.时间类型 == 'StartDate') {
        this.query.StartDate = 时间格式化('yyyy-MM-dd', this.currentDate)
      } else {
        this.query.EndDate = 时间格式化('yyyy-MM-dd', this.currentDate)
      }
      this.list = []
      this.获取数据()
    },
    时间取消 () {
      this.showTime = false
    },
    查找 () {
      this.query.page = 1
      this.list = []
      this.获取数据()
    },
    获取数据 () {
      this.loading = true
      this.error_1 = false
      api_获取下级交易明细(this.query)
        .then(x => {
          console.log(x)
          this.list = [...this.list, ...x.data.rows]
          this.total = x.data.total
          this.loading = false
        })
        .catch(err => {
          this.error_1 = true
          this.loading = false
        })
    },
    选择彩票类型 () {
      this.titleShow = true
    }
  },
  mounted () {
    this.获取数据()
  }
}
</script>

<style lang="scss" scoped>
/deep/ .van-list__finished-text {
  background: #fff;
}
.search {
  flex-shrink: 0;
  background: #fff;
  border-bottom: 1px solid #efeff4;
  height: 50px;
  width: 100%;
  display: flex;
  align-items: center;
  padding: 10px;
  box-sizing: border-box;
  .类型 {
    white-space: nowrap;
    font-size: 12px;
    flex-shrink: 0;
    background: #f2f2f2;
    height: 30px;
    line-height: 30px;
    padding: 0px 10px;
    border-radius: 0.06rem;
    margin: 0px 5px 0px 0px;
    i {
      color: #ff6700;
    }
  }
  input {
    flex-grow: 1;
    height: 30px;
    border-radius: 0.06rem;
    font-size: 12px;
    background-color: #f2f2f2;
    border: none;
    outline: medium;
    margin: 0px;
    padding: 0px 10px;
    width: 20%;
  }
  .查找框 {
    flex-shrink: 0;
    white-space: nowrap;
    background: #ff6700;
    height: 30px;
    padding: 0px 10px;
    border-radius: 5px;
    text-align: center;
    color: #ffffff;
    margin: 0px 0px 0px 10px;
    font-size: 12px;
    display: flex;
    align-items: center;
    .icon-weibiaoti-- {
      font-size: 18px;
    }
  }
  .至 {
    margin: 0px 10px;
  }
}

.内容 {
  flex-grow: 1;
  overflow: auto;
}

.table_2 {
  position: sticky;
  top: 0px;
}
.table_1 {
  width: 100%;
  text-align: center;
  font-size: 13px;
  td {
    padding: 5px;
    border-top: 1px solid #f5f5f5;
  }
  .会员 {
    width: 60px;
  }
  .彩种 {
  }
  .时间 {
    width: 85px;
    white-space: nowrap;
  }
  .金额 {
    width: 70px;
  }
  td:not(:nth-child(1)) {
    border-left: 1px solid #f5f5f5;
  }
  thead {
    background: #cccccc;
  }
  tbody {
    tr:nth-child(2n-1) {
      background: #ffffff;
    }
  }
}

.list_2 {
  > li {
    background: #ffffff;
    display: flex;
    margin: 10px 0px 0px 0px;
    padding: 10px;
    .img_box {
      width: 26px;
      height: 26px;
      flex-shrink: 0;
      margin: 0px 10px 0px 0px;
      img {
        width: 100%;
        height: 100%;
      }
    }
    .text_box {
      flex-grow: 1;
      display: flex;
      flex-direction: column;
      font-size: 14px;
      color: #8f8f94;
      > div {
        display: flex;
        align-items: center;
        justify-content: space-between;
        align-items: baseline;
        margin: 2px 0px;
      }
      .标题 {
        font-weight: bold;
        color: #000000;
      }
      .未结算 {
        color: #28a745;
      }
      .中奖 {
        color: red;
      }
      .未中奖 {
        color: #949494;
      }
      .时间 {
        font-size: 12px;
      }
    }
    .红色字体 {
      color: red;
    }
  }
}
</style>
