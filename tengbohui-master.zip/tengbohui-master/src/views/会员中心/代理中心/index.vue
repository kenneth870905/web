<template>
  <div class="layout-box">
    <div class="layout-header">
      <van-nav-bar title="代理中心"
                   left-arrow
                   left-text="返回"
                   @click-left="$router.go(-1)" />
    </div>
    <div class="agent">
      <div class="head-box">
        <div class="head-img fl">
          <img src="images/user.png"
               alt=""
               class="wh">
        </div>
        <div class="head-title fl">
          <p>{{userinfo.UserId}}</p>
          <p>￥{{userinfo.Money}}</p>
        </div>
      </div>
      <ul class="box_1">
        <li>
          <div>拥有会员</div>
          <p>{{统计.MemberCount}}</p>
        </li>
        <li>
          <div>可用收益</div>
          <p>{{统计.AgentMoney}}</p>
        </li>
        <li>
          <div>总收益</div>
          <p>{{统计.ZShouYi}}</p>
        </li>
      </ul>
      <div class="agency_message">
        <div class="explain_box">
          <div class="explain"
               @click="$router.push('/mine/agent/agencyExplain')">
            <div><span class="iconfont icon-icon_wenhao"></span><span>代理说明</span></div>
            <div>
              <van-icon name="arrow"
                        class="right" />
            </div>
          </div>
          <div class="explain"
               @click="$router.push('/mine/agent/generalizeAdmin')">
            <div><span class="iconfont icon-icon_fenxiang"></span><span>推广管理</span></div>
            <div>
              <van-icon name="arrow"
                        class="right" />
            </div>
          </div>
          <div class="explain"
               @click="$router.push('/mine/records')">
            <div><span class="iconfont icon-qian f_f"></span><span>代理佣金</span></div>
            <div>
              <van-icon name="arrow"
                        class="right" />
            </div>
          </div>
          <!-- 没有对应的api -->
          <div class="explain"
               @click="$router.push('/mine/agent/betDetail')">
            <div><span class="iconfont icon-iconmingxi"></span><span>投注明细</span></div>
            <div>
              <van-icon name="arrow"
                        class="right" />
            </div>
          </div>
          <div class="explain"
               @click="$router.push('/mine/agent/detail')">
            <div><span class="iconfont icon-mingxi"></span><span>交易明细</span></div>
            <div>
              <van-icon name="arrow"
                        class="right" />
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { api_代理统计 } from '@/api/代理接口.js';
import { mapState, mapActions } from 'vuex';
export default {
  data () {
    return {
      统计: {
        AgentId: '',
        AgentMoney: '0.00',
        GradeName: '',
        MemberCount: 0,
        ZShouYi: '0.00'
      }
    }
  },
  computed: {
    ...mapState({
      config: 'config',
      userinfo: state => state.user.userinfo,
      Person: x => x.个人资料.Person
    })
  },
  methods: {
    ...mapActions({
      进入资金明细: '资金明细/进入资金明细',
      getPersonInfo: '个人资料/getPersonInfo'
    })
  },
  mounted () {
    this.getPersonInfo()
    api_代理统计().then(x => {
      var data = x.data
      var obj = {}
      data.forEach(item => {
        obj[item.Key] = item.Value
      })
      this.统计 = obj
    })
  }
}
</script>

<style scoped lang="scss">
.agent {
  overflow: hidden;
}
.head-box {
  padding: 0.8rem 0 0.7rem 0.5rem;
  overflow: hidden;
  background-image: url("../../../assets/agent-bj.b893a037.png");
}
.head-img {
  width: 1.5rem;
  height: 1.5rem;
  img {
    border-radius: 50%;
  }
}
.head-title {
  padding-left: 0.5rem;
  color: #fff;
  height: 1.5rem;
  display: flex;
  flex-direction: column;
  justify-content: flex-end;
  p {
    margin-bottom: 0.3rem;
    float: left;
    color: #fff;
  }
}
.box_1 {
  display: flex;
  justify-content: space-around;
  text-align: center;
  margin-bottom: 5px;
  li {
    text-align: center;
    width: calc(100% / 3);
    display: flex;
    flex-direction: column;
    justify-content: center;
    height: 1.2rem;
    background: #fff;
    div {
      margin-bottom: 2px;
    }
  }
  li:not(:nth-child(1)) {
    border-left: 1px solid #eeeeee;
  }
  div {
    font-size: 14px;
  }
  p {
    margin: 0px;
    color: #000000;
  }
}

.agency_message {
  background: #fff;
  .explain_box {
    padding: 0px 10px 0px 10px !important;
    .explain {
      height: 50px;
      display: flex;
      justify-content: space-between;
      line-height: 50px;
      padding: 0px 10px 0px 10px;
      border-bottom: 1px solid #eee;
      div {
        display: flex;
        align-items: center;
        span:nth-child(1) {
          font-size: 22px;
        }
        span:nth-child(2) {
          padding-left: 10px;
          font-size: 15px;
          //  color:#ccc;
        }
      }
      .right {
        color: #ccc;
      }
    }
  }
}
</style>
