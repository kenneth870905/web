<template>
  <div class="layout-box">
    <div class="layout-header">
      <appHeader headTitle="会员中心" />
    </div>
    <div class="mine">
      <div class="userInfo">
        <div class="userImg fl"
             @click="$router.push('/mine/basic')">
          <img v-if="!Person.ImgId"
               src="images/user.png"
               alt
               srcset
               class="wh" />
          <img v-if="Person.ImgId"
               :src="'images/touxiang/'+Person.ImgId"
               alt
               srcset
               class="wh" />

        </div>
        <ul class="info">
          <li class="fl">
            <div class="username">
              欢迎您，
              <span class="user-name"
                    @click="$router.push('/mine/basic')">{{Person.Nickname ? Person.Nickname :'未设置'}} </span>
            </div>
            <div class="level">
              <span class="vip">
                <!-- <img src="../../assets/images/user.png"
                   alt=""
                   class="wh vip-img"> -->
                <i class="wh vip-img iconfont icon-vip"></i>
              </span>
              <span class="vip-name"
                    @click="$router.push('/mine/vip')">{{等级.MemberVipName ? 等级.MemberVipName : '普通用户'}}</span>
            </div>
          </li>
          <li class="fr">
            <div class="right fr">
              安全等级：
              <span>低</span>
            </div>
          </li>
        </ul>
      </div>
      <div class="account">
        <div class="userMoney">
          <span class="fl">主账户余额</span>
          <span class="fl money">{{ 新钱}}</span>
          <span class="fr refresh-money"
                @click="refresh">
            <i :class="['iconfont','icon-shuaxin',rotate?'go':'']"></i>
            刷新
          </span>
        </div>
        <!-- 没有这个功能 -->
        <!-- <div class="userMoney">
          <span class="fl"
                style="width:1.2rem"> 腾币</span>
          <span class="fl money">0</span>
          <span class="fr history">
            <button>签到</button>
            <button>查看记录</button>
          </span>
        </div> -->

        <ul class="user-bar fl">
          <li @click="$router.push('/deposit')">
            <div class="box">
              <i class="iconfont icon-cunkuan"></i>
            </div>
            <h3>会员存款</h3>
          </li>

          <li @click="$router.push('/withdraw')">
            <div class="box">
              <i class="iconfont icon-bank-card"></i>
            </div>
            <h3>会员提款</h3>
          </li>

          <li @click="$router.push('/changCash')">
            <div class="box">
              <i class="iconfont icon-Transfer_accounts"></i>
            </div>
            <h3>户内转账</h3>
          </li>

          <li @click="$router.push('/discount')">
            <div class="box">
              <i class="iconfont icon-zizhujiaoyi_new"></i>
            </div>
            <h3>自助优惠</h3>
          </li>
        </ul>
      </div>

      <div class="user-nav">
        <div class="user-cell">

          <div class="cell-item"
               @click="$router.push('/mine/personage')">
            <div class="cell-left">
              <span class="my-icon">
                <!-- <i class="iconfont icon-baobiao"></i> -->
                <van-icon name="manager-o" />
              </span>
              <span class="title">个人资料</span>
            </div>
            <div class="cell-right">
              <i class="iconfont icon-right"></i>
            </div>
          </div>

            <div class="cell-item"
               @click="$router.push('/ckjl')">
            <div class="cell-left">
              <span class="my-icon">
                <!-- <i class="iconfont icon-baobiao"></i> -->
                <i class="iconfont icon-cunkuan"></i>
              </span>
              <span class="title">存款记录</span>
            </div>
            <div class="cell-right">
              <i class="iconfont icon-right"></i>
            </div> 
          </div>


          <div class="cell-item"
               @click="$router.push('/order')">
            <div class="cell-left">
              <span class="my-icon">
                <!-- <i class="iconfont icon-baobiao"></i> -->
                <!-- <van-icon name="points" /> -->
                <i class="iconfont icon-zhudanmeixuanzhong"></i>
              </span>
              <span class="title">投注记录</span>
            </div>
            <div class="cell-right">
              <i class="iconfont icon-right"></i>
            </div>
          </div>

          <div class="cell-item"
               @click="$router.push('/mine/records')">
            <div class="cell-left">
              <span class="my-icon">
                <i class="iconfont icon-baobiao"></i>
              </span>
              <span class="title">客户报表</span>
            </div>
            <div class="cell-right">
              <i class="iconfont icon-right"></i>
            </div>
          </div>

          <div class="cell-item"
               @click="$router.push('/mine/agent')">
            <div class="cell-left">
              <span class="my-icon">
                <i class="iconfont icon-daili"></i>
              </span>
              <span class="title">代理中心</span>
            </div>
            <div class="cell-right">
              <i class="iconfont icon-right"></i>
            </div>
          </div>

          <div class="cell-item"
               @click="$router.push('/chatlist')">
            <div class="cell-left">
              <span class="my-icon">
                <i class="iconfont icon-tongxunlu"></i>
              </span>
              <span class="title">通讯录</span>
            </div>
            <div class="cell-right">
              <!-- <span class="tips">5</span> -->
              <i class="iconfont icon-right"></i>
            </div>
          </div>

          <div class="cell-item"
               @click="$router.push('/notice')">
            <div class="cell-left">
              <span class="my-icon">
                <i class="iconfont icon-gonggao1"></i>
              </span>
              <span class="title">公告信息</span>
            </div>
            <div class="cell-right">
              <!-- <span class="tips">5</span> -->
              <i class="iconfont icon-right"></i>
            </div>
          </div>

          <div class="cell-item"
               @click="$router.push('/mine/vip')">
            <div class="cell-left">
              <span class="my-icon">
                <i class="iconfont icon-jinjitiaojian"></i>
              </span>
              <span class="title">VIP列表</span>
            </div>
            <div class="cell-right">
              <i class="iconfont icon-right"></i>
            </div>
          </div>
          <div class="cell-item"
               @click="$router.push('/kfzx')">
            <div class="cell-left">
              <span class="my-icon">
                <i class="iconfont icon-kefu"></i>
              </span>
              <span class="title">客服中心</span>
            </div>
            <div class="cell-right">
              <i class="iconfont icon-right"></i>
            </div>
          </div>

          <div class="cell-item"
               @click="$router.push('/suggest')">
            <div class="cell-left">
              <span class="my-icon">
                <i class="iconfont icon-jianyi"></i>
              </span>
              <span class="title">意见反馈</span>
            </div>
            <div class="cell-right">
              <i class="iconfont icon-right"></i>
            </div>
          </div>

          <!-- <div class="cell-item"
               @click="$router.push('/mine/vip')">
            <div class="cell-left">
              <span class="my-icon">
                <i class="iconfont icon-jinjitiaojian"></i>
              </span>
              <span class="title">VIP列表</span>
            </div>
            <div class="cell-right">
              <i class="iconfont icon-right"></i>
            </div>
          </div> -->

        </div>
      </div>
      <button class="user-exit"
              @click="goOut()">退出当前账号</button>
    </div>
    <div class="layout-footer">
      <appFooter />
    </div>
  </div>

</template>

<script>
import appHeader from '@/components/头部';
import appFooter from '@/components/尾部';
import { api_退出登录 } from '@/api/登录接口.js';
import { mapMutations, mapActions, mapState } from 'vuex';
import { number_format } from '@/assets/js/通用.js';

export default {
  components: {
    appHeader,
    appFooter
  },
  data () {
    return {
      rotate: false
    }
  },
  computed: {
    ...mapState({
      userinfo: x => x.user.userinfo,
      等级: x => x.user.等级,
      config: 'config',
      Person: x => x.个人资料.Person
    }),
    新钱 () {
      if (!this.userinfo.Money) {
        return 0.0
      } else {
        return number_format(this.userinfo.Money)
      }
    }
  },
  methods: {
    ...mapMutations({
      加载中: '加载中'
    }),
    ...mapActions({
      getUserInfo: 'user/getUserInfo',
      getPersonInfo: '个人资料/getPersonInfo'
    }),
    refresh () {
      this.rotate = !this.rotate
      setTimeout(() => {
        this.rotate = false
      }, 1500)
      this.getUserInfo()
    },

    async goOut (url) {
      try {
        var r = await api_退出登录()
      } catch (error) {
        console.log(error)
        this.$toast('系统错误，稍后再试！')
      }
      if (r.data.code == 0) {
        this.$toast('退出成功')
        this.$router.push('/')
      } else {
        this.$toast(r.data.msg)
      }
      this.getUserInfo()
    }
  },
  mounted () {
    this.getPersonInfo()
  }
}
</script>

<style lang="scss" scoped>
.cell-item:nth-child(1) > .cell-left > .my-icon {
  background: #a93c55;
}
.cell-item:nth-child(2) > .cell-left > .my-icon {
  background: rgb(0, 184, 204);
}
.cell-item:nth-child(3) > .cell-left > .my-icon {
  background: rgb(41, 201, 0);
}
.cell-item:nth-child(4) > .cell-left > .my-icon {
  background: rgb(209, 130, 24);
}
.cell-item:nth-child(5) > .cell-left > .my-icon {
  background: rgb(138, 61, 186);
}
.cell-item:nth-child(6) > .cell-left > .my-icon {
  background: rgb(36, 105, 251);
}
.cell-item:nth-child(7) > .cell-left > .my-icon {
  background: rgb(253, 43, 3);
}
.cell-item:nth-child(8) > .cell-left > .my-icon {
  background: rgb(141, 122, 56);
}
.cell-item:nth-child(9) > .cell-left > .my-icon {
  background: rgb(163, 44, 0);
}
.cell-item:nth-child(10) > .cell-left > .my-icon {
  background: #5f4035;
}
.go {
  transform: rotate(720deg);
  transition: all 1s;
  animation-iteration-count: infinite;
}
@keyframes go {
  0% {
    transform: rotateZ(0);
  }
  100% {
    transform: rotateZ(360deg);
  }
}
.mine {
  background: #ececec;

  flex: 1;
  overflow-x: scroll;
  .userInfo {
    height: 1.8rem;
    background: #fff;

    .userImg {
      width: 1.2rem;
      height: 1.2rem;
      line-height: 1.2rem;
      text-align: center;
      overflow: hidden;
      margin: 0.3rem 0.3rem 0.3rem 0.2rem;
      background: #efe5e4;
      border-radius: 50%;
    }
    .info {
      padding: 0.32rem 0;
      color: #444;
      li {
        padding: 0.1rem 0;
        .username {
          color: #aaa;
          font-size: 0.24rem;
          margin-right: 0.2rem;
          span {
            color: #06f;
            font-size: 0.28rem;
          }
        }
        .level {
          position: relative;
          margin: 0.12rem 0 0 0;
          background: #a99963;
          line-height: 0.4rem;
          border-radius: 0.4rem;
          color: #fff;
          .vip {
            position: absolute;
            left: 5px;
            top: 1px;
            width: 0.4rem;
            height: 0.4rem;
            overflow: hidden;
            text-align: center;
            i {
              font-size: 0.3.5rem;
            }
          }
          .vip-name {
            padding-left: 0.6rem;
            font-size: 0.24rem;
            padding-right: 0.4rem;
          }
        }
        .right {
          padding: 0 0.25rem;
          font-size: 0.22rem;
          line-height: 0.6rem;
          background: #fff;
          border: 1px solid #eee;
          box-shadow: -0.01rem 0.05rem 0.3rem rgba(0, 0, 0, 0.05);
          border-right: none;
          color: #aaa;
          border-radius: 0.6rem 0 0 0.6rem;
          span {
            color: #f80;
          }
        }
      }
    }
  }
  .account {
    background: #fff;
    margin-top: 0;
    overflow: hidden;
    .userMoney {
      float: left;
      width: 100%;
      font-size: 0.24rem;
      color: #bbb;
      height: 1.08rem;
      padding: 0 0 0 0.3rem;
      line-height: 1.08rem;
      border-top: 1px solid #f5f5f5;
      border-bottom: 1px solid #f5f5f5;
      background: #fff;
      box-sizing: border-box;
      .money {
        font-size: 0.32rem;
        color: #f01924;
        font-weight: 400;
        margin: 0 0.12rem 0 0.2rem;
      }
      i {
        position: absolute;
        left: -5px;
        top: 2px;
      }
      .refresh-money {
        color: #aaa;
        padding: 0 0.3rem;
        font-size: 0.24rem;
        position: relative;
      }
      .history {
        color: #aaa;
        padding: 0 0.3rem;
        font-size: 0.24rem;
        button {
          color: #fff;
          background: #ff3a2b;
          border: none;
          border-radius: 4px;
          height: 0.6rem;
          padding: 0 0.24rem;
          margin-right: 3px;
          line-height: 0.6rem;
        }
      }
    }
    .user-bar {
      display: flex;
      width: 100%;
      justify-content: space-around;
      align-items: center;
      padding: 0.25rem 0 0.1rem 0;
      li {
        .box {
          width: 0.96rem;
          height: 0.96rem;
          background-image: linear-gradient(180deg, #a08dff, #c5a2ff);
          border-radius: 44%;
          overflow: hidden;
          margin: 0 auto;
          text-align: center;
          line-height: 0.96rem;
          color: #fff;
          i {
            font-size: 0.4rem;
          }
        }
        h3 {
          font-size: 0.22rem;
          font-weight: 500;
          text-align: center;
          color: #aaa;
          line-height: 0.5rem;
        }
      }
      li:nth-child(2) > .box {
        background-image: linear-gradient(180deg, #ff7884, #ff71b5);
      }
      li:nth-child(3) > .box {
        background-image: linear-gradient(180deg, #ffbb57, #ffcf41);
      }
      li:nth-child(4) > .box {
        background-image: linear-gradient(180deg, #ff396b, #ff396b);
      }
    }
  }
  .user-nav {
    margin: 0.15rem 0 0 0;
    .user-cell {
      background-color: #fff;
      .cell-item {
        padding-left: 0.24rem;
        min-height: 1.2rem;
        display: flex;
        align-items: center;
        justify-content: space-between;
        border-bottom: 1px solid #eee;
        .cell-left {
          display: flex;
          align-items: center;
          .title {
            font-size: 0.26rem;
          }
          .my-icon {
            width: 0.64rem;
            height: 0.64rem;
            line-height: 0.64rem;
            border-radius: 38%;
            opacity: 1;
            text-align: center;
            margin-right: 0.2rem;
            display: inline-block;
            overflow: hidden;
            i {
              color: #fff;
            }
          }
        }
        .cell-right {
          padding: 0 0.3rem;
          width: 50%;
          text-align: right;
          .tips {
            background: #fc0;
            color: #fff;
            font-size: 0.22rem;
            line-height: 0.4rem;
            padding: 0 0.2rem;
            border-radius: 0.4rem;
          }
          i {
            padding-left: 0.24rem;
          }
        }
      }
    }
  }
  .user-exit {
    width: 96%;
    margin: 0.2rem 2% 0.3rem 2%;
    height: 0.88rem;
    border-color: #e3e3e3;
    background: #fcfcfc;
    color: #999;
    border: 1px solid #ccc;
    border: none;
    font-size: 0.26rem;
    border-radius: 4px;
  }
}
.user-name {
  width: 1.5rem;
  text-overflow: ellipsis;
  overflow: hidden;
  white-space: nowrap;
  display: inline-block;
}
</style>
