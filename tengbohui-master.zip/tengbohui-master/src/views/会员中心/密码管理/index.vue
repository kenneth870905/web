<template>

  <div class="layout-box">
    <div class="layout-header">
      <van-nav-bar title="密码管理"
                   left-arrow
                   left-text="返回"
                   @click-left="$router.go(-1)" />
    </div>
    <div class="mmgl">
      <van-tabs v-model="active"
                line-width="20%"
                line-height="3px"
                title-active-color="#ff3a2b">
        <aqwt />
        <xgaqmm />
        <xgdlmm />
      </van-tabs>

    </div>
  </div>

</template>

<script>
import { Toast } from 'vant';
import JSEncrypt from 'jsencrypt';
// const xgdlmm = () => import('./修改登录密码.vue')
// const xgaqmm = () => import('./修改安全密码.vue')
// const aqwt = () => import('./修改安全问题.vue')

export default {
  // components: {
  //   xgdlmm,
  //   xgaqmm,
  //   aqwt
  // },
  data () {
    return {
      active: 0
    }
  }
}
</script>

<style lang="scss" scoped>
/deep/.van-field__body input {
  border: none;
  margin-bottom: 0;
}
.mmgl {
  flex: 1;
  overflow-x: scroll;
  .aqmm {
    .notice {
      display: block;
      font-size: 0.22rem;
      color: #bbb;
      text-align: center;
      padding: 0.1rem 0;
      width: 100%;
      line-height: 0.3rem;
      margin-bottom: -0.2rem;
      background: none;
    }
    .aqmm-box {
      width: 96%;
      margin: 0.2rem 0 0 2%;
      border-radius: 6px;
      border: 1px solid #eee;
      box-shadow: 0 0 0.5rem rgba(0, 0, 0, 0.06);
      overflow: hidden;
    }
  }
}
</style>
