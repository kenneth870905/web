<template>
  <div class="layout-box">
    <div class="layout-header">
      <van-nav-bar title="修改登录密码"
                   left-arrow
                   left-text="返回"
                   @click-left="$router.go(-1)" />
    </div>

    <div class="mui-content mui-fullscreen">
      <div class="list">
        <van-cell-group>
          <van-field v-model="pwd"
                     label="当前密码"
                     placeholder="长度6-20"
                     type="password" />
          <van-field type="password"
                     v-model="newPwd"
                     label="新密码"
                     placeholder="长度6-20" />
          <van-field v-model="newPwd_2"
                     label="确认密码"
                     type="password"
                     placeholder="请确认密码" />
        </van-cell-group>
      </div>

    </div>
    <button class="btn"
            @click="提交()">确认修改</button>
  </div>
</template>

<script>
import JSEncrypt from 'jsencrypt';
import { api_修改登录密码 } from '@/api/个人资料.js';

import { mapState } from 'vuex';
export default {
  name: '',

  data () {
    return {
      pwd: '',
      newPwd: '',
      newPwd_2: ''
    }
  },
  computed: {
    ...mapState({
      publicKey: 'publicKey'
    })
  },
  methods: {
    提交 () {
      if (!this.pwd) {
        this.$toast('请输入旧密码')
        return;
      } else if (this.pwd.length < 6 || this.pwd.length > 20) {
        this.$toast('旧密码长度错误')
        return;
      } else if (!this.newPwd) {
        this.$toast('请输入新密码')
        return;
      } else if (this.newPwd.length < 6 || this.newPwd.length > 20) {
        this.$toast('新密码长度有误')
        return;
      } else if (this.newPwd != this.newPwd_2) {
        this.$toast('两次密码不一致')
        return;
      }
      var layout_encrypt = new JSEncrypt()
      layout_encrypt.setPublicKey(this.publicKey)
      var obj = {
        pwd: layout_encrypt.encrypt(this.pwd),
        newPwd: layout_encrypt.encrypt(this.newPwd)
      }

      api_修改登录密码(obj)
        .then(x => {
          if (x.data.code == 0) {
            this.$toast('设置成功')
          } else {
            this.$toast(x.data.msg)
          }
        })
        .catch(err => {
          this.$toast('系统错误稍后再试')
        })
    }
  }
}
</script>

<style lang="scss" scoped>
.mui-content {
  background: #f5f5f5;
  margin: 0.2rem 0 0 2%;
  border-radius: 6px;
  border: 1px solid #eee;
  width: 96%;
}
.mui-fullscreen {
  position: inherit;
}
.list {
  border-radius: 6px;
  /deep/ .van-field {
    input {
      padding: 0px;
      margin: 0px;
      border: none;
      height: auto;
    }
  }
}
.btn {
  width: 96%;
  margin-left: 2%;
  height: 0.88rem;
  background-color: #f01924;
  color: #fff;
  box-shadow: 0 0.03rem 0.3rem rgba(220, 0, 0, 0.2);
  display: block;
  margin-top: 0.3rem;
  font-size: 0.26rem;
  border-radius: 4px;
  border: none;
}
</style>
