<template>
<div class="layout-box">
  <div class="layout-header">
    <van-nav-bar title="意见反馈" left-arrow left-text="返回" @click-left="$router.go(-1)" />
  </div>
  <div class="suggest">
    <div class="Cont-Spacing-02">
      <div class="m-cell-box">
        <div class="m-cell">
          <!---->
          <div class="cell-item">
            <div class="cell-left"><span class="cell-icon"></span><span class="title">反馈标题</span></div>
            <div class="cell-right">
              <div class="m-input">
                <input type="text" maxlength="16" placeholder="请输入反馈标题" autocomplete="off" v-model="tel">

              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="Cont-Spacing-02">
      <div class="m-cell-box sug-xuanzhe">
        <div class="m-cell">
          <div class="cell-item" @click="选择反馈类型()">
            <div class="cell-left">
              <span class="cell-icon"></span>
              <span class="title">反馈类型</span>
              <span class="sort">{{ name ? name : '选择反馈类型'}}</span>
            </div>
            <div class="cell-right cell-arrow">
              <van-icon name="arrow" />
            </div>
          </div>
          <div class="cell-item" style="align-items: flex-start;">
            <div class="cell-left">
              <span class="cell-icon"></span>
              <span class="title" style="padding-top: 0.24rem;">意见反馈</span>
            </div>
            <div class="cell-right">
              <div class="m-textarea" style="height: 3rem;">
                <textarea placeholder="请输入您的建议..." maxlength="400" v-model="textarea">
                            </textarea>
                <div class="textarea-counter">{{textareaNum}}/400</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <button class="btnSubmit btn-boxshadow btn-block btn-primary" @click="submit">确认</button>
    <div>

    </div><span style="font-size: 0.22rem; color: rgb(170, 170, 170); display: block; text-align: center; padding-top: 0.4rem;">电话号码如需修改，请联系
      <span class="blueColor" @click="联系客服()">在线客服</span></span>
  </div>

  <!-- 弹出菜单 -->
  <van-action-sheet v-model="show" :actions="actions" cancel-text="取消" @select="onSelect" />
</div>
</template>

<script>
import {
  api_添加反馈
} from "@/api/反馈接口.js";
import {mapMutations} from 'vuex'
export default {
  data() {
    return {
      show: false,
      name: '产品BUG',
      textarea: '',
      tel: '',
      actions: [{
          name: '产品BUG'
        },
        {
          name: '吐槽'
        },
        {
          name: '功能建议'
        },
        {
          name: '其他'
        }

      ]
    }
  },
  computed: {
    textareaNum() {
      return this.textarea.length
    }
  },
  methods: {
    ...mapMutations({
      加载中: "加载中"
    }),
    选择反馈类型() {
      this.show = true
    },
    onSelect(e) {
      this.show = false
      this.name = e.name
    },
    submit() {
      if (!this.tel) {
        this.$toast('请输入您的反馈标题')
        return;
      } else if (!this.textarea) {
        this.$toast('请输入您的建议')
        return;
      }
      this.加载中(true);
       let obj = {
          title: this.tel,
          feedbacktype: this.name,
          content: this.textarea
        }
      api_添加反馈(obj).then(x => {
        if (x.data.code == 0) {
           this.$toast('提交成功，请您耐心等待')
           this.加载中(false)
           this.tel = ''
           this.textarea = ''
        } else{
           this.$toast(r.data.msg);
           this.加载中(false)
        }
      }).catch(err => {
        this.$toast('系统错误稍后再试')
        this.加载中(false);
        return
      })
      
      // try {
      //   let obj = {
      //     tel: this.tel,
      //     name: this.name,
      //     textarea: this.textarea
      //   }
      //   var r = api_添加反馈(obj)
      // } catch (error) {
      //   this.$toast('系统错误稍后再试')
      //   this.加载中(false);
      //   return
      // }
      // this.加载中(false);
      // if (r.data.code == 0) {
      //   this.$toast('提交成功，请您耐心等待')
      // } else {
      //   this.$toast(r.data.msg);
      // }

    },
    联系客服() {
      window.location.href = config.online_chat
    }
  }
}
</script>

<style lang="scss" scoped>
.suggest {
  font-size: 0.24rem;
}

.Cont-Spacing-02 {
  width: 96%;
  margin: 0.2rem 0 0 2%;
  border-radius: 6px;
  border: 1px solid #eee;
  box-shadow: 0 0 0.5rem rgba(0, 0, 0, 0.06);
  overflow: hidden;
  position: relative;
  z-index: 6;
}

.suggest .sug-xuanzhe {
  position: relative;
}

.m-cell {
  background-color: #fff;
}

.cell-item {
  display: flex;
  position: relative;
  padding-left: 0.24rem;
  overflow: hidden;
  border-bottom: 1px solid #eee;

  .cell-left {
    display: flex;
    align-items: center;
    color: #666;
    white-space: nowrap;

    .cell-icon {
      display: block;
      margin-right: 0.1rem;
    }

    .title {
      width: 1.8rem;
      display: inline-block;
    }

    .sort {
      color: #699deb;
      font-size: 0.26rem;
    }
  }

  .cell-right {
    flex: 1;
    width: 100%;
    min-height: 1.2rem;
    color: grey;
    text-align: right;
    padding-right: 0.24rem;
    justify-content: flex-end;
    font-size: 0.26rem;

    .m-textarea {
      padding: 0.2rem 0;
      background-color: #fff;
      width: 100%;
      height: 3rem;

      textarea {
        border: none;
        width: 100%;
        display: block;
        height: 1.5rem;
        font-size: 0.26rem;
      }

      .textarea-counter {
        position: absolute;
        bottom: 0.2rem;
        right: 0.2rem;
        font-size: 0.28rem;
        color: #ccc;
        text-align: right;
        padding-top: 0.06rem;
      }
    }

    .m-input {
      display: flex;
      width: 100%;
      height: 100%;
      align-items: center;

      input {
        flex: 1;
        height: 1.2rem;
        border: none;
        font-size: 0.26rem;
        background: transparent;
        color: #666;
        display: flex;
        justify-content: flex-start;
        align-items: center;
        text-align: left;
      }
    }
  }
}

.cell-arrow {
  display: flex;
  align-items: center;
}

.btnSubmit {
  width: 96%;
  margin-left: 2%;
  height: 0.88rem;
  background-color: #f01924;
  color: #fff;
  margin-top: 0.3rem;
  display: block;
  border: none;
  font-size: 0.26rem;
  border-radius: 4px;
}

.blueColor {
  color: #09f;
}

input::placeholder,
textarea::placeholder {
  color: #ccc;
}

.van-action-sheet__name {
  font-size: 0.3rem;
}
</style>
