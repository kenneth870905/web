<template>
  <div class="app-home">
    <div class="app-header">
      <appHeader />
    </div>
    <div class="app-main">
      <!-- 轮播图 -->
      <appBanner />
      <!-- 功能栏 -->
      <appNavBar />
      <!-- 热门栏 -->
      <appHotGame />
      <!-- 电游平台 -->
      <dypt></dypt>
      <!-- 游戏总和 -->
      <yxzh></yxzh>
    </div>

    <div class="app-footer">
      <appFooter />
    </div>

    <BackTop container=".app-main"
             :distance="200" />

  </div>
</template>

<script>
const dypt = () => import('./components/电游平台')
const yxzh = () => import('./components/游戏总和')
const appHeader = () => import('@/components/头部')
const appBanner = () => import('./components/轮播图')
const appNavBar = () => import('./components/功能栏')
const appHotGame = () => import('./components/热门栏')
const appFooter = () => import('@/components/尾部')
export default {
  components: {
    appHeader,
    appBanner,
    appNavBar,
    appHotGame,
    appFooter,
    dypt,
    yxzh
  },
  data () {
    return {

    }
  },

}
</script>

<style lang="scss" scoped>
.app-home {
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  .app-header {
    width: 100%;
    height: 0.88rem;
  }
  .app-main {
    flex: 1;
    overflow-x: hidden;
  }
  .app-footer {
    width: 100%;
    height: 0.88rem;
    background: black;
  }
}
</style>
