<template>
  <div>
    <div class="rmyx">
      <div class="rmyx-title">
        <span>捕鱼游戏</span>
      </div>
      <div class="buyupic" @click="$router.push('/fishGame')">
        <img src="
           images/捕鱼游戏/tb-buyu.06f16946.jpg" alt />
      </div>
      <div class="newegame">
        <div class="newegame-box">
          <div
            class="newegame-list"
            v-for="(item,index) in fourFish"
            :key="item.id"
            @click="跳转游戏(item)"
          >
            <div class="img-box">
              <img v-lazy="`images/捕鱼游戏/${item.id}.jpg`" alt />
            </div>
            <h2 class="title">{{item.title}}</h2>
            <p>{{item.typeTitle}}</p>
          </div>
        </div>
      </div>
      <div class="games">
        <div class="game-box" v-for="(item,index) in 捕鱼游戏" :key="item.id">
          <div class="fl" style="position: relative;">
            <div class="tb-img">
              <img v-lazy="`images/捕鱼游戏/${item.id}.jpg`" />
              <div class="egamepic-shadow"></div>
            </div>
            <div class="fl">
              <h2>{{item.title}}</h2>
              <span>{{item.typeTitle}}</span>
              <p>{{item.desc}}</p>
            </div>
          </div>
          <div class="fr">
            <div class="btn-link" @click="跳转游戏(item)">进入大厅</div>
          </div>
        </div>
      </div>
    </div>
    <!-- 真人娱乐 -->
    <div class="zryl">
      <div class="rmyx">
        <div class="rmyx-title">
          <span>真人娱乐</span>
        </div>
        <div class="games" @click="$router.push('/liveCasino')">
          <img src="images/真人娱乐/zryl.jpg" alt />
        </div>

        <div class="game-box zryl" v-for="(item,index) in 真人娱乐" :key="item.id">
          <div class="tb-box">
            <div class="fl" style="position: relative;">
              <div class="tb-img aaa">
                <img v-lazy="`images/真人娱乐/${item.id}.png`" />
                <div class="egamepic-shadow"></div>
              </div>
              <div class="fl">
                <h2>{{item.title}}</h2>
                <span>{{item.desc1}}</span>
                <p>{{item.desc2}}</p>
              </div>
            </div>
            <div class="fr">
              <div class="btn-link" @click="跳转游戏(item)">进入大厅</div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- 棋牌游戏 -->
    <div class="rmyx">
      <div class="rmyx-title">
        <span>棋牌游戏</span>
      </div>
      <div class="game-box" v-for="(item,index) in 棋牌游戏" :key="item.id">
        <div class="tb-box">
          <div class="fl" style="position: relative;">
            <div class="tb-img">
              <img v-lazy="`images/棋牌游戏/${item.id}.png`" />
              <div class="egamepic-shadow"></div>
            </div>
            <div class="fl">
              <h2>{{item.title}}</h2>
              <span>{{item.desc1}}</span>
              <p>{{item.desc2}}</p>
            </div>
          </div>
          <div class="fr">
            <div class="btn-link" @click="跳转游戏(item)">进入大厅</div>
          </div>
        </div>
      </div>
    </div>
    <!-- 体育赛事 -->
    <div class="rmyx">
      <div class="rmyx-title">
        <span>体育赛事</span>
      </div>
      <div class="game-box" v-for="(item,index) in 体育赛事" :key="item.id">
        <div class="tb-box">
          <div class="fl" style="position: relative;">
            <div class="tb-img">
              <img v-lazy="`images/体育赛事/${item.id}.png`" />
              <div class="egamepic-shadow"></div>
            </div>
            <div class="fl">
              <h2>{{item.title}}</h2>
              <span>{{item.desc1}}</span>
              <p>{{item.desc2}}</p>
            </div>
          </div>
          <div class="fr">
            <div class="btn-link" @click="跳转游戏(item)">进入大厅</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { mapState, mapActions } from 'vuex';
import { Dialog } from 'vant';
export default {
  data() {
    return {
      fourFish: [],
      捕鱼游戏: [],
      真人娱乐: [],
      棋牌游戏: [],
      体育赛事: [],
    }
  },
  computed: {
    ...mapState({
      userinfo: x => x.user.userinfo
    })
  },
  methods: {
    ...mapActions({
      设置类型: '进入游戏/设置类型'
    }),
    跳转游戏(item) {
      if (this.userinfo.UserId) {
        this.设置类型(item)
      } else {
        this.$store.commit('setIsLoginShow', true)
      }
    },

  },
  created() {
    this.$axios.get('json/homeList.json').then(x => {
      this.fourFish = x.data[2].children.slice(6, 10)
      this.捕鱼游戏 = x.data[2].children
      this.真人娱乐 = x.data[3].children
      this.棋牌游戏 = x.data[4].children
      this.体育赛事 = x.data[5].children
    })
  }
}
</script>

<style lang="scss" scoped>
.rmyx {
  padding-bottom: 0;
  margin-top: 0.2rem;
  &-title {
    background: #fcfcfc;
  }
}
.buyupic {
  width: 100%;
  height: 136px;
  margin: 0.12rem 0.1rem 0 0.1rem;
  box-shadow: 0 2px 6px rgba(0, 0, 50, 0.25);
  background: #fff;
  img {
    width: 100%;
    height: 100%;
  }
}

.newegame {
  margin-top: 0;
  padding-top: 0.1rem;
  border-bottom: 1px solid #f3f3f3;
  box-shadow: 2px 0 5px rgba(0, 0, 0, 0.05);
  padding-bottom: 0.24rem;
  &-box {
    display: flex;
    justify-content: space-around;
    .newegame-list {
      display: flex;
      flex-direction: column;
      text-align: center;

      .img-box {
        width: 1.28rem;
        height: 1.28rem;
        border: 1px solid #e6e6e6;
        -webkit-box-shadow: 2px 2px 8px rgba(80, 0, 0, 0.15);
        box-shadow: 2px 2px 8px rgba(80, 0, 0, 0.15);
        margin: 0.28rem auto 0 auto;
        overflow: hidden;
        border-radius: 16px;
        position: relative;
        img {
          width: 100%;
          height: 100%;
          border-radius: 16px;
        }
      }
      .title {
        color: #111;
        font-weight: 400;
        font-size: 0.24rem;
        line-height: 0.32rem;
        margin-top: 0.14rem;
      }
      p {
        font-size: 0.22rem;
        color: #ccc;
      }
    }
  }
}
.games {
  width: 100%;
  overflow: hidden;
  img {
    width: 100%;
  }
}
.game-box {
  width: auto;
  overflow: hidden;
  clear: both;
  margin: 0 0.2rem;
  border-bottom: 1px solid #f2f2f2;
  padding: 0.2rem 0;
}
.fl {
  float: left;
  h2 {
    font-weight: 400;
    font-size: 0.26rem;
    color: #111;
    line-height: 0.36rem;
    margin-top: 0.14rem;
  }
  span {
    line-height: 0.36rem;
    font-size: 0.24rem;
    color: #aaa;
    display: block;
    padding-top: 0.02rem;
    border: none;
    margin: 0;
    padding-left: 0;
  }
  p {
    font-size: 0.24rem;
    color: #ccc;
    height: 0.3rem;
    line-height: 0.4rem;
  }
}
.tb-img {
  float: left;
  width: 1.28rem;
  height: 1.28rem;
  line-height: 1.28rem;
  border-radius: 16px;
  text-align: center;
  color: #666;
  // background-image: linear-gradient(to right bottom, #47c0f5, #3eeac4);
  margin-top: 2px;
  margin-right: 0.24rem;
  -webkit-box-shadow: 2px 2px 8px rgba(80, 0, 0, 0.15);
  box-shadow: 2px 2px 8px rgba(80, 0, 0, 0.15);
  overflow: hidden;
  position: relative;
  img {
    width: 100%;
    border-radius: 16px;
    position: absolute;
    left: 0;
    top: 0;
    right: 0;
    bottom: 0;
    margin: auto;
  }
}

.fr {
  float: right;
  .btn-link {
    display: inline-block;
    text-align: center;
    margin-top: 0.32rem;
    font-size: 0.24rem;
    height: 0.64rem;
    line-height: 0.64rem;
    color: #fff;
    width: 1.68rem;
    padding: 0;
    border-radius: 0.34rem;
    background-image: linear-gradient(180deg, #ff2549, #ff9280);
  }
}
</style>
