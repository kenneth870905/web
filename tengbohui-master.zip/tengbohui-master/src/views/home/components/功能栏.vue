<template>
  <div class="nav-container">

    <div class="nav-item"
         @click="$router.push('/chatBoxes')">
      <div class="nav-item-box">
        <i class="iconfont icon-kefu"></i>
      </div>
      <p>聊天室</p>
    </div>

    <div class="nav-item"
         @click="显示礼包弹框=true">
      <div class="nav-item-box">
        <i class="iconfont icon-youhui2"></i>
      </div>
      <p>天天礼包</p>
    </div>

    <div class="nav-item"
         @click="免费试玩()">
      <div class="nav-item-box">
        <i class="iconfont icon-shiwan1"></i>
      </div>
      <p>试玩</p>
    </div>
    <div class="nav-item"
         @click="$router.push('/notice')">
      <div class="nav-item-box">
        <i class="iconfont icon-gonggao1"></i>
      </div>
      <p>公告</p>
    </div>

    <div class="nav-item"
         @click="$router.push('/caipiao')">
      <div class="nav-item-box">
        <i class="iconfont icon-caipiao"></i>
      </div>
      <p>彩票</p>
    </div>

    <transition name="bounce">
      <!-- <transition> -->
      <lbtk v-if="显示礼包弹框" />
    </transition>
  </div>
</template>

<script>
import { api_登录试玩 } from '@/api/登录接口.js';
import { mapState, mapActions, mapMutations } from 'vuex';
const lbtk = () => import('@/components/礼包弹框.vue')

export default {
  components: {
    lbtk
  },
  provide () {
    return {
      关闭礼包弹框: () => {
        this.显示礼包弹框 = false
      }
    }
  },
  data () {
    return {
      显示礼包弹框: false
    }
  },
  computed: {
    ...mapState({
      进入游戏: x => x.进入游戏,
      userinfo: x => x.user.userinfo
    })
  },
  methods: {
    ...mapActions({
      获取平台余额: '进入游戏/获取平台余额',
      getUserInfo: 'user/getUserInfo'
    }),
    download () {
      window.location.href = config.app_download
    },
    async 免费试玩 () {
      if (this.userinfo.UserId) {
        this.$toast('请先退出当前账号')
        return;
      }
      var r = await api_登录试玩()
      if (r.data.code == 0) {
        this.$toast('登录成功')
        this.getUserInfo()
        // this.获取平台余额()
      } else {
        this.$toast(r.data.msg)
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.nav-container {
  display: flex;
  align-items: center;
  padding-top: 0.2rem;
  background-color: #fff;
  text-align: center;
  box-shadow: 0 1px 0.25rem rgba(0, 0, 0, 0.06);
  justify-content: space-around;
  margin-bottom: 0.2rem;
  .nav-item-box {
    width: 0.76rem;
    height: 0.76rem;
    border-radius: 44%;
    background-image: linear-gradient(to right bottom, #6b83fa, #caa2fd);
  }
  .nav-item:nth-child(2) > .nav-item-box {
    background-image: linear-gradient(to right bottom, #47c0f5, #3eeac4);
  }
  .nav-item:nth-child(3) > .nav-item-box {
    background-image: linear-gradient(to right bottom, #ff2549, #ff8080);
  }
  .nav-item:nth-child(4) > .nav-item-box {
    background-image: linear-gradient(to right bottom, #ff9d0b, #ffdd57);
  }
  .nav-item:nth-child(5) > .nav-item-box {
    background: linear-gradient(
      to right bottom,
      rgb(77, 144, 255),
      rgb(135, 211, 255)
    );
  }
  i {
    color: #fff;
    line-height: 0.76rem;
    font-size: 0.4rem;
  }
  p {
    line-height: 0.48rem;
    color: #444;
    font-size: 0.24rem;
    height: 0.64rem;
  }
}
.nav-item {
  display: flex;
  flex-direction: column;
  align-items: center;
}
</style>
