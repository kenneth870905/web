<template>
  <div class="rmyx dypt">
    <div class="rmyx-title dypt-title">
      <span>电游平台</span>
    </div>
    <div class="dypt-banner">
      <div class="box">
        <swiper :options="swiperOption">
          <swiper-slide v-for="(item, index) in 电游平台" :key="item.id">
            <div class="swiper-item" @click="$router.push(`/eGames/${item.gameId}`)">
              <div class="dypt-img">
                <img :src="`images/电游平台/${item.id}.jpg`" alt />
              </div>
              <div class="dypt-text">
                <div
                  class="dypt-text-img"
                  style="background-image: linear-gradient(to right bottom,#ff9d0b,#ffdd57);"
                >
                  <img :src="`images/${item.title}.png`" alt />
                </div>
                <div class="text-box">
                  <h2>{{item.title}}</h2>
                  <p>{{item.desc1}}</p>
                </div>
              </div>
            </div>
          </swiper-slide>

          <div class="swiper-pagination" slot="pagination"></div>
        </swiper>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      swiperOption: {
        autoplay: true,
        slidesPerView: 2,
        spaceBetween: 30,
        slidesPerGroup: 2,
        loopFillGroupWithBlank: true,
        pagination: {
          el: '.swiper-pagination',
          clickable: true
        }
      },
      电游平台: []
    }
  },
  created() {
    this.$axios.get('json/homeList.json').then(x => {
      this.电游平台 = x.data[1].children
    })
  }
}
</script>

<style lang="scss" scoped>
.dypt {
  width: 100%;
  overflow: hidden;
  background: #fcfcfc;
  margin-top: 0.2rem;
  padding-bottom: 0.14rem;
  box-shadow: 0 1px 0.25rem rgba(0, 0, 0, 0.06);
  margin-bottom: 0.2rem;
  &-banner {
    width: 100%;
  }
}
.box {
  padding: 0.6rem 0.1rem 0 0.1rem;
}
.swiper-container {
  height: 100%;
}

.swiper-item {
  .dypt-img {
    width: 100%;
    border-radius: 0.1333rem;
    box-shadow: 2px 2px 8px rgba(80, 0, 0, 0.25);
    img {
      width: 100%;
      height: 100%;
      border-radius: 0.1333rem;
      vertical-align: middle;
    }
  }
}
.text-box h2 {
  margin-top: 0.08rem;
  font-size: 0.26rem;
  font-weight: 400;
  color: #111;
}
.text-box p {
  margin-top: 0.08rem;
  font-size: 0.22rem;
  color: #ccc;
  line-height: 0.2667rem;
}
.dypt-text {
  overflow: hidden;
  margin-top: 2px;
}
.dypt-text-img {
  float: left;
  width: 0.64rem;
  height: 0.64rem;
  border-radius: 42%;
  margin-top: 2px;
  margin-right: 0.14rem;
  opacity: 0.8;

  img {
    width: 100%;
    height: 100%;
    border-radius: 42%;
  }
}
</style>
<style>
.swiper-pagination {
  position: inherit;
}
.dypt-banner .swiper-pagination-bullet {
  width: 0.1333rem;
  height: 0.1333rem;
  margin: 0 0.07rem !important;
  bottom: 0;
}
.dypt-banner .swiper-pagination-bullet-active {
  background: #f01924;
}
.swiper-pagination-bullets {
  bottom: 0 !important;
}
</style>
