<template>
  <!-- 热门游戏 -->
  <div class="rmyx">
    <div class="rmyx-title">
      <span>热门游戏</span>
    </div>
    <div class="rmyx-list">
      <div class="rmyx-list-item"
           v-for="(item,index) in listData"
           :key="item.id"
           @click="跳转游戏(item)">
        <div class="item-img">
          <img v-lazy="'images/电游平台/'+ item.type + '/' + item.id + item.ext"
               alt="">
        </div>
        <h2>{{item.title}}</h2>
        <p>{{item.typeTitle}}</p>
      </div>
    </div>
  </div>
  </div>
</template>

<script>
import { mapActions, mapState } from 'vuex';

export default {
  data () {
    return {
      listData: [],
      type: '',
    }
  },
  computed: {
    ...mapState({
      config: 'config',
      userinfo: x => x.user.userinfo
    })
  },
  mounted () {
    this.list()
  },
  methods: {
    list () {
      this.$axios.get('json/homeList.json').then(x => {
        this.listData = x.data[0].children
      })
    },
    ...mapActions({
      设置类型: '进入游戏/设置类型'
    }),
    跳转游戏 (item) {
      if (this.userinfo.UserId) {
        this.设置类型(item)
      } else {
        this.$store.commit('setIsLoginShow', true)
      }
    },
  }
}
</script>

<style lang="scss">
.rmyx {
  overflow: hidden;
  background: #fcfcfc;
  padding-bottom: 0.24rem;
  &-title {
    width: 100%;
    height: 100%;
    border-bottom: 1px solid #f4f4f4;
    box-shadow: 0 0 5px rgba(0, 0, 0, 0.04);
  }

  .rmyx-title > span {
    display: inline-block;
    font-size: 0.28rem;
    height: 0.36rem;
    line-height: 0.42rem;
    margin: 0.3rem 0;
    color: #333;
    padding-left: 0.16rem;
    border-left: 5px solid #d00;
  }
}

.rmyx-list {
  display: flex;
  align-items: center;
  text-align: center;
  justify-content: space-around;
  flex-wrap: wrap;
  .item-img {
    width: 1.28rem;
    height: 1.28rem;
    border: 1px solid #e6e6e6;
    margin: 0.2rem;
    border-radius: 16px;
    img {
      width: 100%;
      height: 100%;
      border-radius: 16px;
    }
  }
  h2 {
    color: #111;
    font-weight: 400;
    font-size: 0.24rem;
    line-height: 0.32rem;
    margin-top: 0.14rem;
    margin-bottom: 2px;
  }
  p {
    font-size: 0.22rem;
    color: #ccc;
  }
}
</style>
