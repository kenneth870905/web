<template>
  <div class="banner">
    <van-swipe :autoplay="3000"
               indicator-color="white">
      <van-swipe-item v-for="(item,index) in 优惠活动"
                      :key="index"
                      @click="$router.push('/discount')">
        <img v-lazy="item.Img"
             alt="">
      </van-swipe-item>
    </van-swipe>
    <!-- 通知栏 -->
    <div class="notice"
         @click="$router.push('/notice')">
      <van-notice-bar left-icon="volume-o">
        {{roll_titles}}
      </van-notice-bar>
    </div>
  </div>
</template>

<script>
import { api_获取优惠列表 } from '@/api/优惠接口.js';
export default {
  data () {
    return {
      roll_titles: config.roll_titles,
      优惠活动: []
    }
  },
  created () {},
  mounted () {
    api_获取优惠列表().then(x => {
      this.优惠活动 = x.data
    })
  }
}
</script>

<style lang="scss" scoped>
.banner {
  width: 100%;
  position: relative;
  img {
    width: 100%;
    height: 180px;
  }
  .van-swipe {
    height: 100%;
  }

  .notice {
    position: absolute;
    bottom: 1px;
    left: 0;
    right: 0;
    width: 100%;
    height: 0.5rem;
    line-height: 0.5rem;

    .van-notice-bar {
      height: 100%;
      background-image: linear-gradient(
        180deg,
        rgba(0, 0, 0, 0.15) 0,
        rgba(0, 0, 0, 0.3)
      );
      color: #fff;
      font-size: 14px;
    }
  }
}
</style>
<style >
.van-swipe__indicator {
  margin: 0.05rem;
  width: 6px;
  height: 6px;
}
.van-swipe__indicators {
  bottom: 0.54rem;
}
.van-notice-bar__content {
  height: 25px;
  font-size: 12px;
}

.van-notice-bar__left-icon,
.van-notice-bar__right-icon {
  font-size: 0.2667rem;
}
.van-notice-bar {
  background: transparent;
}
</style>
