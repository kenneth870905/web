import {
  api_Online
} from '@/api/登录接口.js'
import { Dialog } from 'vant'
import { api_隐藏公告 } from '@/api/公告接口.js'
import { api_获取等级 } from '@/api/个人资料.js'

export default {
  namespaced: true,
  state: {
    userinfo: {},
    偏好设置: {
      高级投注模式: false,
      聊天室弹框: true,
      购彩助手: true,
      主题色: {}
    },
    彩票玩法: 2,
    等级: {},
    api路线: '',
    路线list: []
  },
  getters: {

    试玩 (state) {
      if (state.userinfo.UserId) {
        var userid = state.userinfo.UserId.toLowerCase()
        return userid.indexOf('demo') != '-1'
      } else {
        return false
      }
    }
  },
  mutations: {
    设置state (state, [key, value]) {
      state[key] = value
    },
    设置userinfo (state, value) {
      state.userinfo = value
    }
  },
  actions: {
    获取个人等级 ({ state }) {
      api_获取等级().then(x => {
        console.log(x)
        state.等级 = x.data
      }).catch(err => { })
    },
    getUserInfo ({ state, dispatch, commit }) {
      return new Promise((resolve, reject) => {
        api_Online({ init: true }).then(x => {
          console.log(x)
          commit('设置userinfo', x.data)
          // state.userinfo = x.data
          if (x.data.Messages && x.data.Messages.length > 0) {
            mui.alert(x.data.Messages[0].Content, '消息提醒', '我知道了', () => {
              var obj = {
                Id: x.data.Messages[0].Id,
                Type: 2
              }
              api_隐藏公告(obj).then(r => {
                dispatch('getUserInfo')
              }).catch(err1 => {
                dispatch('getUserInfo')
              })
            })
          }
          resolve()
        }).catch(err => {
          reject()
        })
      })
    }
  },
  modules: {}
}
