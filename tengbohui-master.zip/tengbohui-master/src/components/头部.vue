<template>
  <header class="m-navbar navbar-bottom-line-color app-header app-header">
    <div class="navbar-item">
      <van-icon name="wap-nav"
                size="1.8em"
                style="line-height: 1.8em;"
                @click="popupShow" />

    </div>
    <div class="navbar-item">
      <span @click="service">客服</span>
    </div>

    <div class="navbar-center-box">
      <div class="navbar-center">
        <span class="center-title">
          {{ headTitle ? headTitle : config.title}}
        </span>
      </div>
    </div>

  </header>
</template>

<script>
import {
  mapState
} from 'vuex';
export default {
  props: ['headTitle'],
  computed: {
    ...mapState({
      config: 'config',
    })
  },
  methods: {
    service () {
      window.location.href = config.online_chat
    },
    popupShow () {
      this.$store.commit('setOverlay', true)
    },

  },
}
</script>

<style lang="scss" scoped>
.m-navbar {
  color: #fff;
  height: 0.88rem;
  line-height: 0.88rem;
  width: 100%;
  position: relative;
  background-image: linear-gradient(
    180deg,
    rgba(5, 5, 30, 0.92),
    rgba(5, 5, 30, 0.8)
  );
}

.navbar-item {
  height: 100%;
  font-size: 0.3rem;
  color: #ddd;
  position: absolute;
  top: 0;

  i {
    height: 100%;
  }
}

.navbar-item:first-child {
  position: absolute;
  left: 0;
  top: 0;
}

.navbar-item:nth-child(2) {
  right: 0;
}

.navbar-center-box {
  width: 50%;
  margin: 0 auto;
  text-align: center;
}

.app-header .navbar-item {
  background-image: linear-gradient(
    180deg,
    hsla(0, 0%, 100%, 0),
    hsla(0, 0%, 100%, 0.05)
  );
  padding: 0 0.24rem;
  text-shadow: 1px 1px 1px rgba(0, 0, 0, 0.2);
}

.center-title {
  color: rgb(255, 255, 253);
  font-size: 0.28rem;
}

i {
  font-size: 0.34rem;
}
</style>
