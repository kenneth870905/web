<template>
  <div class="home-footer">
    <div class="footer">
      <router-link tag="div"
                   v-for="(item,index) in list"
                   :key="index"
                   :to="item.href">
        <i :class="item.icon"></i>
        <span>{{item.title}}</span>
      </router-link>
    </div>
  </div>
</template>

<script>
export default {
  data () {
    return {
      list: [
        {
          title: '首页',
          icon: 'iconfont icon-home',
          href: '/home'
        },
        {
          title: '存款',
          icon: 'iconfont icon-cunkuan',
          href: '/deposit'
        },
        {
          title: '转账',
          icon: 'iconfont icon-Transfer_accounts',
          href: '/changCash'
        },
        {
          title: '优惠',
          icon: 'iconfont icon-zizhujiaoyi_new',
          href: '/discount'
        },
        {
          title: '会员中心',
          icon: 'iconfont icon-huiyuanzhongxin',
          href: '/mine'
        }
      ]
    }
  }
}
</script>

<style lang="scss" scoped>
.home-footer {
  width: 100%;
  height: 0.88rem;
  background-color: rgb(255, 255, 255);
  box-shadow: 0 0 0.3rem rgba(0, 0, 0, 0.1);
  font-size: 0.24rem;
  position: fixed;
  bottom: 0;
  left: 0;
}
.footer {
  display: flex;
  height: 100%;
  justify-content: space-around;
  text-align: center;
  align-items: center;
  &-item {
    // display: flex;
    // flex-direction: column;
  }
  i {
    display: block;
    font-size: 0.45rem;
    padding-bottom: 5px;
    color: rgb(151, 151, 151);
  }
  span {
    font-size: 0.22rem;
    color: rgb(151, 151, 151);
  }
}

.router-link-active {
  i,
  span {
    color: rgb(240, 24, 35);
  }
}
</style>
