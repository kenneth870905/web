<template>
  <div class="back-top"
       v-back="{ container, distance }"
       @click="toTop">
    <van-icon name="arrow-up" />
  </div>
</template>

<script>
import { constants } from 'crypto';
export default {
  props: {
    container: String,
    distance: Number
  },
  directives: {
    back: {
      inserted (el, binding) {
        document
          .querySelector(binding.value.container)
          .addEventListener('scroll', e => {
            if (e.target.scrollTop > binding.value.distance) {
              el.style.display = 'block';
            } else {
              el.style.display = 'none';
            }
          })
      }
    }
  },
  methods: {
    toTop () {
      let timer = null
      let _that = document.querySelector(this.container)
      cancelAnimationFrame(timer)
      timer = requestAnimationFrame(function fn () {
        if (_that.scrollTop > 0) {
          _that.scrollTop -= 300
          timer = requestAnimationFrame(fn)
        } else {
          cancelAnimationFrame(timer)
          _that.goTopShow = false
        }
      })
    }
  }
}
</script>

<style lang="scss">
.back-top {
  display: none;
  position: fixed;
  right: 0.1rem;
  bottom: 1.22rem;
  width: 0.88rem;
  height: 0.88rem;
  border-radius: 14%;
  line-height: 30px;
  background-size: 25px 25px;
  background-color: rgba(34, 34, 34, 0.9);
  box-shadow: 0 0 0.12rem rgba(0, 0, 0, 0.25);
  text-align: center;
  line-height: 0.88rem;
  i {
    color: #fff;
    font-size: 0.36rem;
  }
}
</style>
