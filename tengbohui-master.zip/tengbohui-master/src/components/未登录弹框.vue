<template>
  <div class="login-alert "
       ref="closeAc"
       v-if="isLoginShow">
    <div class="遮罩"></div>
    <div class="box bounceIn">
      <div class="m-confirm-icon">
        <van-icon name="fail"
                  style="font-size: 1.6rem;" />
      </div>
      <div class="confirm-hd">
        <strong class="confirm-title">未登录或登录超时</strong>
      </div>
      <div class="confirm-bd">请您登录，再进行操作！</div>
      <div class="btn">

        <button @click="前往登录()">前往登录</button>
        <button class="back-home"
                @click="返回首页()">返回首页</button>
      </div>
    </div>
  </div>
</template>

<script>
import { Dialog } from 'vant';
import {
  mapState
} from 'vuex'
export default {
  computed: {
    ...mapState({
      isLoginShow: 'isLoginShow'
    })
  },
  methods: {
    前往登录 () {
      this.$router.push('/login')
      this.$store.commit('setIsLoginShow', false)
    },
    返回首页 () {
      this.$router.push('/')
      this.$store.commit('setIsLoginShow', false)
    }
  },
}
</script>

<style lang="scss" scoped>
.login-alert {
  .遮罩 {
    position: absolute;
    top: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.4);
    z-index: 99;
  }
  .box {
    width: 72%;
    height: _vw(250);
    background: #fff;
    position: absolute;
    top: 0;
    right: 0;
    left: 0;
    bottom: 0;
    margin: auto;
    z-index: 100;
    border-radius: 12px;
    .btn {
      overflow: hidden;
      margin: 0 auto;
      text-align: center;
    }
    button {
      background-color: #f01924;
      height: _vw(37);
      border-radius: 6px;
      width: 90%;
      box-shadow: 0 2px 6px rgba(0, 0, 0, 0.06);
      margin-bottom: 2.4%;
      color: #fff;
      font-size: 0.24rem;
      border: none;
    }
    .back-home {
      background: #eee;
      color: #444;
    }
  }
}

.m-confirm-icon {
  text-align: center;
  padding-top: 0.12rem;
  margin-bottom: -0.14rem;

  i {
    margin-top: 0.12rem;
    font-size: 1.6rem;
    background-image: -webkit-gradient(
      linear,
      0 0,
      right bottom,
      from(#ffd232),
      to(rgba(255, 210, 20, 0.5))
    );
    color: #fff;
    border-radius: 50%;
    margin-bottom: 10px;
  }
}

.confirm-hd {
  text-align: center;
  padding: 15px 20px 5px;

  .confirm-title {
    font-size: 0.3rem;
    color: #444;
    font-weight: 400;
  }
}

.confirm-bd {
  text-align: center;
  font-size: 0.24rem;
  line-height: 0.3rem;
  color: #bbb;
  padding: 6px 0.2rem 8px 0.2rem;
  margin-top: -5px;
}

@keyframes bounceIn {
  from,
  20%,
  40%,
  60%,
  80%,
  to {
    -webkit-animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
    animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
  }

  0% {
    opacity: 0;
    -webkit-transform: scale3d(0.3, 0.3, 0.3);
    transform: scale3d(0.3, 0.3, 0.3);
  }

  20% {
    -webkit-transform: scale3d(1.1, 1.1, 1.1);
    transform: scale3d(1.1, 1.1, 1.1);
  }

  40% {
    -webkit-transform: scale3d(0.9, 0.9, 0.9);
    transform: scale3d(0.9, 0.9, 0.9);
  }

  60% {
    opacity: 1;
    -webkit-transform: scale3d(1.03, 1.03, 1.03);
    transform: scale3d(1.03, 1.03, 1.03);
  }

  80% {
    -webkit-transform: scale3d(0.97, 0.97, 0.97);
    transform: scale3d(0.97, 0.97, 0.97);
  }

  to {
    opacity: 1;
    -webkit-transform: scale3d(1, 1, 1);
    transform: scale3d(1, 1, 1);
  }
}

.bounceIn {
  -webkit-animation-duration: 0.5s;
  animation-duration: 0.5s;
  -webkit-animation-name: bounceIn;
  animation-name: bounceIn;
}
</style>