<template>
  <div class="系统公告"
       v-if="iframe.show">
    <div class="内容">
      <div class="iframe">
        <iframe :src="iframe.url"
                frameborder="0"></iframe>
      </div>
      <div class="btn_1"
           @click="关闭()">我知道了</div>
    </div>
  </div>
</template>

<script>
import { mapState, mapActions, mapMutations } from "vuex";
import { api_隐藏公告 } from "@/api/公告接口.js";

export default {
  name: "",
  data () {
    return {
      显示: false
    };
  },
  computed: {
    ...mapState({
      userinfo: state => state.user.userinfo
    }),
    iframe () {
      var obj = {
        url: "",
        show: false
      };
      if (
        (!this.userinfo.Messages || this.userinfo.Messages.length == 0) &&
        this.userinfo.Notices &&
        this.userinfo.Notices.length > 0
      ) {
        obj.show = true;
        obj.url =
          config.api_url +
          "/Systems/Notice/Show/" +
          this.userinfo.Notices[0].Id +
          "?p=" +
          this.userinfo.Notices[0].HowLong;
      }
      return obj;
      // return config.api_url
    }
  },
  methods: {
    ...mapActions({
      getUserInfo: "user/getUserInfo"
    }),
    ...mapMutations({
      加载中: '加载中'
    }),
    关闭 () {
      this.加载中(true)
      var obj = {
        Id: this.userinfo.Notices[0].Id,
        Type: 1
      };
      api_隐藏公告(obj)
        .then(x => {
          this.getUserInfo();
          this.加载中(false)
        })
        .catch(err => {
          this.getUserInfo();

          this.加载中(false)
        });
    }
  },
  mounted () {
    this.加载中(false);
  },
};
</script>

<style lang="scss" scoped>
.系统公告 {
  position: fixed;
  width: 100%;
  height: 100%;
  top: 0px;
  left: 0px;
  background: rgba(0, 0, 0, 0.3);
  z-index: 10;
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 20;
  .内容 {
    width: 90%;
    height: 70%;
    background: #ffffff;
    display: flex;
    flex-direction: column;
    padding: 0px 0px 0.67rem 0px;
    position: relative;
    border-radius: 4px;
    .btn_1 {
      width: 85%;
      left: 0px;
      bottom: 0px;
      line-height: 0.9rem;
      text-align: center;
      background-image: linear-gradient(
        180deg,
        rgba(5, 5, 30, 0.92),
        rgba(5, 5, 30, 0.8)
      );
      border-top: 1px solid #d4d4d4;
      border-radius: 12px;
      color: #fff;
      margin: 0 auto;
    }
    iframe {
      width: 100%;
      height: 93%;
    }
    .iframe {
      height: 100%;
      overflow: auto;
    }
  }
}
</style>
