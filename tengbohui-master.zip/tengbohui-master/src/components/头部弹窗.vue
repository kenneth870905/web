<template>
  <div>
    <div :class="['leftBar', overlay ? 'fadeInLeft' : 'fadeOutLeft' ]">
      <div class="popup">
        <div class="popup-header"
             v-if="!userinfo.UserId">
          <div class="header-top">
            <div class="left">
              <!-- <i class="icon">&#xe660;</i> -->
              <img src="images/user.png"
                   alt="">
            </div>
            <div class="right">
              <span>未登录</span>
              <p>登录后体验更多精彩...</p>
            </div>
          </div>
          <div class="header-bottom">
            <span @click="$router.push('/login')">登录</span>
            <span @click="$router.push('/register')">注册</span>
          </div>

        </div>

        <div class="popup-header"
             v-else>
          <div class="header-top">
            <div class="left">
              <!-- <i class="icon">&#xe660;</i> -->
              <img v-if="!Person.ImgId"
                   src="images/user.png"
                   alt="">
              <img v-if="Person.ImgId"
                   :src="'images/touxiang/'+Person.ImgId"
                   alt
                   srcset
                   style="    border-radius: 50%;"
                   class="wh" />
            </div>
            <div class="right">
              <span>{{userinfo.UserId }}</span>

              <p>账户余额: {{userinfo.Money}}</p>
            </div>
          </div>
          <div class="header-bottom"
               v-if="userinfo.UserId">
            <span @click="$router.push('/deposit')">存款</span>
            <span @click="$router.push('/withdraw')">提款</span>
          </div>

        </div>

        <div class="popup-main">
          <ul>
            <router-link v-for="(item,index) in popupList"
                         :key="index"
                         :to="item.path"
                         tag="li"
                         class="list">
              <span class="list-icon fl">
                <i class="iconfont"
                   v-html="item.icon"></i>
              </span>
              <span class="list-title fl">{{item.title}}</span>
              <i class="iconfont fr">&#xe63b;</i>
            </router-link>

            <!-- 客户端下载  -->
            <li class="list"
                @click="goDownload">
              <span class="list-icon fl">
                <i class="iconfont">&#xe609;</i>
              </span>
              <span class="list-title fl">客户端下载</span>
              <i class="iconfont fr">&#xe63b;</i>
            </li>
          </ul>
        </div>

      </div>
    </div>
    <!-- 遮罩 -->
    <van-overlay :show="overlay"
                 @click="closeOverlay" />
  </div>
</template>

<script>
import { mapState } from 'vuex';

export default {
  computed: {
    ...mapState({
      overlay: 'overlay',
      userinfo: x => x.user.userinfo,
      Person: x => x.个人资料.Person
    })
  },
  data () {
    return {
      show: false,
      popupList: [
        {
          title: '首页',
          icon: '&#xe76e;',
          path: '/home'
        },
        {
          title: '彩票游戏',
          icon: '&#xe611;',
          path: '/caipiao'
        },
        {
          title: '真人娱乐',
          icon: '&#xe617',
          path: '/liveCasino'
        },
        {
          title: '电子游艺',
          icon: '&#xe619;',
          path: '/eGames'
        },
        {
          title: '捕鱼游戏',
          icon: '&#xe61a;',
          path: '/fishGame'
        },
        {
          title: '棋牌游戏',
          icon: '&#xe614;',
          path: '/chessGame'
        },
        {
          title: '体育赛事',
          icon: '&#xe627;',
          path: '/sports'
        },
        {
          title: '优惠活动',
          icon: '&#xe613;',
          path: '/discount'
        }
      ]
    }
  },
  methods: {
    closeOverlay () {
      this.$store.commit('setOverlay', false)
    },
    goDownload () {
      window.location.href = config.app_download
    }
  },
  watch: {
    '$route' (to, from) {
      if (to) {
        this.$store.commit('setOverlay', false)
      }
    }
  }
}
</script>

<style lang="scss" scoped>
i {
  font-size: 0.34rem;
}
.leftBar {
  width: 58%;
  height: 100%;
  background: skyblue;
  position: absolute;
  top: 0;
  left: -58%;
  z-index: 99;
}
.fadeInLeft {
  left: 0;
}

@-webkit-keyframes fadeInLeft {
  from {
    opacity: 0;
    -webkit-transform: translate3d(-100%, 0, 0);
    transform: translate3d(-100%, 0, 0);
  }

  to {
    opacity: 1;
    -webkit-transform: translate3d(0, 0, 0);
    transform: translate3d(0, 0, 0);
  }
}

@keyframes fadeInLeft {
  from {
    opacity: 0;
    -webkit-transform: translate3d(-100%, 0, 0);
    transform: translate3d(-100%, 0, 0);
  }

  to {
    opacity: 1;
    -webkit-transform: translate3d(0, 0, 0);
    transform: translate3d(0, 0, 0);
  }
}

.fadeInLeft {
  -webkit-animation-name: fadeInLeft;
  animation-name: fadeInLeft;
  animation-duration: 0.5s;
}

.fadeOutLeft {
  transition: all 0.5s;
}

.popup {
  height: 100%;
  width: 100%;
  text-shadow: none;
  color: #fff;
  background: rgba(30, 30, 52, 0.98);
  &-header {
    padding-bottom: 0.3rem;
    background: #24243a;
    .header-top {
      padding: 0.24rem 0 0.2rem 0;
      .left {
        width: 0.88rem;
        height: 0.88rem;
        background: #33314f;
        border-radius: 50%;
        margin-right: 0.16rem;
        margin-left: 0.2rem;
        float: left;
        text-align: center;
        img {
          width: 100%;
          height: 100%;
        }
      }
      .right {
        font-size: 0.26rem;
        line-height: 0.45rem;
        color: #cce;
        p {
          color: #999;
        }
      }
    }
    .header-bottom {
      display: flex;
      justify-content: space-around;
      span {
        width: 1.76rem;
        height: 0.54rem;
        line-height: 0.54rem;
        text-align: center;
        font-size: 0.22rem;
        border-radius: 0.6rem;
        color: #fff;
        opacity: 0.9;
        display: block;
        background-image: linear-gradient(to right bottom, #ff2549, #ff8080);
      }
      span:nth-child(2) {
        background-image: linear-gradient(to right bottom, #47c0f5, #3eeac4);
      }
    }
  }
  &-main {
    // flex: 1;
    background: rgba(30, 30, 52, 0.98);
    ul {
      .list {
        height: 1rem;
        line-height: 1rem;
        width: auto;
        overflow: hidden;
        clear: both;
        margin-left: 0.2rem;
        font-size: 0.24rem;
        font-weight: 400;
        box-sizing: border-box;
        padding-right: 0.2rem;
        border-bottom: 1px solid rgba(0, 0, 0, 0.12);
        &-icon {
          width: 0.5rem;

          margin-right: 0.1rem;
          text-align: center;
        }
        .fr {
          color: #7d7b98;
        }
        &-title {
          color: rgba(230, 230, 255, 0.85);
        }
      }
    }
  }
}
.list:nth-child(1) i {
  color: #a12228;
}
.list:nth-child(2) i {
  color: #008b8d;
}
.list:nth-child(3) i {
  color: #5c29ee;
}
.list:nth-child(4) i {
  color: #04d;
}
.list:nth-child(5) i {
  color: #ca6111;
}
.list:nth-child(6) .list-icon i {
  color: #216b60;
  font-size: 0.43rem;
}
.list:nth-child(7) i {
  color: #f0382c;
}
.list:nth-child(8) i {
  color: #ca6111;
}
.list:nth-child(9) i {
  color: #746d35;
}
</style>