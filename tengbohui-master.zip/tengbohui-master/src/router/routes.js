import Vue from 'vue'
import Router from 'vue-router'
Vue.use(Router)

export default [
  // 404页面
  // {
  //   path: '*',
  //   redirect: '/404'
  // },
  // {
  //   path: '/404',
  //   component: () => import('@/views/404')
  // },
  // 首页
  {
    path: '/',
    redirect: '/home'
  },
  {
    path: '/home',
    name: 'home',
    component: () => import('@/views/home')
  },
  // 存款
  {
    path: '/deposit',
    name: 'deposit',
    component: () => import('@/views/存款'),
    meta: {
      需要登录: true
    }

  },
  // 转账
  {
    path: '/changCash',
    name: 'changCash',
    component: () => import('@/views/转账'),
    meta: {
      需要登录: true
    }
  },
  // 计划
  {
    path: '/jh',
    name: 'jh',
    component: () => import('@/views/计划/计划.vue')
  },

  // 会员中心
  {
    path: '/mine',
    name: 'mine',
    component: () => import('@/views/会员中心'),
    meta: {
      需要登录: true
    }
  },
  // 会员中心分支
  {
    path: '/mine/safePassCheck',
    name: 'safePassCheck',
    component: () => import('@/views/会员中心/密码管理'),
    meta: {
      需要登录: true
    }
  },
  {
    path: '/aqwenti',
    name: 'aqwenti',
    component: () => import('@/views/会员中心/密码管理/修改安全问题.vue'),
    meta: {
      需要登录: true
    }
  },
  {
    path: '/dlmm',
    name: 'dlmm',
    component: () => import('@/views/会员中心/密码管理/修改登录密码.vue'),
    meta: {
      需要登录: true
    }
  },
  {
    path: '/aqmm',
    name: 'aqmm',
    component: () => import('@/views/会员中心/密码管理/修改安全密码.vue'),
    meta: {
      需要登录: true
    }
  },
  {
    path: '/mine/bankInfo',
    name: 'bankInfo',
    component: () => import('@/views/会员中心/银行卡管理'),
    meta: {
      需要登录: true
    }
  },
  {
    path: '/mine/bankInfo/addBank',
    name: 'addBank',
    component: () => import('@/views/会员中心/银行卡管理/添加银行卡.vue'),
    meta: {
      需要登录: true
    }
  },
  {
    path: '/yhksz',
    name: 'yhksz',
    component: () => import('@/views/会员中心/银行卡管理/银行卡设置.vue'),
    meta: {
      需要登录: true
    }
  },

  {
    path: '/order',
    name: 'order',
    component: () => import('@/views/会员中心/投注记录'),
    meta: {
      需要登录: true
    }
  },
  {
    path: '/kfzx',
    name: 'kfzx',
    component: () => import('@/views/会员中心/客服中心'),
    meta: {
      需要登录: true
    }
  },
  // 登录
  {
    path: '/login',
    name: 'login',
    component: () => import('@/views/登录'),
    meta: {
      需要登录: true
    }
  },
  // 注册
  {
    path: '/register',
    name: 'register',
    component: () => import('@/views/注册')
  },
  // 公告信息
  {
    path: '/notice',
    name: 'notice',
    component: () => import('@/views/信息公告')
  },
  // 优惠活动
  {
    path: '/discount',
    name: 'discount',
    component: () => import('@/views/优惠活动')
  },
  // 真人娱乐
  {
    path: '/liveCasino',
    name: 'liveCasino',
    component: () => import('@/views/真人娱乐')
  },
  // 电子游艺
  {
    path: '/eGames',
    name: 'eGames',
    component: () => import('@/views/电子游艺')
  },
  // AG电子
  {
    path: '/eGames/agdz',
    component: () => import('../views/电子游艺/游戏总和/游戏总和.vue'),
    meta: {
      title: 'AG电子'
    }
  },
  // AG街机
  {
    path: '/eGames/agjj',
    component: () => import('../views/电子游艺/游戏总和/游戏总和.vue'),
    meta: {
      title: 'AG街机'
    }
  },
  // MG电子
  {
    path: '/eGames/mgdz',
    component: () => import('../views/电子游艺/游戏总和/游戏总和.vue'),
    meta: {
      title: 'MG电子'
    }
  },
  // BBIN电子
  {
    path: '/eGames/bbin',
    component: () => import('../views/电子游艺/游戏总和/游戏总和.vue'),
    meta: {
      title: 'BBIN电子'
    }
  },
  // BG电子
  {
    path: '/eGames/bgdz',
    component: () => import('../views/电子游艺/游戏总和/游戏总和.vue'),
    meta: {
      title: 'BG电子'
    }
  },
  // 泛亚电竞
  {
    path: '/eGames/fydj',
    component: () => import('../views/电子游艺/游戏总和/游戏总和.vue'),
    meta: {
      title: '泛亚电竞'
    }
  },
  // FG电子
  {
    path: '/eGames/fgdz',
    component: () => import('../views/电子游艺/游戏总和/游戏总和.vue'),
    meta: {
      title: 'FG电子'
    }
  },
  // 哈巴电游
  {
    path: '/eGames/hbdy',
    component: () => import('../views/电子游艺/游戏总和/游戏总和.vue'),
    meta: {
      title: '哈巴电游'
    }
  },

  // 乐游电子
  {
    path: '/eGames/lydz',
    component: () => import('../views/电子游艺/游戏总和/游戏总和.vue'),
    meta: {
      title: '乐游电子'
    }
  },
  // CQ9电子
  {
    path: '/eGames/cq9dz',
    component: () => import('../views/电子游艺/游戏总和/游戏总和.vue'),
    meta: {
      title: 'CQ9电子'
    }
  },
  // SW电子
  {
    path: '/eGames/swdz',
    component: () => import('../views/电子游艺/游戏总和/游戏总和.vue'),
    meta: {
      title: 'SW电子'
    }
  },

  {
    path: '/fishGame',
    name: 'fishGame',
    component: () => import('@/views/捕鱼游戏')
  },
  {
    path: '/chessGame',
    name: 'chessGame',
    component: () => import('@/views/棋牌游戏')
  },
  {
    path: '/sports',
    name: 'sports',
    component: () => import('@/views/体育赛事')
  },
  {
    path: '/forget',
    name: 'forget',
    component: () => import('@/views/忘记密码')
  },

  {
    path: '/withdraw',
    name: 'withdraw',
    component: () => import('@/views/提款'),
    meta: {
      需要登录: true
    }
  },
  {
    path: '/chatBoxes',
    name: 'chatBoxes',
    component: () => import('@/views/聊天室')
  },

  // 存款
  {
    path: '/dzxk',
    name: 'dzxk',
    component: () => import('@/views/存款/电子选卡'), // 电子选卡
    meta: {
      需要登录: true
    }
  },
  {
    path: '/wyxk',
    name: 'wyxk',
    component: () => import('@/views/存款/网银选卡'), // 网银选卡
    meta: {
      需要登录: true
    }
  },
  {
    path: '/zxxk',
    name: 'zxxk',
    component: () => import('@/views/存款/在线充值'), // 在线充值
    meta: {
      需要登录: true
    }
  },
  {
    path: '/mine/records',
    name: 'records',
    component: () => import('@/views/会员中心/客户报表'),
    meta: {
      需要登录: true
    }
  },
  {
    path: '/mine/vip',
    name: 'vip',
    component: () => import('@/views/会员中心/VIP'),
    meta: {
      需要登录: true
    }
  },

  {
    path: '/mine/agent',
    name: 'agent',
    component: () => import('@/views/会员中心/代理中心'),
    meta: {
      需要登录: true
    }
  },
  {
    path: '/mine/agent/agencyExplain',
    name: 'agencyExplain',
    component: () => import('@/views/会员中心/代理中心/代理说明'),
    meta: {
      需要登录: true
    }
  },
  {
    path: '/mine/agent/generalizeAdmin',
    name: 'generalizeAdmin',
    component: () => import('@/views/会员中心/代理中心/代理管理'),
    meta: {
      需要登录: true
    }
  },

  {
    path: '/mine/agent/betDetail',
    name: 'betDetail',
    component: () => import('@/views/会员中心/代理中心/投注明细'),
    meta: {
      需要登录: true
    }
  },
  {
    path: '/mine/agent/detail',
    name: 'detail',
    component: () => import('@/views/会员中心/代理中心/交易明细'),
    meta: {
      需要登录: true
    }
  },
  {
    path: '/mine/basic',
    name: 'basic',
    component: () => import('@/views/会员中心/个人信息'),
    meta: {
      需要登录: true
    }
  },
  {
    path: '/mine/basic/qq',
    name: 'qq',
    component: () => import('@/views/会员中心/个人信息/设置qq.vue'),
    meta: {
      需要登录: true
    }
  },
  {
    path: '/mine/basic/picture',
    name: 'picture',
    component: () => import('@/views/会员中心/个人信息/设置头像.vue'),
    meta: {
      需要登录: true
    }
  },
  {
    path: '/mine/basic/name',
    name: 'name',
    component: () => import('@/views/会员中心/个人信息/设置昵称.vue'),
    meta: {
      需要登录: true
    }
  },
  {
    path: '/mine/personage',
    name: 'personage',
    component: () => import('@/views/会员中心/个人资料'),
    meta: {
      需要登录: true
    }
  },
  {
    path: '/vipbet',
    name: 'vipbet',
    component: () => import('@/views/特邀嘉宾/特邀嘉宾.vue'),
    meta: {
      需要登录: true
    }
  },
  {
    path: '/privateChat',
    component: () => import('@/views/聊天室/私聊.vue')
  },
  {
    path: '/chatlist',
    component: () => import('@/views/聊天室/消息列表.vue')
  },
  {
    path: '/ifr/:type',
    component: () => import('@/views/iframe.vue')
  },
  {
    path: '/caipiao',
    component: () => import('@/views/彩票/彩票.vue')
  },
  {
    path: '/cpiframe',
    component: () => import('@/views/彩票/cpiframe.vue')
  },
  {
    path: '/rule',
    component: () => import('@/views/彩票/游戏规则/游戏规则.vue')
  },
  {
    path: '/kjzs',
    component: () => import('@/views/彩票/开奖走势/开奖走势.vue')
  },
  {
    path: '/yeb/yeb',
    component: () => import('@/views/余额宝/余额宝.vue')
  },
  {
    path: '/yeb/zc',
    component: () => import('@/views/余额宝/余额宝转出.vue')
  }, {
    path: '/yeb/bdk',
    component: () => import('@/views/余额宝/绑定银行卡.vue')
  }, {
    path: '/yeb/zr',
    component: () => import('@/views/余额宝/余额宝转入.vue')
  }, {
    path: '/yeb/szmx',
    component: () => import('@/views/余额宝/余额宝明细.vue')
  },
  {
    path: '/suggest',
    component: () => import('@/views/会员中心/意见反馈')
  },
  {
    path: '/ckjl',
    component: () => import('@/views/会员中心/存款记录')
  },
  {
    path: "/tjQunHongBao",
    component: () => import('@/views/红包/群红包')
  },
  {
    path: "/hbxq",
    component: () => import('@/views/红包/领取详情')
  }
]
