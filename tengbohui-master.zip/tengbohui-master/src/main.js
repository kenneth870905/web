import Vue from 'vue'
import App from './App.vue'
import router from './router/index'
import store from './store'

// 引入axios
import axios from 'axios'
// 引入vant组件
import Vant from 'vant'
import 'vant/lib/index.css'
// 图片懒加载
import {
  Lazyload,
  Dialog
} from 'vant'

// 轮播图插件
import VueAwesomeSwiper from 'vue-awesome-swiper'
import 'swiper/dist/css/swiper.css'

// 复制粘贴
import VueClipboard from 'vue-clipboard2'

// lodash
import lodash from 'lodash'
// 返回顶部组件注册
import BackTop from '@/components/返回顶部'
//

Vue.component('BackTop', BackTop)

var Options = {
  loading: 'images/imgloading.gif',
  error: 'images/imgloading2.jpg'
}
Vue.prototype.$axios = axios
Vue.use(VueClipboard)
Vue.use(Lazyload, Options, Dialog)
Vue.use(Vant)
Vue.use(VueAwesomeSwiper)
Vue.config.productionTip = false
new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')

// 前置守卫
router.beforeEach((to, from, next) => {
  var userinfo = store.state.user.userinfo.UserId

  if (to.path === '/login') {
    next()
  } else {
    if (to.meta.需要登录) {
      if (!userinfo) {
        store.commit('setIsLoginShow', true)
        // router.push('/login')
      } else {
        next()
      }
    } else {
      next()
    }
  }
})

// 路由守卫
// router.beforeEach((to, from, next) => {
//   var userInfo = store.state.userInfo.UserId
//   if (to.meta.需要登录) {
//     if (!userInfo) {
//       router.push('/login')
//     } else {
//       next()
//     }
//   } else {
//     next()
//   }
// })
