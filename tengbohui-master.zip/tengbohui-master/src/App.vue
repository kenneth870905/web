<template>
  <div id="app">
    <router-view />
    <jryxtk />

    <xtxx />

    <!-- 头部左边弹窗 -->
    <tbtc />
    <!-- loading请求加载 -->
    <div class="A加载中"
         v-show="加载中">
      <div>
        <van-loading color="white"
                     size="50px" />
      </div>
    </div>
    <!-- 未登录弹窗 -->
    <wdltc />
  </div>
</template>

<script>
import jryxtk from '@/components/进入游戏弹框.vue'
import tbtc from '@/components/头部弹窗.vue'

import {
  mapState,
  mapMutations,
  mapActions,
  mapGetters
} from 'vuex'

const xtxx = () => import('@/components/系统消息弹框.vue')
const wdltc = () => import('@/components/未登录弹框.vue')
export default {
  data () {
    return {}
  },
  components: {
    jryxtk,
    xtxx,
    tbtc,
    wdltc
  },
  created () {
    document.body.removeChild(document.getElementById('isLoading'))
  },
  computed: {
    ...mapState({
      加载中: '加载中',
    })
  },
  methods: {
    ...mapActions({
      获取json配置: '获取json配置',
      读取配置: '读取配置'
    })
  },
  mounted () {
    this.读取配置()
  }
}
</script>

<style lang="scss">
body,
html,
#app {
  width: 100%;
  height: 100%;
}
body {
  font-family: arial, sans-serif;
  -webkit-font-smoothing: antialiased;
}
.layout-box {
  display: flex;
  height: 100%;
  flex-direction: column;
  background: #f5f5f5;

  .layout-footer {
    height: 0.88rem;
  }
}

.van-nav-bar {
  background-image: linear-gradient(
    180deg,
    rgba(5, 5, 30, 0.92),
    rgba(5, 5, 30, 0.8)
  ) !important;

  .van-nav-bar__title {
    font-size: 0.28rem;
    color: #eee;
  }

  .van-nav-bar__left {
    padding: 0 0.24rem 0 0;
    left: 0;
    background-image: linear-gradient(
      180deg,
      hsla(0, 0%, 100%, 0),
      hsla(0, 0%, 100%, 0.05)
    );
  }

  .van-nav-bar__text {
    padding-left: 20px;
    color: #ccc;
  }

  .van-icon {
    padding-left: 4px;
    color: #ccc !important;
  }

  .van-nav-bar__arrow + .van-nav-bar__text {
    padding-left: 20px;
  }
}

.A加载中 {
  position: absolute;
  width: 100%;
  height: 100%;
  top: 0px;
  left: 0px;
  z-index: 20;
  display: flex;
  justify-content: center;
  align-items: center;
  background: rgba(0, 0, 0, 0.3);

  > div {
    background: rgba(0, 0, 0, 0.3);
    padding: 10px;
  }
}
</style>
