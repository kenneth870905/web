import Vue from 'vue'
import Vuex from 'vuex'
import createPersistedState from 'vuex-persistedstate'
import axios from 'axios'

import user from '@/vuex/user.js'
import 进入游戏 from '@/vuex/进入游戏.js'
import 个人资料 from '@/vuex/个人资料.js'
import 资金明细 from '@/vuex/资金明细.js'
import { api_获取游戏彩票 } from '@/api/游戏彩票接口.js'
import { api_Online } from '@/api/登录接口.js'
import 聊天室 from '@/vuex/聊天室.js'
import 私聊 from '@/vuex/私聊.js'
import 跟单 from '@/vuex/跟单.js'
import 投注订单 from '@/vuex/投注订单.js'
import 计划 from '@/vuex/计划.js'
import 投注 from '@/vuex/投注.js'
import 悬浮按钮 from '@/vuex/悬浮按钮.js'
import 开奖走势 from '@/vuex/开奖走势.js'

Vue.use(Vuex)
export default new Vuex.Store({
  plugins: [
    createPersistedState({
      reducer (val) {
        return {
          user: val.user,
          ip: val.ip,
          聊天室: {
            当前房间: val.聊天室.当前房间,
            预设房间: val.聊天室.预设房间,
            房间密码: val.聊天室.房间密码,
            偏好彩票: val.聊天室.偏好彩票,
            偏好彩票2: val.聊天室.偏好彩票2
          }
        }
      }
      // 使用 sessionStorage
      // storage: window.sessionStorage
      // 使用 cookie
      // storage: {
      //     getItem: key => Cookies.get(key),
      //     setItem: (key, value) => Cookies.set(key, value, { expires: 7 }),
      //     removeItem: key => Cookies.remove(key)
      // }
    })
  ],
  state: {
    // 弹窗
    overlay: false,
    isLoginShow: false,
    加载中: false,
    ip: '',
    游戏彩票类型: [],
    pageDirection: 'fade', // 控制页面切换
    // config:JSON.parse(JSON.stringify(config)),
    config: config,
    // 彩票颜色生肖等 主要用于 六合彩
    marSixNums: $.base.markSixNums,
    // 加密方式
    publicKey: 'MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDOfM4Ikzr/973NIm6ZgkhzPdJjMgTzwwh2h8aZcubSF5IT0UBZPfNtF9IpZi59dUHwe/4W2mP6aShQqlzteII+BNGxDUIIYMH0WLHTO3W3u7No0PD3eJ8cfpd+xCYTpYEgL0Qh08b5WrOUFXnKzyd1Hjmur3LYR0106s67Ce7k2wIDAQAB'
  },
  mutations: {
    // 设置overlay
    setOverlay (state, val) {
      state.overlay = val
    },
    // 需要一直保存的数据放在这里
    设置用户信息 (state, 用户信息) {
      // console.log('mutations',用户信息)
      state.userInfo = 用户信息
    },
    修改用户信息 (state, obj) {
      state.userInfo = obj
    },
    setPageDirection (state, dir) {
      state.pageDirection = dir
    },
    加载中 (state, type) {
      if (!type) {
        setTimeout(() => {
          state.加载中 = type
        }, 3000)
      } else {
        state.加载中 = type
      }
    },
    设置state (state, [key, value]) {
      state[key] = value
    },
    修改state (state, [key, val]) {
      console.log(key, val)
      state[key] = val
    },
    设置config (state, [key, value]) {
      state.config[key] = value
    },
    setIsLoginShow (state, val) {
      state.isLoginShow = val
    }
  },
  getters: {
    // 带有类型
    全部彩票类型 (state) {
      var obj = state.游戏彩票类型.find(x => x.title == '彩票')
      return obj ? obj.children : []
    },
    分类彩票 (state) {
      var obj = state.游戏彩票类型.find(x => x.title == '彩票')
      if (obj) {
        var list = obj.children.filter(x => x.title != '所有彩种')
        return list
      } else {
        return []
      }
    },
    // {title:时时彩,'...':"..."}
    全部彩票 (state) {
      var obj = state.游戏彩票类型.find(x => x.title == '彩票')
      if (obj) {
        var obj1 = obj.children.find(x => x.title == '所有彩种')
        var list = obj1.children.filter(x => x.title != '代理加盟')
        return list
      } else {
        return []
      }
    }
  },
  actions: {
    Online ({ state, commit }) {
      api_Online({ init: 1, n: 1 }).then(x => {
        // state.userInfo=x.data;
        commit('修改用户信息', x.data)
      })
    },
    获取游戏彩票 ({ state, commit, dispatch }) {
      return new Promise((resolve, reject) => {
        api_获取游戏彩票().then(x => {
          var data = x.data
          data.forEach(item => {
            if (!item.noSub) {
              item.children.forEach(x => {
                x.children.forEach(y => {
                  y.type = x.type
                  y.彩票 = item.title == '彩票'
                })
              })
            }
          })
          state.游戏彩票类型 = x.data
          commit('设置state', ['游戏彩票类型', x.data])
          resolve()
        }).catch(err => {
          reject()
        })
      })
    },
    读取配置 ({ state, dispatch, rootState }) {
      var url = rootState.user.api路线.url
      var title_1 = state.config.title
      Promise.all([
        dispatch('修改config')
        // dispatch('获取json配置')
      ]).then(list => {
        console.log(list, config)
        // 这里的cofig是获取到的

        if (typeof LineSwitch !== 'undefined') {
          if (LineSwitch) {
            var obj = Object.assign({}, config)
            obj.api_url = url
            obj.img_url = url + '/M1/'
            obj.iframe_url = url
            obj.wchat_url = url
            for (const key in obj) {
              state.config[key] = obj[key]
            }
            config = state.config
            var config1 = state.config
            state.config = ''
            state.config = config1
          }
        }

        console.log(list[1])
        if (list[1]) {
          var jsondata = list[1]
          document.title = jsondata.Title
          state.config.title = jsondata.Title
        } else {
          document.title = title_1
        }
      }).catch(err => {
        console.log(err)
      })
    },
    修改config ({ state, commit, rootState }) {
      console.log('修改config')
      var url = rootState.user.api路线.url
      var config_url = rootState.user.api路线.config
      return new Promise((resolve, reject) => {
        if (typeof LineSwitch !== 'undefined') {
          if (!LineSwitch) {
            resolve()
            return
          } else {
            console.log('需要获取config')
          }
        } else {
          resolve()
          return
        }
        $.ajax({
          type: 'get',
          url: config_url,
          dataType: 'script',
          success: (data) => {
            resolve()
          },
          error: function (err) {
            resolve()
          }
        })
      })
    }
  },
  modules: {
    user,
    进入游戏,
    个人资料,
    资金明细,
    聊天室,
    投注订单,
    私聊,
    跟单,
    计划,
    投注,
    悬浮按钮,
    开奖走势
  }
})
