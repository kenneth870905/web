// import axios from 'axios'
// import { Toast } from 'vant'

// axios.interceptors.request.use(config => {
//   Toast.loading({
//     mask: true,
//     message: '加载中...'
//   })
//   return config
// }, error => {
//   setTimeout(() => {
//     Toast.clear()
//     Toast('加载超时')
//   }, 3000)
//   return Promise.reject(error)
// })

// axios.interceptors.response.use(config => {
//   Toast.clear()
//   return config
// })
