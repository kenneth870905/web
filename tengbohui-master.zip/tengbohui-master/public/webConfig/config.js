// eslint-disable-next-line no-unused-vars
var config = {
  title: '腾博会',
  // 接口前缀
  api_url: '/apis',
  img_url: '',
  // 首页滚动字幕
  roll_titles: '✿尊敬的会员您好，感谢您的到来！我们拥有真人百家乐骰宝龙虎、电子游戏、老虎机、水果机、捕鱼、彩票等等游戏品类，满足您的所有需求。活动多多彩种多多，请尽情享受吧。',
  // app 下载地址
  app_download: 'https://luofandiya.com/down.php?id=1001',
  // 在线客服跳转地址
  online_chat: 'https://e-143504.chatnow.meiqia.com/dist/standalone.html',
  // 绑定 支付银行卡 所有银行
  bank: ['农业银行', '中国银行', '招商银行', '建设银行', '交通银行', '渤海银行', '广大银行', '兴业银行', '民生银行', '中信银行', '广发银行', '华夏银行'],
  qq: '68383668',
  // 邮箱
  mail: 'yunlaiservice@gmail.com',
  // 个人中心隐藏页面
  my: {
    yuEbao: true, // 余额宝
    geRenBaoBiao: true, // 个人报表
    heMai: true, // 合买
    chatBoxes: true // 聊天室
  },
  wchat_url: 'https://0698aa.com',
  iframe_url: 'https://0698aa.com',
  // 天天礼包
  libao: [
    { name: '每日签到', path: '/ifr/qd', NoShiWan: true, img: 'images/3.png' },
    { name: '每日首存', path: '/ifr/ShouChong', NoShiWan: true, img: 'images/1.png' },
    { name: '代理中心', path: '/mine/agent', img: 'images/5.png' },
    { name: '余额宝', path: '/yeb/yeb', img: 'images/2.png' },
    // { name: "余额宝", path: '', img: 'images/2.png' }, //没地址的不跳转
    // { name: "特邀嘉宾", path: '/ifr/vipbet', img: '', icon: 'icon iconfont icon-hezuo', bg: 'linear-gradient(30deg, rgb(233, 30, 99), rgb(255, 185, 209))' }
    { name: '特邀嘉宾', path: '/vipbet', img: '', icon: 'icon iconfont icon-zizhujiaoyi_new', bg: 'linear-gradient(30deg, rgb(233, 30, 99), rgb(255, 185, 209))' },
    { name: '玩转棋牌', path: '/ifr/zdy?u=1', img: 'images/7.png' }
  ],
  // 最新中奖
  最新中奖: [
    {
      name: 'hb',
      children: [
        {
          id: 'SGTheKoiGate',
          imgid: 'SGTheKoiGate',
          title: '鲤鱼门',
          type: 'HB',
          ext: '.png',
          money: '50000',
          user: 'tb**h18****'
        },
        {
          id: 'SGHotHotFruit',
          imgid: 'SGHotHotFruit',
          title: '疯狂水果',
          type: 'HB',
          ext: '.png',
          money: '20000',
          user: 'as**1234****'
        },
        {
          id: 'SGSantasVillage',
          imgid: 'SGSantasVillage',
          title: '圣诞乐村',
          type: 'HB',
          ext: '.png',
          money: '38500',
          user: '12**457****'
        },
        {
          id: 'SGFourDivineBeasts',
          imgid: 'SGFourDivineBeasts',
          title: '四大神兽',
          type: 'HB',
          ext: '.png',
          money: '41100',
          user: 'aa**h18****'
        }
      ]
    },
    {
      name: '',
      children: [
        {
          id: '161',
          imgid: '161',
          title: '大力神',
          type: 'CQ',
          ext: '.png',
          money: '120000',
          user: 'ww**s01****'
        },
        {
          id: '163',
          imgid: '163',
          title: '哪吒再临',
          type: 'CQ',
          ext: '.png',
          money: '200000',
          user: 'zx**c18****'
        },
        {
          id: 'AR12',
          imgid: 'AR12',
          title: '8级台风',
          type: 'CQ',
          ext: '.png',
          money: '15000',
          user: 'we**134****'
        },
        {
          id: 'AR16',
          imgid: 'AR16',
          title: '守株待兔',
          type: 'CQ',
          ext: '.png',
          money: '300000',
          user: 'at**155****'
        }
      ]
    }
  ]
}
