<template>
    <div class="home">
        首页
    </div>
</template>

<script>
// @ is an alias to /src

export default {
    data() {
        return {
            
        }
    },
}
</script>
