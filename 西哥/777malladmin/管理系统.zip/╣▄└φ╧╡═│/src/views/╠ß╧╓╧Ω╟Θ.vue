<template>
    <div>
        提现详情
    </div>
</template>