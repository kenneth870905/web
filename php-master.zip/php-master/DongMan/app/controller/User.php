<?php

namespace app\controller;

use app\BaseController;
use thans\jwt\facade\JWTAuth;

// use app\middleware\TestJwt;
// use think\facade\Request;
use think\facade\Db;

use app\model\User as u;

class User
{
    // protected $middleware = ['app\middleware\TestJwt'];
    // protected $middleware = [
	// 	'app\middleware\Test' => ['only'  => ['test']],
	// 	// 'app\middleware\TestJwt' => ['only'=> ['test1']],
	// 	'app\middleware\TestJwt' => ['except'=> ['test1']]  //这个是除开 test1 都会执行
	// ];
    public function register()
    {
        // $data = Request::param();
        $data = Request()->param();

        $u = new u;
        $user = $u->add($data);
        $r = [
            'token' => JWTAuth::builder(['userid' => $user->id]),
            'user' => $user
        ];
        return $r;
    }
    //登录
    public function login()
    {
        $data = Request()->param();
        $w = [
            'username'=>$data['username'],
            'password'=>md5($data['password'])
        ];
        $r = Db::table('user')->where($w)->find();
        if(!$r){
            throw new \think\Exception('用户已存在', 0);
        }
        return $r;
    }

    public function test()
    {
        // print_r(request()->param());
        // echo request()->InApp;
    }

    public function test1()
    {

    }
    public function test2()
    {

    }
}
