<?php
namespace app\controller;
use app\BaseController;
// 跨域设置
// 在 app/middleware.php 文件中添加

use app\model\wenzhang as wz;

use think\facade\Request;

class Wenzhang extends BaseController
{
    
    public function queryAll()
    {
        // 参数 leiBieId 
        $data = Request::param();
        $name = isset($data['name']) ? $data['name'] : '';
        $leibieName = isset($data['leibieName']) ? $data['leibieName'] : '';
        $order = isset($data['order']) ? $data['order'] : 'renQi';
        $leiBieId = isset($data['leiBieId']) ? $data['leiBieId'] : 0;
        $wz = new wz();
        $list = $wz->getList( $leiBieId , $data['pageIndex'] ,$data['pageSize'] ,$name,$leibieName,$order);
        // echo $list;
        return $list;
    }
    
    public function queryByLeibie()
    {
        $name = Request::param();
        $r = new wz();
        return $r->queryByLeibie(0,10);
    }


    public function queryById()
    {
        $data = Request::param();
        $wz = new wz();
        $list = $wz->queryById($data['id']);
        return $list;
    }

}
