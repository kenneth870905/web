<?php
namespace app\controller;
use app\BaseController;

use think\facade\Request;

class GetImg extends BaseController
{
    public function index()
    {
        header("Content-type: image/png");
        // 参数 leiBieId 
        // header("Content-type: image/png");
        $data = Request::param();
        $imgFromUrl = $data['url'];
        // ob_start();//打开输出
        // readfile($imgFromUrl);//输出图片文件
        // $img = ob_get_contents();//得到浏览器输出
        // ob_end_clean();//清除输出并关闭
        // echo readfile($imgFromUrl);
        echo file_get_contents($imgFromUrl);
        //$size = strlen($img);//得到图片大小
        // $fp2 = @fopen($newFileName, "a");
        // fwrite($fp2, $img);//向当前目录写入图片文件，并重新命名
        // fclose($fp2);
        // return $newFileName;//返回新的文件名
        // return $list;
    }
}
