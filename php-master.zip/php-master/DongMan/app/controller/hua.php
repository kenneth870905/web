<?php
namespace app\controller;
use app\BaseController;
// 跨域设置
// 在 app/middleware.php 文件中添加

use app\model\hualist as hl;
use app\model\huaimage;

use think\facade\Request;

class hua extends BaseController
{
    
    public function huaList()
    {
        // 参数 leiBieId 
        $data = Request::param();
        $hl = new hl();
        $list = $hl->getList( $data['wenZhangId'] );
        // echo $list;
        return $list;
    }

    public function huaDetails()
    {
        $data = Request::Param();
        $huaimage = new huaimage();
        $list = $huaimage->getList($data['huaId']);
        return $list;
    }
    
}
