<?php
declare (strict_types = 1);

namespace app\middleware;

// use thans\jwt\facade\JWTAuth;
class TestJwt
{
    /**
     * 处理请求
     *
     * @param \think\Request $request
     * @param \Closure       $next
     * @return Response
     */
    public function handle($request, \Closure $next)
    {   
        // if ($request->param('name') == 'think') {
        //     return redirect('index/think');
        // }
        // return $next($request);
        echo '执行了jwt中间件';

        if (preg_match('~micromessenger~i', $request->header('user-agent'))) {
            $request->InApp = 'WeChat';
        } else if (preg_match('~alipay~i', $request->header('user-agent'))) {
            $request->InApp = 'Alipay';
        }else{
            $request->InApp = '其他';
        }
        return $next($request);
    }
}
