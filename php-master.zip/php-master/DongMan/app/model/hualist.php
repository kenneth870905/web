<?php
namespace app\model;

use think\Model;

use think\facade\Db;

class hualist extends Model
{
    public function getList($wenZhangId)
    {
        $r = hualist::where([
            'wenZhangId'=>$wenZhangId
        ])->order('name','ASE')->select();
            // ->order('id', 'asc');
            // ->paginate([
            //     'page'=>$pageIndex,
            //     'list_rows'=>$pageSize
            // ]);
        return $r;
    }
}