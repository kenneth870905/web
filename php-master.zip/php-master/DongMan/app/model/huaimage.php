<?php
namespace app\model;

use think\Model;

use think\facade\Db;

class huaimage extends Model
{
    public function getList($huaId)
    {
        $r = huaimage::where([
            'huaId'=>$huaId
        ])
        ->select();
            // ->order('id', 'asc');
            // ->paginate([
            //     'page'=>$pageIndex,
            //     'list_rows'=>$pageSize
            // ]);
        return $r;
    }
}