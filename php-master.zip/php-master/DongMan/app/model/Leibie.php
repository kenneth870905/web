<?php
namespace app\model;

use think\Model;

use think\facade\Db;

class Leibie extends Model
{
    public function getList()
    {
        $r = leibie::where('1=1')->select();
            // ->order('id', 'asc');
            // ->paginate([
            //     'page'=>$pageIndex,
            //     'list_rows'=>$pageSize
            // ]);
        return $r;
    }
}