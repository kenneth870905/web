<?php
namespace app\model;
use think\Model;
use think\facade\Db;
use think\db\exception\DataNotFoundException;
class User extends Model
{
    public function add($data)
    {
        $u = User::where('username',$data['username'])->find();
        if($u){
            // return json($e->getMessage());
            // abort(200, '用户已存在');
            throw new \think\Exception('用户已存在', 0);
        }
        $user =new User;
        $user->save([
            'username'  => $data['username'],
            'password' => md5($data['password']),
            'nickname' => isset($data['nickname']) ? $data['nickname'] : '' ,
            'sex'=> isset($data['sex']) ? $data['sex'] : 0
        ]);
        return $user;
        // $id = $user->id;
        // return $this->findById($user->id);
        // return $user->id;
    }

    public function findById($id)
    {
        return User::where('id',$id)->find();
    }
}