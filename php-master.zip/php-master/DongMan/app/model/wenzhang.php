<?php
namespace app\model;

use think\Model;

use think\facade\Db;

class wenzhang extends Model
{
    public function getList($leibieId,$pageIndex,$pageSize,$name='',$leibieName='',$order)
    {
        $w = '1=1 ';
        if($leibieId){
            $w .= "AND wenzhang.leiBieId = $leibieId";
        }
        $r = wenzhang::field('wenzhang.*,leibie.name as leibieName')
            ->leftJoin(['leibie'],'wenzhang.leiBieId = leibie.id')
            ->where($w)
            ->where('wenzhang.name','like',"%$name%")
            ->where('leibie.name','like',"%$leibieName%")
            ->order("wenzhang.$order",'DESC')
            // ->selct(false);
            ->paginate([
                'page'=>$pageIndex,
                'list_rows'=>$pageSize
            ]);
        return $r;

        // $r = wenzhang::where([
        //     'leiBieId'=>$leibieId,
        // ])->where('name','like',"%$name%")
        // ->paginate([
        //     'page'=>$pageIndex,
        //     'list_rows'=>$pageSize
        // ]);
        return $r;
    }

    public function queryById($id)
    {
        $r = wenzhang::where('id',$id)->find();
        return $r;
    }

    public function queryByLeibie($pageIndex,$pageSize)
    {
        
        $r = wenzhang::field('wenzhang.*,leibie.name as leibieName')
            ->leftJoin(['leibie'],'wenzhang.leiBieId = leibie.id')
            ->where("leibie.name='彩虹'")
            ->paginate([
                'page'=>$pageIndex,
                'list_rows'=>$pageSize
            ]);
        return $r;
    }

}


