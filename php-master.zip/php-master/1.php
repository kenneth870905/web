<?php
    error_reporting(-1);
    $conn = mysqli_connect("localhost", "root", "123456",'news');
    if (!$conn) {
        die("连接失败: " . mysqli_connect_error());
    }

    // $sql = "SELECT imageData FROM output_images WHERE imageId=" . $_GET['image_id'];
    $sql = "SELECT photoBlob FROM `user` WHERE id=1";
    // $result = $conn->query($sql);
    $result = mysqli_query($conn,$sql);
    $row = mysqli_fetch_array($result);
    header("Content-type: image/jpg" );
    $url1 =  $row["photoBlob"];
    echo $url1;
    mysqli_close($conn);
?>


