<?php
    header('Access-Control-Allow-Origin:*');
    header( "Access-Control-Allow-Methods: GET,POST,PUT,DELETE,OPTIONS");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    if (strtolower($_SERVER['REQUEST_METHOD']) == 'options') {
        exit;
    }
    class index  
    {
        public function queryT1()
        {
            $servername = "localhost";
            $username = "root";
            $password = "123456";
            $dbname = "shouji_bizi";     
            
            // 创建连接
            $conn = mysqli_connect($servername, $username, $password,$dbname);

            $conn->close();

            // SELECT * FROM `t1` WHERE 1

            // $request_body = file_get_contents('php://input');
            // $data = json_decode($request_body, true);
            // echo json_encode($data);
            // echo $data['page1'];
        }
    }


    // $obj = new index();
    // echo $obj->queryT1();

    $request_body = file_get_contents('php://input');
    $data = json_decode($request_body, true);
    echo json_encode($data);

?>