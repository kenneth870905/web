<?php
    if($_SERVER['REQUEST_METHOD']=='POST'){

        $expire=time();
        if(isset($_COOKIE["user"])){
            setcookie("user", "", time()-3600);
        }
        setcookie("user", $expire);
        exit;
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <botton>cookie测试</botton>
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script>
        $('botton').click(function(){
            $.ajax({
                type: "post",
                url: "",
                success: function (response) {
                    console.log(response)
                },
                error:function(err){
                    console.log(err)
                }
            });
        })
    </script>
</body>
</html>