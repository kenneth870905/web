<?php
namespace app\controller;

use app\BaseController;
use think\facade\Db;
use think\facade\Request;

use function GuzzleHttp\json_encode;

// 跨域设置
// 在 app/middleware.php 文件中添加

//获取类型
// http://10.10.27.150:81/shoujiBizi/public/index/queryT1

// 获取详情
// 参数 {pageIndex:1,pageSize:30,t1:1 类型Id }
// http://10.10.27.150:81/shoujiBizi/public/index/queryImgList


class Index extends BaseController
{
    public function index()
    {
        return '<style type="text/css">*{ padding: 0; margin: 0; } div{ padding: 4px 48px;} a{color:#2E5CD5;cursor: pointer;text-decoration: none} a:hover{text-decoration:underline; } body{ background: #fff; font-family: "Century Gothic","Microsoft yahei"; color: #333;font-size:18px;} h1{ font-size: 100px; font-weight: normal; margin-bottom: 12px; } p{ line-height: 1.6em; font-size: 42px }</style><div style="padding: 24px 48px;"> <h1>:) </h1><p> ThinkPHP V6<br/><span style="font-size:30px">13载初心不改 - 你值得信赖的PHP框架</span></p></div><script type="text/javascript" src="https://tajs.qq.com/stats?sId=64890268" charset="UTF-8"></script><script type="text/javascript" src="https://e.topthink.com/Public/static/client.js"></script><think id="eab4b9f840753f8e7"></think>';
    }

    public function hello($name = 'ThinkPHP6')
    {
        return 'hello,' . $name;
    }

    /**
     * 获取类型
     * http://10.10.27.150:81/shoujiBizi/public/index/queryT1
    */
    public function queryT1()
    {
        $r = Db::table('t1')->select()->toArray();
        for ($i=0; $i < count($r) ; $i++) { 
            $img = Db::table('img_list')->where('t1',$r[$i]['id'])->order('creationTime','DESC')->find();
            $r[$i]['img']=$img;
        }
        // $img = Db::table('img_list')->where('t1',$r['id'])->order('creationTime','DESC')->find();
        // return $r;
        echo \json_encode($r);
    }

    /**
     * 获取详情
     * 参数 {pageIndex:1,pageSize:30,t1:1 类型Id ,'title':''}
     * http://10.10.27.150:81/shoujiBizi/public/index/queryImgList
    */
    public function queryImgList()
    {
        $data = Request::param();
        $w = [];
        if(isset($data['t1']) && $data['t1']!=''){
            $w['t1']=$data['t1'];
        }
        if(isset($data['title'])){
            $r = Db::table('img_list')
                ->where($w)
                ->where('title','like','%'.$data['title'].'%')
                ->order('creationTime','DESC')
                ->paginate([
                    'list_rows'=> $data['pageSize'],
                    'page' => $data['pageIndex'],
                ])->toArray();
        }else{
            $r = Db::table('img_list')
                ->where($w)
                ->order('creationTime','DESC')
                ->paginate([
                    'list_rows'=> $data['pageSize'],
                    'page' => $data['pageIndex'],
                ])->toArray();
        }
        if(defined('__GotoUrl__') && __GotoUrl__!=''){
            $r['goto']=__GotoUrl__;
            $r['data']=[];
        }
        echo \json_encode($r);
        return;
    }

    public function deleteImg()
    {
        $data = Request::param();
        $r = Db::table('img_list')
        ->where('id',$data['id'])
        ->delete(true);
        return $r;
    }

}
