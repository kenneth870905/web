<?php

namespace app\validate;

use think\Validate;

class Vregister extends Validate
{
    /**
     * 定义验证规则
     * 格式：'字段名'	=>	['规则1','规则2'...]
     *
     * @var array
     */	
	protected $rule = [
        'userName'  => 'require|max:25',
        'password1'   => 'require|min:6|max:20',
        // 'email' => 'email', 
        'phone' => 'mobile' 
    ];
    
    /**
     * 定义错误信息
     * 格式：'字段名.规则名'	=>	'错误信息'
     *
     * @var array
     */	
    protected $message = [
        'userName' => ['message'=>'请输入用户名'],
        'password1' => ['message'=>'密码长度必须在6-20之间'],
        'phone'=>['message'=>'手机号码错误']   
    ];
}
