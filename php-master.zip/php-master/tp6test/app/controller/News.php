<?php
    namespace app\controller;
    use app\BaseController;
    use think\facade\Db;
    use thans\jwt\facade\JWTAuth;

    class News extends BaseController{
        public function findAll()
        {
            $data = json_decode(file_get_contents("php://input"),true);

            $where = '1=1';
            if(isset($data['sourceId'])){
                $where .= " AND a.source=".$data['sourceId'];
            }
            if(isset($data['t2id']) && $data['t2id']!=''){
                $where .= ' AND a.t2id='.$data['t2id'];
            }
            // return $where;
            $list = Db::table('news')
                        ->alias('a')
                        ->field('a.*,b.Name AS sourceName')
                        ->join(['source'=>'b'],'a.source=b.id')
                        ->order(['a.time'=>'desc'])
                        ->where($where)
                        ->paginate([
                            'page'=>$data['pageIndex'],
                            'list_rows'=>$data['pageSize']
                        ]);
            return $list;
        }

        public function getNewsById()
        {
            $data = json_decode(file_get_contents('php://input'),true);
            // 查询新闻
            $r = Db::table('news')->where('id',$data['id'])->find();
            // 查询来源
            if($r['source']){
                $r['sourceObj'] = Db::table('source')->where('id',$r['source'])->find();
            }else{
                $r['sourceObj'] = array();
            }
            return $r;
        }
    }