<?php
namespace app\controller;
use app\BaseController;

use QL\QueryList;
// 获取javascript 渲染的页面；
use QL\Ext\PhantomJs;

class Test extends BaseController{
    public function index(){
        return 'testindex';
    }

    public function hello($name = 'ThinkPHP6'){
        return 'hello,' . $name;
    }

    public function querylist(){
        
        ini_set('open_basedir', 'C:/phantomjs/bin/phantomjs');

        $ql = QueryList::getInstance();
        // 安装时需要设置PhantomJS二进制文件路径
        $ql->use(PhantomJs::class,'/usr/local/bin/phantomjs');
        //or Custom function name
        $ql->use(PhantomJs::class,'/usr/local/bin/phantomjs','browser');

        // Windows下示例
        // 注意：路径里面不能有空格中文之类的
        $ql->use(PhantomJs::class,'C:/phantomjs/bin/phantomjs.exe');
        
        $html = $ql->browser('https://m.toutiao.com')->getHtml();
        print_r($html);
        return;
        // //采集规则
        // $rules = [
        //     //采集a标签的href属性
        //     'link' => ['.catalog a','href'],
        //     'title' => ['.catalog a','text']
        // ];
        // $data = $ql->browser('https://www.kancloud.cn/manual/thinkphp6_0/1037479')->getHtml();
        // print_r($data);
        // return



        //采集规则
        $rules = [
            //采集a标签的href属性
            'link' => ['.catalog a','href'],
            'title' => ['.catalog a','text']
        ];
        $url = 'https://www.kancloud.cn/manual/thinkphp6_0/1037479';
        $data = Querylist::get($url)->rules($rules)->query()->getData();
        // print_r($data);
        // print_r($data->all());
        $list = $data->all();
        echo \json_encode($list);
    }
}
