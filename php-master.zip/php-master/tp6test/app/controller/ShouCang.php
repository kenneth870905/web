<?php
namespace app\controller;
use app\BaseController;
use think\facade\Db;

//验证
use app\validate\Vregister;
use think\exception\ValidateException;

use thans\jwt\facade\JWTAuth;

class ShouCang extends BaseController
{
    //设置 添加收藏和删除收藏
    public function index()
    {
        $data = json_decode(file_get_contents("php://input"),true);
        $userId = JWTAuth::auth()['userId']->getValue();

        $d = [
            'newsId'=>$data['newsId'],
            'userId'=>$userId
        ];
        $r1= Db::table('shouchang')->where($d)->find();
        if($r1){
            $r2 = Db::table('shouchang')->where($d)->delete();
        }else{
            $d['creationTime'] = array('exp','NOW()');
            $r2 = Db::table('shouchang')->insert($d);
        }
        return [
            'code'=>1,
            'message'=>'设置成功'
        ];
    }

    // 查询收藏
    public function query()
    {
        $userId = JWTAuth::auth()['userId']->getValue();
        $data = json_decode(file_get_contents("php://input"),true);

        $d = [
            'newsId'=>$data['newsId'],
            'userId'=>$userId
        ];
        $r1= Db::table('shouchang')->where($d)->find();
        return [
            'code'=>$r1 ? 1 : 2,
            'message'=>""
        ];
    }

    public function queryAll()
    {
        $userId = JWTAuth::auth()['userId']->getValue();
        $data = json_decode(file_get_contents("php://input"),true);

        // SELECT t2.title , t2.cover , t2.id FROM `shouchang` AS t1 LEFT JOIN news AS t2 ON t2.id = t1.newsId  WHERE 1
        // SELECT t2.title, t2.cover, t2.id, t2.source, t3.name FROM `shouchang` AS t1 LEFT JOIN news AS t2 ON t2.id = t1.newsId LEFT JOIN source AS t3 ON t3.id=t2.source WHERE 1
        $w = [
            'page'=>$data['pageIndex'],
            'list_rows'=>$data['pageSize']
        ];
        $r = DB::table('shouchang')
                // ->alias('t1')
                ->field('news.title , news.time , news.cover , news.id , news.source , source.name AS sourceName')
                ->join(['news'],'shouchang.newsId = news.id')
                ->join(['source'],'news.source = source.id')
                ->where(['userId'=>$userId])
                ->order('shouchang.creationTime', 'DESC')
                ->paginate([
                    'page'=>$data['pageIndex'],
                    'list_rows'=>$data['pageSize']
                ]);
        return $r;
    }
}
    


