<?php
namespace app\controller;
//数据库辅助
use think\facade\Db;
use app\BaseController;

use think\facade\Request;
//验证
use app\validate\Vregister;
use think\exception\ValidateException;

class Register extends BaseController{

    public function index(){
        $data = json_decode(file_get_contents("php://input"),true);

        $data1 = [
            'userName' => $data['userName'],
            'password' => md5($data['password']),
            "password1" => $data['password'],
            'phone' => isset($data['phone']) ? $data['phone'] : '',
        ];

        try {
            $result = validate(Vregister::class)->check($data1);
        } catch (ValidateException $e) {
            return $e->getError();
        }
        //查询是否已有账号
        $userName = $data['userName'];
        $phone =  $data['phone'];
        $sql = "userName='$userName'";
        if($phone){
            $sql .= "OR phone = '$phone'";
        }
        $r1 = Db::table('user')->where($sql)->count();
        if($r1){
            return [
                'code'=>0,
                "message"=>'账号或手机号码已存在'
            ];
        }
        
        $data2 = [
            'userName' => $data['userName'],
            'password' => md5($data['password']),
            'phone' => isset($data['phone']) ? $data['phone'] : '',
            'creationTime'=>array('exp','NOW()')
            // INSERT INTO `user`(`account`, `pwd`, `name`, `creationTime`) VALUES ('0002','123456','张三',NOW())
            // 'creationTime'=>'NOW()'
        ];
        $r2 = Db::table('user')->insert($data2);
        return [
            'code'=> $r2 ? 1 : 0,
            'message'=> $r2 ? "添加成功" : "添加失败"
        ];
    }
}
