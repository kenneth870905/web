<?php
    namespace app\controller;
    use app\BaseController;
    use think\facade\Db;
    use thans\jwt\facade\JWTAuth;

    class NewType extends BaseController{
        public function findAll()
        {
            $r = Db::table('news_t1')->select();
            return $r;
        }

        public function getT2()
        {
            $data = json_decode(file_get_contents('php://input'),true);
            // return $data['t1id'];
            $where = '1=1';
            if(isset($data['t1id'])){
                $where .= ' AND t1id ='.$data['t1id'];
            }
            $r = Db::table('news_t2')->where($where)->select();
            return $r;
        }
    }
?>


















