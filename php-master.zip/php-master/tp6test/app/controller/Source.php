<?php
    namespace app\controller;
    use app\BaseController;
    use think\facade\Db;
    use thans\jwt\facade\JWTAuth;

    class Source extends BaseController{
        public function getById()
        {
            $data = json_decode(file_get_contents('php://input'),true);
            $r = Db::table('Source')->where('id',$data['id'])->find();
            return $r ? $r : array();
        }
    }