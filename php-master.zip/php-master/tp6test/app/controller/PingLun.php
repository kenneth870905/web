<?php
namespace app\controller;
use app\BaseController;
use think\facade\Db;

//验证
use app\validate\Vregister;
use think\exception\ValidateException;

use thans\jwt\facade\JWTAuth;
// use app\BaseController\Model;
use app\model;
use app\model\news_review;

use think\facade\Request;

class PingLun extends BaseController{
    public function add()
    {
        $data = json_decode(file_get_contents('php://input'),true);
        $userId = JWTAuth::auth()['userId']->getValue();
        $t = [
            'newId'=>isset($data['newId']) ? $data['newId'] : null ,
            'creationTime'=>['exp','NOW()'],
            'parentId'=>$data['parentId'],
            'text'=>$data['text'],
            'revert'=>$data['revert'],
            'userId'=>$userId
        ];
        // $add = DB::table('news_review')->insert($t);
        $id = DB::table('news_review')->insertGetId($t);
        $r = $this->findById($id,$userId);
        if($data['revert']){
            $r['revertObj'] = $this->findById($data['revert'],$userId);
        }else{
            $r['revertObj']=null;
        }
        return [
            'code'=>$id ? 1 : 0,
            'message'=> $r,
        ];
    }
    
    protected function findById($id,$userId)
    {
        $r = DB::table(['news_review'=>'t1'])
            ->field("t1.* , 
                    ( SELECT COUNT(*) FROM dian_zhan WHERE dian_zhan.reviewId = t1.id ) AS dianzhanCount,
                    ( SELECT COUNT(*) FROM news_review WHERE news_review.parentId = t1.id ) AS huiFuCount,
                    ( SELECT COUNT(*) FROM dian_zhan WHERE dian_zhan.reviewId = t1.id AND dian_zhan.userId='$userId' ) AS isDianZan,
                    CONCAT(substring(user.userName,1,4),'***') AS userName ,
                    user.nickname,
                    user.photo
                ")
            ->leftJoin(['user'],'t1.userId = user.id')
            ->leftJoin(['dian_zhan'],'t1.id = dian_zhan.reviewId')
            ->where([
                't1.id'=>$id
            ])->find();
        return $r;
    }

    //通过Id查询
    public function queryById()
    {
        $userId = '';
        try {
            $userId = JWTAuth::auth()['userId']->getValue();
        } catch (\Throwable $th) {}

        $data = json_decode(\file_get_contents('php://input'),true);
        $r = $this->findById($data['id'],$userId);
        $r['huiFUList'] = $this->getList('','',$data['id'] , 1 , 5);
        $r = json_decode(json_encode($r),true);
        // $r['revertObj'] = $this->findById($r['revert']);
        if($r['revert']){
            $r['revertObj'] = $this->findById($r['revert'],$userId);
        }else{
            $r['revertObj']=null;
        }
        return $r ;        
    }
    
    public function getList($userId,$newId,$parentId,$pageIndex,$pageSize,$order='')
    {
        //员语句
        // SELECT t1.*, t2.userName, t2.nickname, ( SELECT COUNT(*) FROM dian_zhan WHERE dian_zhan.reviewId = t1.id ) AS dianzhanCount, ( SELECT COUNT(*) FROM news_review WHERE news_review.parentId = t1.id ) AS huiFuCount FROM `news_review` AS t1 LEFT JOIN user AS t2 ON t1.userId = t2.id LEFT JOIN dian_zhan AS t3 ON t1.id = t3.reviewId WHERE 1 ORDER BY huiFuCount ASC
        $order = $order ? $order : 'news_review.creationTime';
        // $w = [
        //     'news_review.parentId'=>$parentId
        // ];
        $w = "(t1.parentId = '$parentId' OR t1.revert = '$parentId')";
        if($newId){
            // $w['news_review.newId']=$newId;
            $w .= " AND t1.newId=$newId";
        }
        $r = DB::table(['news_review'=>'t1'])
                ->field("t1.* , 
                    ( SELECT COUNT(*) FROM dian_zhan WHERE dian_zhan.reviewId = t1.id ) AS dianzhanCount,
                    ( SELECT COUNT(*) FROM news_review WHERE news_review.parentId = t1.id ) AS huiFuCount,
                    ( SELECT COUNT(*) FROM dian_zhan WHERE dian_zhan.reviewId = t1.id AND dian_zhan.userId='$userId' ) AS isDianZan,
                    CONCAT(substring(user.userName,1,4),'***') AS userName ,
                    user.nickname,
                    user.photo
                ")
            ->leftJoin(['user'],'t1.userId = user.id')
            ->where($w)
            ->order($order, 'DESC')
            ->paginate([
                'page'=>$pageIndex,
                'list_rows'=>$pageSize
            ]);
        return $r;
    }


    public function queryAll()
    {
        $userId='';
        try {
            $userId = JWTAuth::auth()['userId']->getValue();
        } catch (\Throwable $th) {}
        
        $data = json_decode(\file_get_contents('php://input'),true);
        $r = $this->getList($userId,$data['newId'],$data['parentId'],$data['pageIndex'],$data['pageSize'],(isset($data['order']) ? $data['order'] : ""));
        $r = json_decode(json_encode($r),true);
        foreach ($r['data'] as $i => $value) {
            $r1 = $this->getList($userId,'',$r['data'][$i]['id'] , 1 , 5);
            $r1 = json_decode(\json_encode($r1),true);
            
            foreach($r1['data'] as $k =>$value){
                $r1['data'][$k]['revertObj'] = $r1['data'][$k]['revert'] ? $this->findById($r1['data'][$k]['revert'],$userId) : null;
            }

            $r['data'][$i]['huiFuList'] = $r1;
            $r['data'][$i]['revertObj'] = $r['data'][$i]['revert'] ? $this->findById($r['data'][$i]['revert'],$userId) : null;
        }
        return $r;
        // $a = new news_review();
        // return $a->test();
        // print_r($r['data']);
    }

    public function myHuiFu()
    {
        $userId = JWTAuth::auth()['userId']->getValue();
        $data =Request::param();

        $r = DB::table(['news_review'=>'t1'])
                ->field("t1.*,t2.id AS t2Id ,t3.title AS newTitle")
                ->Join(['news_review'=>'t2'],'t2.revert = t1.id')
                ->Join(['news'=>'t3'],'t3.id = t1.newId')
                ->where([
                    't1.userId'=>$userId,
                ])
                ->order('t1.creationTime','DESC')
                ->paginate([
                    'page'=>$data['pageIndex'],
                    'list_rows'=>$data['pageSize']
                ]);
        $r = json_decode(json_encode($r),true);
        foreach ($r['data'] as $i => $value) {
            $r['data'][$i]['huiFu'] = DB::table(['news_review'=>'t1'])
                                    ->field("t1.* , CONCAT(substring(t2.userName,1,4),'***') AS userName , t2.nickname , t2.photo")
                                    ->leftJoin(['user'=>'t2'],'t2.id = t1.userId')
                                    ->where(['t1.id'=>$r['data'][$i]['t2Id']])
                                    ->find();
        }
        return $r;
    }

}

