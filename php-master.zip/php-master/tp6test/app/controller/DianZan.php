<?php
namespace app\controller;

// use think\Request;
use think\facade\Request;
use think\facade\Db;

use thans\jwt\facade\JWTAuth;

class DianZan
{
    public function index()
    {

    }

    //保存点赞
    // public function save(Request $request)
    public function save()
    {
        // return Request::isPost();
        $data =Request::param();
        $userId = JWTAuth::auth()['userId']->getValue();
        $w=[
            'reviewId'=>$data['reviewId'],
            'userId'=>$userId
        ];
        $r = Db::table('dian_zhan')->where($w)->value('id');
        if($r){
            $r1 = Db::table('dian_zhan')->where($w)->delete();
        }else{
            $r1 = Db::table('dian_zhan')->insert($w);
        }
        return [
            'code'=>$r1
        ];
    }

    public function read($id)
    {
    }

    public function update(Request $request, $id)
    {
    }

    public function delete($id)
    {
    }
}
