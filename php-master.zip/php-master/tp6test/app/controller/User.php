<?php

namespace app\controller;

use app\BaseController;
use think\facade\Db;

//验证
use app\validate\Vregister;
use think\exception\ValidateException;

// https://learnku.com/articles/30578  这个是类似的
// https://gitee.com/thans/jwt-auth
// https://learnku.com/thinkphp/t/32725?order_by=vote_count&
// https://jwt.io/

// thans/tp-jwt-auth
use thans\jwt\facade\JWTAuth;
use think\facade\Request;

use app\model\User as U;
//删除 
// composer remove 依赖名称
class User extends BaseController
{
    public function login()
    {

        $data = json_decode(file_get_contents("php://input"), true);
        $data = [
            'userName' => $data['userName'],
            'password' => $data['password']
        ];
        $rule = [
            'userName'  => 'require',
            'password'   => 'require',
        ];
        $message = [
            'userName' => ['message' => '请输入用户名'],
            'password' => ['message' => '密码长度必须在6-20之间'],
        ];
        try {
            $this->validate($data, $rule, $message, true);
        } catch (\Throwable $e) {
            return $e->getError();
        }
        $user = Db::table('user')->where('userName', $data['userName'])->where('password', md5($data['password']))->find();
        if ($user) {
            $user['photoBlobUrl'] = $user['photoBlob']!='' && $user['photoBlob']!='null';
            unset($user['photoBlob']);
            $token = JWTAuth::builder(['userId' => $user['id']]);
            return [
                'code'=>1,
                'user'=>$user,
                'token'=>$token
            ];
        } else {
            return [
                'code' => 0,
                'message' => '账号密码错误'
            ];
        }
    }
    //刷新
    public function refreshToken()
    {
        JWTAuth::auth(); //token验证
        $r = JWTAuth::refresh(); //刷新token，会将旧token加入黑名单
        return [
            'code' => 1,
            'message' => $r
        ];
    }
    //验证
    public function testToken()
    {
        $userId = JWTAuth::auth()['userId']->getValue();
        $token =JWTAuth::refresh();
        $u = new U();
        $user = $u->queryById($userId);

        $r = [
            'code'=>1,
            'user'=>$user,
            'token'=>$token
        ];
        return $r;
    }

    public function getOut()
    {
        $Authorization = Request::header('Authorization');
        $token = str_replace("bearer ", "", $Authorization);
        $r1 = JWTAuth::invalidate($token);
    }

    // public function test1()
    // {
    //     $user =['id'=>132];
    //     $token = JWTAuth::fromUser($user);
    //     return $token;
    // }
    
    public function getPhoto()
    {
        header("Content-type: image/png");
        try {
            $id = JWTAuth::auth()['userId']->getValue();        
        } catch (\Throwable $th) {
            echo '';
            return;
        }
        $r = Db::table('user')->field('photoBlob')->where('id',$id)->find();
        echo $r['photoBlob'];
    }
    
    public function getUser()
    {
        // $data = Request::param();
        $id = JWTAuth::auth()['userId']->getValue();
        $u = new U();
        return $u->queryById($id);
    }

    public function Update()
    {
        $data = Request::param();
        $blob = Request::file('blob');
        
        $userId = JWTAuth::auth()['userId']->getValue();
        $w = [];
        if (isset($data['password'])) {
            $w['password'] = md5($data['password']);
        }
        if (isset($ata['phone'])) { 
            $w['phone'] = $data['phone'];
        };
        if(isset($data['photo'])){
            $w['photo'] = $data['photo'];
        }
        if(isset($data['address'])){
            $w['address'] = $data['address'];
        }
        if(isset($data['nickname'])){
            $w['nickname'] = $data['nickname'];
        }
        if(isset($blob)){
            $image = file_get_contents($_FILES['blob']['tmp_name']);
            $w['photoBlob'] = $image;
        }
        $r = Db::table('user')->where('id',$userId)->update($w);
        return [
            'code'=>$r
        ];

    }
}

