<?php
namespace app\model;
use think\Model;

class news_review extends Model
{
    protected static function init(){
        
    }
    public function findById($id)
    {
        
    }
    public function getList()
    {
        
    }
}