<?php
namespace app\model;

use think\Model;
use think\facade\Db;

class User extends Model
{
    protected $schema = [
        'id'=>'int',
        // 'userName'=>'',
        'phone'=>'',
        'photo'=>'',
        'address'=>'',
        'nickname'=>''
    ];
    // protected $type = [
    //     'photoBlob'       => 'float',
    // ];
    // 设置废弃字段
    // protected $disuse = [ 'photoBlob'];
    // protected $name = 'user';
    public function queryById($id)
    {
        # code...
        $user = User::find($id);
        $user['photoBlobUrl'] = $user['photoBlob']!='' && $user['photoBlob']!='null';
        unset($user['photoBlob']);
        // $user['photoBlobUrl'] = ;
        return $user;
        // return print_r($user['photoBlob']);
    }
    
}

