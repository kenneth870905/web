<?php
namespace app\model;
class test  
{
    public function t1(Type $var = null)
    {
        return 't1sdfsdfsaf';
    }
}
