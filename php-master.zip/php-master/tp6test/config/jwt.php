<?php


return [
    'secret'      => env('JWT_SECRET'),
    //Asymmetric key
    'public_key'  => env('JWT_PUBLIC_KEY'),
    'private_key' => env('JWT_PRIVATE_KEY'),
    'password'    => env('JWT_PASSWORD'),
    //JWT time to live
    'ttl'         => env('JWT_TTL', 60*24),
    //Refresh time to live
    'refresh_ttl' => env('JWT_REFRESH_TTL', 20160),
    //JWT hashing algorithm
    'algo'        => env('JWT_ALGO', 'HS256'),

    // 宽限时间需要开启黑名单（默认是开启的），黑名单保证过期token不可再用，最好打开
    'blacklist_enabled' => env('JWT_BLACKLIST_ENABLED', true),
    //设定宽限时间，单位：秒
    'blacklist_grace_period'=> env('JWT_BLACKLIST_GRACE_PERIOD', 60),

    'blacklist_storage' => thans\jwt\provider\storage\Tp5::class,
];
