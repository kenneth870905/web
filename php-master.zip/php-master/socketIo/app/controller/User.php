<?php
namespace app\controller;

use app\BaseController;
use DateTime;
use think\facade\Db;
use think\facade\Request;
use think\exception\ValidateException;

//允许跨域 在 middleware.php 中设置

// jwt-token https://learnku.com/articles/7264/using-jwt-auth-to-implement-api-user-authentication-and-painless-refresh-access-token
// https://gitee.com/thans/jwt-auth
use thans\jwt\facade\JWTAuth;

class User extends BaseController
{
    public function index()
    {
        // return '<style type="text/css">*{ padding: 0; margin: 0; } div{ padding: 4px 48px;} a{color:#2E5CD5;cursor: pointer;text-decoration: none} a:hover{text-decoration:underline; } body{ background: #fff; font-family: "Century Gothic","Microsoft yahei"; color: #333;font-size:18px;} h1{ font-size: 100px; font-weight: normal; margin-bottom: 12px; } p{ line-height: 1.6em; font-size: 42px }</style><div style="padding: 24px 48px;"> <h1>:) 2020新春快乐</h1><p> ThinkPHP V' . \think\facade\App::version() . '<br/><span style="font-size:30px;">14载初心不改 - 你值得信赖的PHP框架</span></p><span style="font-size:25px;">[ V6.0 版本由 <a href="https://www.yisu.com/" target="yisu">亿速云</a> 独家赞助发布 ]</span></div><script type="text/javascript" src="https://tajs.qq.com/stats?sId=64890268" charset="UTF-8"></script><script type="text/javascript" src="https://e.topthink.com/Public/static/client.js"></script><think id="ee9b1aa918103c4fc"></think>';
        // return '注册页面';
        // return uniqid().time().rand(100000, 9999999);
        return uniqid();
    }

    public function hello($name = 'ThinkPHP6')
    {
        return 'hello,' . $name;
    }

    public function zhuce()
    {
        $rule = [
            'account'  => 'require|max:25|min:3',
            'pwd'=>"require",
            'name'=>'require|chs|min:2|max:4'
        ];
        $message = [
            'account.require'  =>  ['message'=>'请输入注册账号'],
            'account.max'  =>  ['message'=>'账号最大25位'],
            'account.min'  =>  ['message'=>'账号最小3位'],
            'pwd'=>['message'=>'请输入密码'],
            'name.require'=>['message'=>'请输入昵称'],
            'name.chs'=>['message'=>'昵称只能是中文'],
            'name.min'=>['message'=>'昵称长度为2-4位'],
            'name.max'=>['message'=>'昵称长度为2-4位'],
        ];
       
        $data = Request::param();
        $data = json_decode( \json_encode($data) ,true);
        try {
            $this->validate($data,$rule,$message);
        } catch (ValidateException $e) {
            return $e->getError();
        } 
        
        // $data['creationTime']='NOW()';
        // $data['creationTime']=array('exp','NOW()');

        // return $data;
        $user = Db::table('user')->where('account', $data['account'])->find();
        if($user){
            return [
                'code'=>0,
                'message'=>'账号已被注册'
            ];
        }
        $add = [
            'account'=>$data['account'],
            'pwd'=>\md5($data['pwd']),
            'name'=>$data['name'],
            // 'creationTime'=>array("EXP","now()"),
            // 'creationTime1'=>['exp',"NOW()"],
            // 'creationTime2'=>['exp',"now()"]
            'creationTime'=>date('Y-m-d H:i:s')
        ];
        // $r = Db::table('user')->insert($add);
        $r = Db::table('user')->insertGetId($add);
        
        if($r){
            return [
                // $token = JWTAuth::builder(['uid' => 1]);//参数为用户认证的信息，请自行添加
                "token"=>JWTAuth::builder(['id' => $r]),         
                'code' => 1,
                'message' => '注册成功'
            ];
        }else{
            return [
                'code' => 0,
                'message' => '注册失败'
            ];
        }

    }

    public function renzheng()
    {
        $id = JWTAuth::auth();//token验证
        // $id = JWTAuth::auth()['id']->getValue();
        return $id; 
    }

    public function login()
    {
        $data = Request::param();
        $w = [
            'account'=>$data['account'],
            'pwd'=>\md5($data['pwd'])
        ];
        $user = Db::table('user')->where($w)->find();
        if($user){
            return [
                'code'=>1,
                'user'=>$user,
                'token'=>JWTAuth::builder(['id' => $user['id']])
            ];
        }else{
            return [
                'code'=>0,
                'message'=>'账号或密码错误'
            ];
        }
    }

    public function getUser()
    {
        try {
            $id = JWTAuth::auth()['id']->getValue();
        } catch (\Throwable $th) {
            return [
                'code'=>0,
                'message'=>'登录失效'
            ];
        }
        $user = DB::table('user')->where('id',$id)->find();
        if($user){
            unset($user['pwd']);
            return [
                'code'=>1,
                'user'=>$user
            ];
        }else{
            return [
                'code'=>0,
                'message'=>'未找到用户信息'
            ];
        }
    }

    public function getUserList()
    {
        $data = Request::param();
        // $r = Db::table('user')->limit(0,25)->select();
        $r = Db::name('user')->paginate([
            'list_rows'=>10,
            'page'=>$data['pageIndex']
        ]);
        return $r;
    }
}


