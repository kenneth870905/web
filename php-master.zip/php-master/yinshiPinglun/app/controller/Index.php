<?php
namespace app\controller;

use app\BaseController;
use think\facade\Db;
use think\facade\Request;

// use function GuzzleHttp\json_encode;
// use function GuzzleHttp\json_encode as GuzzleHttpJson_encode;

// 跨域设置
// 在 app/middleware.php 文件中添加

use think\facade\Session;
use think\facade\View;

class Index extends BaseController
{
    public function index()
    {
        return '<style type="text/css">*{ padding: 0; margin: 0; } div{ padding: 4px 48px;} a{color:#2E5CD5;cursor: pointer;text-decoration: none} a:hover{text-decoration:underline; } body{ background: #fff; font-family: "Century Gothic","Microsoft yahei"; color: #333;font-size:18px;} h1{ font-size: 100px; font-weight: normal; margin-bottom: 12px; } p{ line-height: 1.6em; font-size: 42px }</style><div style="padding: 24px 48px;"> <h1>:) </h1><p> ThinkPHP V6<br/><span style="font-size:30px">13载初心不改 - 你值得信赖的PHP框架</span></p></div><script type="text/javascript" src="https://tajs.qq.com/stats?sId=64890268" charset="UTF-8"></script><script type="text/javascript" src="https://e.topthink.com/Public/static/client.js"></script><think id="eab4b9f840753f8e7"></think>';
    }

    public function hello($name = 'ThinkPHP6')
    {
        return 'hello,' . $name;
    }

    public function queryType(){
        $r = Db::table('t1')->where('(SELECT COUNT(*) FROM list WHERE list.t1Id = t1.id ) !=0')->select();
        return $r;
    }

    /**
     * {pageIndex:1,pageSize,t1Id:'',title:""}
     * 根据类型  名字查询
     * 
    */
    public function getList()
    {
        $data = Request::param();

        $goto=$this->ipTest();
        if($goto!=''){
            $arr = [
                'redirect'=>$goto,
                'data'=>[]
            ];
            echo json_encode($arr);
            return;
        }

        $w=[];
        if(isset($data['t1Id'])){
            $w['t1Id']=$data['t1Id'];
        }
        if(isset($data['title']) && $data['title']!=''){
            $r = Db::table('list')
                ->where($w)
                ->where('title','like','%'.$data['title'].'%')
                ->where("EXISTS( SELECT * FROM details WHERE details.list_id = list.id)")
                ->paginate([
                    'page'=>$data['pageIndex'],
                    'list_rows'=>$data['pageSize']
                ])->toArray();
        }else{
            $r = Db::table('list')
                ->where($w)
                ->where("EXISTS( SELECT * FROM details WHERE details.list_id = list.id)")
                ->paginate([
                    'page'=>$data['pageIndex'],
                    'list_rows'=>$data['pageSize']
                ])->toArray();
        }
        

        echo \json_encode($r);
        return;
        // return $r;
    }

    public function getDetails()
    {
        $data = Request::param();
        $r=[];
        $r['obj'] = Db::table('list')->where(['id'=>$data['id']])->find();
        $r['details'] = Db::table('details')->where(['list_id'=>$data['id']])->find();
        return $r;
    }

    public function ipTest()
    {
        // $request = Request::instance();

        $ip = request()->ip();
        $goto='';
        if(defined('__GotoUrl__') && __GotoUrl__!=''){
            // $r['goto']=__GotoUrl__;
            // $r['data']=[];
            $ip = request()->ip();
            // $ip = '116.118.112.141'; //越南
            // $ip = '67.220.91.30';   //美国
            $country = '';
            try {
                $ipjson = file_get_contents("http://ip.taobao.com/service/getIpInfo2.php?ip=".$ip);
                $ipobj = \json_decode($ipjson,true);
                $country = $ipobj['data']['country'];
            } catch (\Throwable $th) {}
            if(defined('__RegionalBlacklist__')){
                if(in_array($country,__RegionalBlacklist__)){
                    $goto = __GotoUrl__;
                }
            }else{
                $goto = __GotoUrl__;
            }
        }
        

        return $goto;
    }
    
    // 不能跨域
    // 而且需要开启
    public function setSession()
    {
        $data = Request::param();
        Session::set('name', $data['id']);
    }
    public function testSession()
    {
        $name =  Session::get('name');
        $all = Session::all();
        echo $name;
        print_r($all);
    }

    public function testHtml()
    {
        // return $this->engine('php')->fetch();
        // 改变当前操作的模板路径
        // View::config(['view_path' => 'a']);

        // $content = '{$name}-{$email}';
        // $template = new \think\Template();
        // // $template->fetch('a', ['name' => 'ThinkPHP']);
        // $template->fetch('Test/Hello');
        // $temlate->display($content, ['name' => 'thinkphp', 'email' => 'thinkphp@qq.com']);
        // $this->a ='admin';
        // return View::fetch('Test/a');
    }

}
