<?php
namespace app\index\controller;
use QL\QueryList;
class Test
{
    public function index()
    {
        // return 'sadf';
        // $data = QueryList::get('http://cms.querylist.cc/bizhi/453.html')->find('img')->attrs('src');
        $data = QueryList::get('http://cms.querylist.cc/bizhi/453.html');
        //打印结果
        // print_r($data->all());
        print_r($data);
        // return $data;
    }

    public function test()
    {
        return 'hello,' ;
    }
}
